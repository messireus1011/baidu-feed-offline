#!/bin/sh

source ~/.bashrc
source ./conf/run.conf

set -x

# 判断上一个反馈计算任务是否结束
run_state=`cat ./state/run_state.txt`
if [ "${run_state}" == "doing" ]; then
    exit 0
else
    echo "last task has done, start this task"
fi

echo "doing" > ./state/run_state.txt

if [ $# -eq 3 ]; then
    cur_day=$1
    cur_hour=$2
    cur_min=$3
elif [ $# -eq 0 ];then
    cur_time=`date "+%Y%m%d %H %M"`
    cur_day=`echo ${cur_time} | awk '{print $1}'`
    cur_hour=`echo ${cur_time} | awk '{print $2}'`
    cur_min=`echo ${cur_time} | awk '{print $3}'`
fi

yes_day=`date -d "-1 day $cur_day" +'%Y%m%d'`
cur_dayhour=${cur_day}${cur_hour}
cur_dayhourmin=${cur_day}${cur_hour}${cur_min}

echo "*****************this task start at ${cur_dayhourmin} *********************"
mysql="/home/work/.jumbo/bin/mysql -h 100.66.154.42 -P9030 -u admin -pfeedBd2023 -N -e"
#mysql="/home/work/.jumbo/bin/mysql -h 10.138.28.235 -P9030 -u admin -pBes_report -N -e"    #主物理机使用保定集群数据库
#mysql="/home/work/.jumbo/bin/mysql -h 100.64.7.211 -P9030 -u admin -pBes_report -N -e"    #备用：使用华南集群数据库
#mysql="/home/work/.jumbo/bin/mysql -h 10.99.1.172 -P9030 -u admin -pBes_report -N -e"    #备用：使用华南集群数据库

palo_data=${PALO_DIR}/palo_${cur_dayhourmin}
ocpx_data=${OCPX_DIR}/ocpx_${cur_dayhourmin}
shallow_data=${SHALLOW_DIR}/shallow_data_${cur_dayhourmin}
conv_adjust_data=${CONV_ADJUST_DIR}/conv_adjust_${cur_dayhourmin}
agg_diff_data=${AGG_DIFF_DIR}/agg_diff_${cur_dayhourmin}
aggid_map_data=${AGGID_MAP_DIR}/aggid_map_${cur_dayhourmin}
user_dim_file=${USER_DIM_DIR}/user_dim_file
feedback_dict=${FEEDBACK_DICT}/dict_${cur_dayhourmin}

# 需要数据的时间范围
begin=$(date -d "${cur_day} ${cur_hour} -120 hour" +"%Y%m%d%H")
end=$(date -d "${cur_day} ${cur_hour} -8 hour" +"%Y%m%d%H")
# 重试次数
try_num=0

while [[ ${try_num} -lt 3 ]]; do
    $mysql "set query_timeout=120;
      SELECT
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source, feedback_agg_tag, feedback_agg_id,
        max(is_ocpc_deep) as is_ocpc_deep, max(trans_type) as trans_type, max(deep_trans_type) as deep_trans_type,
        sum(page_views) as sum_eshow, sum(clicks) as sum_clk, sum(conversions) as sum_tnum, sum(ocpc_bid) as sum_obid, sum(conv_ocpc_bid) as sum_conv_obid,
        sum(pay) + sum(cpmpay) / 1000.0 as charge, sum(if(pricing_type=0,price_before_bank_accont,price_before_bank_accont/1000)) as sum_bat, sum(reach_adjust_coe) as coe
      FROM shoubai_online_data.deep_shoubai_pay_cvt_v3
      WHERE
        CONCAT(date, LPAD(CAST(hour as CHAR),2,0)) >= ${begin:0:8}00
        AND CONCAT(date, LPAD(CAST(hour as CHAR),2,0)) <= ${end}
        AND ocpclevel = 2 AND bidtype = 3 AND is_ocpc_deep = 1
        AND cmatch IN (545,669,719,1220,1214,1227,1501,1502,778,547,489,1761,829,646,588,534,1447,720,1429,1173,1738,1639,640,687,689,546,585,844,706,1349,1377,1083,628,855,1511,1016,1085,913)
        AND deep_trans_type != 28
      GROUP BY
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source, feedback_agg_tag, feedback_agg_id;
    " > ${palo_data}_tmp

    if [ $? -ne 0 ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "gen palo data failed at ${cur_dayhourmin}"
                rm -r ${palo_data}_tmp
                echo "Failed to get palo data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
                echo "done" > ./state/run_state.txt
                exit -1
        fi
    else
            echo "gen palo data success at ${cur_dayhourmin}"
            mv ${palo_data}_tmp ${palo_data}
            break
    fi
    try_num=`expr ${try_num} + 1`
done

echo "end sql 24h data at `date`"

time_frame=$(date -d "${cur_day} ${cur_hour} -1 hour" +"%Y%m%d%H")
try_num=0

while [[ ${try_num} -lt 3 ]]; do
    $mysql "set query_timeout=120;
      select
        date, hour, unitid, planid, userid, cmatch, pricing_type,
        max(is_ocpc_deep) as is_ocpc_deep, max(trans_type) as trans_type, max(deep_trans_type) as deep_trans_type,
        sum(page_views) as sum_eshow, sum(clicks) as sum_clk, sum(conversions) as sum_tnum, sum(ocpc_bid) as sum_obid, sum(conv_ocpc_bid) as sum_conv_obid,
        sum(pay) + sum(cpmpay) / 1000.0 as charge, sum(if(pricing_type=0,price_before_bank_accont,price_before_bank_accont/1000)) as sum_bat
      from shoubai_online_data.shoubai_pay_cvt_v3
      where
        date in (${cur_day})
        and cmatch in (545,669,719,1220,1214,1227,1501,1502,778,547,489,1761,829,646,588,534,1447,720,1429,1173,1738,1639,640,687,689,546,585,844,706,1349,1377,1083,628,855,1511,1016,1085,913)
        and ocpclevel = 2 and bidtype = 3 and is_ocpc_deep = 1
        and deep_trans_type != 28
      group by
        date, hour, unitid, planid, userid, cmatch, pricing_type;
    " > ${shallow_data}_tmp

    if [ $? -ne 0 ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "gen palo data failed at ${cur_dayhourmin}"
                rm -r ${shallow_data}_tmp
                echo "Failed to get palo data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
                echo "done" > ./state/run_state.txt
                exit -1
        fi
    else
            echo "gen palo data success at ${cur_dayhourmin}"
            mv ${shallow_data}_tmp ${shallow_data}
            break
    fi
    try_num=`expr ${try_num} + 1`
done

## 合并ocpc和ocpm
#echo "start merging ocpx data at `date`"
#cat ${palo_data} | python3 script/merge_ocpx_data.py > ${ocpx_data}_tmp
#if [[ $? -ne 0 ]];then
#    echo "Failed to merge ocpx data"
#    echo "Failed to merge ocpx data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
#    echo "done" > ./state/run_state.txt
#    exit -1
#fi

# 转化延迟修正
cat ${palo_data} | python3 script/conv_delay_revise.py ${cur_day} ${cur_hour} ${CONV_DELAY_RATIO_DATA} > ${conv_adjust_data}_tmp
if [[ $? -ne 0 ]];then
    echo "Failed to revise conv data"
    echo "Failed to revise conv data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

# 更新账户-实体映射
# 先确保没有并行在修改，否则等待2m
try_num=0
while [[ ${try_num} -lt 3 ]]; do
    vrelation_state=`cat ${VRELATION_DIR}/vrelation_state.txt`
    if [ "${vrelation_state}" == "doing" ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "Failed to get vrelation data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
            echo "done" >> ./state/run_state.txt
            exit -1
        fi
        sleep 3m
    else
        echo "get vrelation"
        break
    fi
    try_num=`expr ${try_num} + 1`
done

# 加入公司,没公司的则entityid=0
awk 'BEGIN{FS=OFS="\t"}ARGIND==1{company_name[$2]=$3}ARGIND==2{user_company=company_name[$4]; if(user_company){print $0,user_company}else{print $0,0}}' ${VRELATION_FILE} ${conv_adjust_data}_tmp > ${conv_adjust_data}
rm -rf ${conv_adjust_data}_tmp

# 分层级聚合数据
cat ${conv_adjust_data} | python3 script/agg_diff_dim.py ${user_dim_file} ${aggid_map_data} > ${agg_diff_data}
if [[ $? -ne 0 ]];then
    echo "Failed to cal feedback coe at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

data_for_bak=${DATA_FOR_BAK_DIR}/data_for_bak_${cur_dayhourmin}
if [ ! -f ${data_for_bak} ]; then
    touch ${data_for_bak}
fi

# 反馈计算
cat ${agg_diff_data} | python3 script/cal_deep_feedback_coe.py ${cur_dayhour} ${shallow_data} ${data_for_bak} > ${feedback_dict}

if [[ $? -ne 0 ]];then
    echo "Failed to cal feedback coe at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

echo ${feedback_dict} >> ${DEEP_FEEDBACK_DICT}
echo ${data_for_bak} >> ${BANK_ACCOUNT_DICT}
echo ${aggid_map_data} >> ${AGGID_MAP_DICT}
echo "ocpx feedback dict success"
echo "done" > ./state/run_state.txt
echo "=======================SUCCESS====================="
