# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/04/22
Function：转化延迟修正
Input：   合并后的ocpx数据
          key：datehour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type
Output：  修正后的ocpx数据
          key：datehour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type
"""

import configparser
import datetime
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path


def load_conv_delay_ratio_dict(conv_delay_ratio):
    """
    功能：生成数据词典
    参数：转化延迟率的分桶数据
    """
    print("Loading conv delay ratio into dict...", file=sys.stderr)
    conv_delay_ratio_dict = {}
    with open(conv_delay_ratio, 'r') as f:
        for line in f:
            #一共50列: [unitid, 第0小时的延迟率(即当前小时，在转化延迟统计里处理成了第1小时的延迟率), 第1小时的延迟率，第2小时的延迟率，...]
            items = line.strip().split('\t')
            unitid = items[0]
            ratio_list = list(map(float, items[1:]))
            conv_delay_ratio_dict[unitid] = ratio_list

    return conv_delay_ratio_dict

def delay_bucket(cur_dayhour):
    """
    功能：根据当前时间生成前48小时的对应时间与索引
    参数：当前时间
    """
    print("Loading delay_bucket_index into dict...", file=sys.stderr)
    delay_bucket_index_dict = {}
    for index in range(1, 49):
        pre_dayhour = (datetime.datetime.strptime(cur_dayhour, "%Y%m%d%H") 
                + datetime.timedelta(hours=-index)).strftime("%Y%m%d%H")
        delay_bucket_index_dict[pre_dayhour] = index
    print(delay_bucket_index_dict, file=sys.stderr)
    return delay_bucket_index_dict
    

def conv_delay_revise(ocpx_data):
    """
    功能：转化延迟修正
    参数：merge ocpx的数据
    """

    print ("Revising conv data...", file=sys.stderr)
    for line in ocpx_data.strip().split("\n"):
        items = line.strip().split('\t')
        date, hour, unitid, planid, userid, cmatch, pricing_type, \
                bid_source, feedback_agg_tag, feedback_agg_id, is_ocpc_deep, trans_type, deep_trans_type, \
                eshow, clk, conv, obid, conv_obid, charge, bat, coe = items
        eshow, clk, conv = map(int, [eshow, clk, conv])
        obid, conv_obid, charge, bat, coe = map(float, [obid, conv_obid, charge, bat, coe])

        ### 类型过滤
        # 付费直投和45不生效反馈
        if trans_type == '26' or trans_type == '45':
            continue
        # 单出价和次留才走浅层反馈
        if is_ocpc_deep == '1' and deep_trans_type not in ['28', '18']:
            continue
        # 易车：deep_trans_type = 18 圈户生效浅层反馈
        if deep_trans_type == "18" and userid not in ["48365466", "45802061"]:
            continue

        ### bank_account 使用
        # 什么情况下用bat？数据流更新之后可以直接用pam标识,不用除1000，从Palo拉的时候已经除了
        #if cmatch in bak_cmatch and trans_type in bak_transtype:
        #    if pricing_type == '1':
        #        charge = bat/1000
        #    else:
        #        charge = bat
        if cmatch in bak_cmatch and pricing_type == '0':
            charge = bat

        ### 异常时间剔除
        dayhour = date + hour.zfill(2)
        if dayhour == "2023041811" or dayhour == "2023041812":
            continue
        # 度小店转化影响，异常时间剔除
        if trans_type in ['80', '90'] and (dayhour == "2023050911" or dayhour == "2023050912"):
            continue
        # 浅层只使用当天数据
        if date != today:
            continue
        # 不用最近一小时数据
        if dayhour == cur_dayhour or dayhour == one_hour_ago:
        #if dayhour == cur_dayhour:
            continue
        # 可能会出现一些大于当前时间的，剔除异常时间
        try:
            index = delay_bucket_index_dict[dayhour]
        except:
            continue
        
        ### 转化延迟修正 
        try:
            conv_delay_ratio = conv_delay_ratio_dict[unitid][index]
        except:
            conv_delay_ratio = 1.0
        
        #conv_delay_ratio = 1.0
        new_conv = conv / conv_delay_ratio
        tcharge = conv_obid / conv_delay_ratio

        print('\t'.join(map(str, [dayhour, unitid, planid, userid, cmatch, pricing_type, \
                bid_source, feedback_agg_tag, feedback_agg_id, is_ocpc_deep, trans_type, deep_trans_type, \
                eshow, clk, new_conv, obid, tcharge, charge, coe])))
        
        # 测试
        # if conv_delay_ratio < 1.0:
        #     print('unit:{0} ori_conv:{1} new_conv:{2} conv_delay_ratio:{3} dayhour:{4} index:{5}'\
        #             .format(unitid, conv, new_conv, conv_delay_ratio, dayhour, index), file=sys.stderr)
        
    print("Revised conv data", file=sys.stderr)



# 读取配置文件
config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)
bak_cmatch = config["BANK_ACCOUNT"].get("BAK_CMATCH").split(',')
bak_transtype = config["BANK_ACCOUNT"].get("BAK_TRANSTYPE").split(',')


# 将数据读入内存，方便进行多次读取
ocpx_data = sys.stdin.read()

#输入参数
cur_day = sys.argv[1]
cur_hour = sys.argv[2]
conv_delay_ratio = sys.argv[3]
cur_dayhour = cur_day + cur_hour.zfill(2)
one_hour_ago = (datetime.datetime.strptime(cur_dayhour, "%Y%m%d%H") + datetime.timedelta(hours=-1)).strftime("%Y%m%d%H")
today = datetime.datetime.now().strftime('%Y%m%d')
if __name__ == '__main__':
    conv_delay_ratio_dict = load_conv_delay_ratio_dict(conv_delay_ratio)
    delay_bucket_index_dict = delay_bucket(cur_dayhour)
    conv_delay_revise(ocpx_data)
