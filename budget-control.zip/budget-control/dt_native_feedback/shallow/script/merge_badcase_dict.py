# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/05/06
Function：合并浅层反馈词典、深层反馈词典和飞线词典
Input：   浅层词典、深层词典和飞线词典
Output:   最终的反馈词典
"""

import configparser
import datetime
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path

def merge_dict(shallow_feedback):
    """
    功能：合并词典
    """
    data_dict = {}
    for line in shallow_feedback.strip().split("\n"):
        items = line.strip().split('\t')
        dim, dimid, cmatch, trans_type, deep_trans_type, coe = items
        key = dim + '\t' + dimid + '\t' + cmatch + '\t' + trans_type + '\t' + deep_trans_type
        data_dict[key] = coe
    print("load shallow feedback", file=sys.stderr)
    
    # badcase覆盖基线系数
    with open(bad_case, 'r') as f2:
        for line in f2:
            items = line.strip().split('\t')
            dim, dimid, cmatch, trans_type, deep_trans_type, coe = items
            key = dim + '\t' + dimid + '\t' + cmatch + '\t' + trans_type + '\t' + deep_trans_type
            data_dict[key] = coe

    print("load bad case", file=sys.stderr)
    return data_dict

def output_data_dict():
    """
    功能：输出词典
    参数：词典存储路径
    """
    for key in data_dict:
        dim, dimid, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        coe = data_dict[key]
        print("\t".join(map(str, [dim, dimid, cmatch, trans_type, deep_trans_type, coe])))
    print("save final dict after merge", file=sys.stderr)

# 读取配置文件
config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)

# 将数据读入内存，方便进行多次读取
shallow_feedback = sys.stdin.read()
bad_case = sys.argv[1]

if __name__ == '__main__':
    data_dict = merge_dict(shallow_feedback)
    output_data_dict()
