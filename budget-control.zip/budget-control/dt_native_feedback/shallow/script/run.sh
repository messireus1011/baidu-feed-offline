#!/bin/sh

source ~/.bashrc
source ./conf/run.conf

set -x

# 判断上一个反馈计算任务是否结束
run_state=`cat ./state/run_state.txt`
if [ "${run_state}" == "doing" ]; then
    exit 0
else
    echo "last task has done, start this task"
fi

echo "doing" > ./state/run_state.txt

if [ $# -eq 3 ]; then
    cur_day=$1
    cur_hour=$2
    cur_min=$3
elif [ $# -eq 0 ];then
    cur_time=`date "+%Y%m%d %H %M"`
    cur_day=`echo ${cur_time} | awk '{print $1}'`
    cur_hour=`echo ${cur_time} | awk '{print $2}'`
    cur_min=`echo ${cur_time} | awk '{print $3}'`
fi

week_before=`date -d "-7 day $cur_day" +'%Y%m%d'`
yes_day=`date -d "-1 day $cur_day" +'%Y%m%d'`
cur_dayhour=${cur_day}' '${cur_hour}
cur_dayhourmin=${cur_day}${cur_hour}${cur_min}
one_dayhour=`date -d "-1 hour" "+%Y%m%d%H"`
cur_datehour=${cur_day}${cur_hour}

echo "*****************this task start at ${cur_dayhourmin} *********************"
mysql="/home/work/.jumbo/bin/mysql -h 100.66.154.42 -P9030 -u admin -pfeedBd2023 -N -e"
#mysql="/home/work/.jumbo/bin/mysql -h 10.138.28.235 -P9030 -u admin -pBes_report -N -e"    #主物理机使用保定集群数据库
#mysql="/home/work/.jumbo/bin/mysql -h 100.64.7.211 -P9030 -u admin -pBes_report -N -e"    #备用：使用华南集群数据库
#mysql="/home/work/.jumbo/bin/mysql -h 10.99.1.172 -P9030 -u admin -pBes_report -N -e"    #备用：使用华南集群数据库(不要用这个)

palo_data=${PALO_DIR}/palo_${cur_dayhourmin}
week_data=${WEEK_DIR}/week_${cur_dayhourmin}
ocpx_data=${OCPX_DIR}/ocpx_${cur_dayhourmin}
conv_adjust_data=${CONV_ADJUST_DIR}/conv_adjust_${cur_dayhourmin}
agg_diff_data=${AGG_DIFF_DIR}/agg_diff_${cur_dayhourmin}
aggid_map_data=${AGGID_MAP_DIR}/aggid_map_${cur_dayhourmin}
user_dim_file=${USER_DIM_DIR}/user_dim_file
user_dim_data=${USER_DIM_DIR}/user_dim_${cur_dayhourmin}
adjust_user=${ADJUST_USER}/adjust_user
#bayes_data=`tail -1 ${BAYES_DIR}/bayes_data`
feedback_dict=${FEEDBACK_DICT}/dict_${cur_dayhourmin}
cyc_res_data=${CYC_RES_FILE}
learning_feedback_dict=${FEEDBACK_DICT}/learning_${cur_dayhourmin}
dt_feedback_dict=${FEEDBACK_DICT}/dt_${cur_dayhourmin}

# 需要数据的时间范围
time_frame=`date -d "-25 hour ${cur_dayhour}" +"%Y%m%d%H"`
# 重试次数
try_num=0

while [[ ${try_num} -lt 3 ]]; do
    $mysql "set query_timeout=120; 
      select 
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source, feedback_agg_tag, feedback_agg_id,
        max(is_ocpc_deep) as is_ocpc_deep, max(trans_type) as trans_type, max(deep_trans_type) as deep_trans_type,
        sum(page_views) as sum_eshow, sum(clicks) as sum_clk, sum(conversions) as sum_tnum, sum(ocpc_bid) as sum_obid, sum(conv_ocpc_bid) as sum_conv_obid, 
        sum(pay) + sum(cpmpay) / 1000.0 as charge, sum(if(pricing_type=0,price_before_bank_accont,price_before_bank_accont/1000)) as sum_bat, sum(reach_adjust_coe) as coe 
      from shoubai_online_data.shoubai_pay_cvt_v3
      where 
        date in (${cur_day}, ${yes_day})
        and cmatch not in (670, 671, 672, 673, 700, 713, 716, 782, 710, 795, 796, 797, 794, 798, 799, 800, 801, 891, 896, 973, 908, 1372, 1373, 1374, 1466, 1354, 1509)
        and ocpclevel=2 and bidtype=3 and trans_type is not null
      group by 
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source, feedback_agg_tag, feedback_agg_id;
    " > ${palo_data}_tmp

    if [ $? -ne 0 ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "gen palo data failed at ${cur_dayhourmin}"
                rm -r ${palo_data}_tmp
                echo "Failed to get palo data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
                echo "done" > ./state/run_state.txt
                exit -1
        fi
    else
            echo "gen palo data success at ${cur_dayhourmin}"
            mv ${palo_data}_tmp ${palo_data}
            break
    fi
    try_num=`expr ${try_num} + 1`
done

while [[ ${try_num} -lt 3 ]]; do
    $mysql "set query_timeout=120;
      select
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source,
        max(is_ocpc_deep) as is_ocpc_deep, max(trans_type) as trans_type, max(deep_trans_type) as deep_trans_type,
        sum(page_views) as sum_eshow, sum(clicks) as sum_clk, sum(conversions) as sum_tnum, sum(ocpc_bid) as sum_obid, sum(conv_ocpc_bid) as sum_conv_obid,
        sum(pay) + sum(cpmpay) / 1000.0 as charge, sum(if(pricing_type=0,price_before_bank_accont,price_before_bank_accont/1000)) as sum_bat
      from shoubai_online_data.shoubai_pay_cvt_v3
      where
        date between $week_before and $cur_day
        and cmatch not in (670, 671, 672, 673, 700, 713, 716, 782, 710, 795, 796, 797, 794, 798, 799, 800, 801, 891, 896, 973, 908, 1372, 1373, 1374, 1466, 1354, 1509)
        and ocpclevel = 2 and bidtype = 3 and is_ocpc_deep = 0
        and trans_type in (42)
      group by
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source;
    " > ${week_data}_tmp

    if [ $? -ne 0 ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "gen week data failed at ${cur_dayhourmin}"
                rm -r ${week_data}_tmp
                echo "Failed to get week data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
                echo "done" > ./state/run_state.txt
                exit -1
        fi
    else
            echo "gen week data success at ${cur_dayhourmin}"
            mv ${week_data}_tmp ${week_data}
            break
    fi
    try_num=`expr ${try_num} + 1`
done

## 合并ocpc和ocpm
#echo "start merging ocpx data at `date`"
#cat ${palo_data} | python3 script/merge_ocpx_data.py > ${ocpx_data}
#if [[ $? -ne 0 ]];then
#    echo "Failed to merge ocpx data"
#    echo "Failed to merge ocpx data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
#    echo "done" > ./state/run_state.txt
#    exit -1
#fi


# 转化延迟修正
cat ${palo_data} | python3 script/conv_delay_revise.py ${cur_day} ${cur_hour} ${CONV_DELAY_RATIO_DATA} > ${conv_adjust_data}_tmp
if [[ $? -ne 0 ]];then
    echo "Failed to revise conv data"
    echo "Failed to revise conv data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi


# 更新账户-实体映射
# 先确保没有并行在修改，否则等待2m
try_num=0
while [[ ${try_num} -lt 3 ]]; do
    vrelation_state=`cat ${VRELATION_DIR}/vrelation_state.txt`
    if [ "${vrelation_state}" == "doing" ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "Failed to get vrelation data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
            echo "done" >> ./state/run_state.txt
            exit -1
        fi
        sleep 2m
    else
        echo "get vrelation"
        break
    fi
    try_num=`expr ${try_num} + 1`
done

# 加入公司,没公司的则entityid=0
awk 'BEGIN{FS=OFS="\t"}ARGIND==1{company_name[$2]=$3}ARGIND==2{user_company=company_name[$4]; if(user_company){print $0,user_company}else{print $0,0}}' ${VRELATION_FILE} ${conv_adjust_data}_tmp > ${conv_adjust_data}
rm -rf ${conv_adjust_data}_tmp

# 分层级聚合数据
# conv_adjust_Coe 在初始两小时为空，需要添加这逻辑，否则脚本会报错
# 初始两个小时直接产出空
if [ "${cur_hour}" == "00" ] || [ "${cur_hour}" == "01" ]; then
    cp hack_agg_diff_data ${agg_diff_data}
else
    wget -O ${user_dim_file} http://zongkong.baidu.com/home/work/zongkong/userdata/93/feedback_user_dim_file/feedback_user_dim_file_zk.txt && cp ${user_dim_file} ${user_dim_data}
    cat ${conv_adjust_data} | python3 script/agg_diff_dim.py ${user_dim_data} ${aggid_map_data} > ${agg_diff_data}
fi
if [[ $? -ne 0 ]];then
    echo "Failed to cal feedback coe at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

data_for_bak=${DATA_FOR_BAK_DIR}/data_for_bak_${cur_dayhourmin}
dt_for_bak=${DT_FOR_BAK_DIR}/dt_for_bak_${cur_dayhourmin}
if [ ! -f ${data_for_bak} ]; then
    touch ${data_for_bak}
fi

# PID反馈计算
cat ${agg_diff_data} | python3 script/cal_feedback_coe.py ${week_data} ${data_for_bak} > ${feedback_dict}
if [[ $? -ne 0 ]];then
    echo "Failed to cal feedback coe at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

echo ${feedback_dict} >> ${SHALLOW_FEEDBACK_DICT}
echo ${data_for_bak} >> ${SHALLOW_BANK_ACCOUNT_DICT}
echo "ocpx feedback dict success"
echo "done" > ./state/run_state.txt

# 取最新记录
shallow_feedback_dict=`tail -1 ${SHALLOW_FEEDBACK_DICT}`
deep_feedback_dict=`tail -1 ${DEEP_FEEDBACK_DICT}`
shallow_bak_dict=`tail -1 ${SHALLOW_BANK_ACCOUNT_DICT}`
deep_bak_dict=`tail -1 ${DEEP_BANK_ACCOUNT_DICT}`

# 深层的映射
deep_aggid_map_dict=`tail -1 ${DEEP_AGGID_MAP_DICT}`
cat ${deep_aggid_map_dict} >> ${aggid_map_data}

if [ "${cur_hour}" == "00" ] || [ "${cur_hour}" == "01" ]; then
    > ${dt_feedback_dict}
else
    /home/disk2/chenjunhao02/python3717/bin/python3 dt/parallel_predict.py ${agg_diff_data} dt/models/dt_model_success1 ${cur_hour} ${dt_for_bak} > ${dt_feedback_dict}
    if [[ $? -ne 0 ]];then
        echo "Failed to run dt coe at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
        python script/sendAlarmMsg.py -h -r 'chenjunhao02' -c "!!!!! run dt failed !!!!!"
        > ${dt_feedback_dict}
        #echo "done" > ./state/run_state.txt
        #exit -1
    fi
fi

# 合并反馈词典
mkdir ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}
cat ${shallow_feedback_dict} | python3 script/merge_dict.py ${deep_feedback_dict} ${dt_feedback_dict} ${aggid_map_data} > ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/ocpx_feedback_dict.txt
if [[ $? -ne 0 ]];then
    echo "Failed to merge feedback dict"
    echo "Failed to merge feedback dict at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

# badcase直接生效
cat ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/ocpx_feedback_dict.txt | python3 script/merge_badcase_dict.py ${BADCASE_DIR}/dict > ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/final_ocpx_feedback_dict.txt
if [[ $? -ne 0 ]];then
    echo "Failed to get final feedback dict"
    echo "Failed to get final feedback dict at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

## empty_tag=1 时，反馈不生效
empty_tag=0
if [[ $empty_tag -eq 0 ]]; then
    # 存放结果
    cp ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/final_ocpx_feedback_dict.txt ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt
    md5sum ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt > ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt.md5
else
    cat ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/final_ocpx_feedback_dict.txt | awk '{FS=OFS="\t"}{print $1, $2, $3, $4, $5, 1.0}' > ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt
    md5sum ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt > ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt.md5
fi

cat ${shallow_bak_dict} > ${BANK_ACCOUNT_DICT}/bank_account_dict_${cur_dayhourmin}
cat ${dt_for_bak} >> ${BANK_ACCOUNT_DICT}/bank_account_dict_${cur_dayhourmin}
cat ${deep_bak_dict} >> ${BANK_ACCOUNT_DICT}/bank_account_dict_${cur_dayhourmin}
rm -rf ${shallow_bak_dict}
rm -rf ${dt_for_bak}
rm -rf ${deep_bak_dict}

# 登录门神
#baas login --baas_user=chenjunhao02 --baas_group=baas_default_group --baas_role=baas_all_privilege
#scp ${ONLINE_DICT_V1}/flexible_ocpx_feedback_dict.txt work@bjhw-xdata-strategy00-online.bjhw.baidu.com:/home/work/chenjunhao02/dict_online/flexible_ocpx_feedback_dict_1/
#scp ${ONLINE_DICT_V1}/flexible_ocpx_feedback_dict.txt.md5 work@bjhw-xdata-strategy00-online.bjhw.baidu.com:/home/work/chenjunhao02/dict_online/flexible_ocpx_feedback_dict_1/
echo "done" > ./state/run_state.txt
echo "=======================SUCCESS====================="
