# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/07/06
Function：反馈计算
Input：   合并后的ocpx数据
          key：datehour, unitid, planid, userid, cmatch, is_ocpc_deep, trans_type, deep_trans_type
Output：  修正后的ocpx数据
          key：unitid, cmatch, coe
"""

import configparser
from datetime import datetime, timedelta
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path
from scipy.stats import binom

def load_week_dict(week_data):
    """
    功能：载入历史7天数据，为转化稀疏账户做兜底
    参数：浅层单元数据
    """

    print("Loading week data dict...", file=sys.stderr)

    today = datetime.now().strftime('%Y%m%d')
    cur_hour = datetime.now().strftime('%Y%m%d%H')
    one_hour_ago = (datetime.now() + timedelta(hours=-1)).strftime('%Y%m%d%H')
    print(today, one_hour_ago, file=sys.stderr) 

    with open(week_data, 'r') as f:
        for line in f:
            items = line.strip().split('\t')
            date, hour, unit, plan, user, cmatch, pricing_type, bid_source, is_ocpc_deep, trans_type, deep_trans_type, \
                    eshow, clk, conv, obid, tcharge, charge, bat = items
            #if int(user) % 10 not in [0,1,2,3,4,5]:
            #    continue
            eshow, clk, conv, obid, tcharge, charge, bat = map(float, [eshow, clk, conv, obid, tcharge, charge, bat])
            if cmatch in bak_cmatch and pricing_type == '0':
                charge = bat
            key = '\t'.join([user_dim, user, cmatch, trans_type, deep_trans_type])

            date_hour = date + hour.zfill(2)
            if date_hour == one_hour_ago or date_hour == cur_hour:
                continue
            if key not in week_dict:
                week_dict[key] = [0.0] * 5

            record = eshow + clk
            week_dict[key][0] += record
            week_dict[key][1] += conv
            week_dict[key][2] += obid
            week_dict[key][3] += tcharge
            week_dict[key][4] += charge

def load_unit_dict(data):
    """
    功能：载入聚合后的数据
    参数：聚合后的数据
    """

    print("Loading data dict...", file=sys.stderr)

    for line in data.strip().split("\n"):
        items = line.strip().split('\t')
        date_hour, dim, agg_dim, cmatch, trans_type, deep_trans_type, \
                record, conv, obid, tcharge, charge, coe = items

        record, conv, obid, tcharge, charge, coe = map(float, [record, conv, obid, tcharge, charge, coe])
        key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if key not in data_dict:
            data_dict[key] = [0.0] * 5

        data_dict[key][0] += record
        data_dict[key][1] += conv
        data_dict[key][2] += obid
        data_dict[key][3] += tcharge
        data_dict[key][4] += charge


def fiducial_feedback_coe(param_dict):
    """
    功能：置信反馈计算
    """

    print ("Calculating fiducial feedback coe...", file=sys.stderr)

    for key in param_dict:
        dim, agg_dim, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        record, conv, obid, tcharge, charge = param_dict[key]

        feedback_coe_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if feedback_coe_key in feedback_coe_dict:
            continue

        error, coe, tcpa = 0, 0, 0
        
        # 排除异常
        if charge <= 0.0 or conv < 0.0 or record <= 0.0:
            continue
        
        tcpa = obid / record
        if conv >= 1 and tcharge > 0:
            tcpa = tcharge / conv
        
        # 点击/曝光门槛
        if record < fiducial:
            continue
        if charge < 2 * tcpa and conv < 2:
            continue
        ## 空跑门槛
        #if conv == 0 and charge < tcpa:
        #    continue
        ## 非空跑门槛
        #if conv > 0 and charge < tcpa:
        #    continue

        # 溢出率 
        error = charge / (tcharge + eps) - 1
        error = min(error, 2)
        # 置信度
        cof = round(max(conv, charge / tcpa) / 10, 1)
        cof = max(min(cof, 1), 0)
        # 反馈系数
        STRATEGY = "NORMAL"
        if conv == 0:
            STRATEGY = "BRAKE"
        coe =  1 - cof * kp * error
        coe = round(max(min(coe, 2), 0.5), 4)

        bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if bank_key not in bank_account_dict:
            bank_account_dict[bank_key] = [STRATEGY, record, conv, tcpa, charge, tcharge, cof, kp, error, coe]

        # 异常，没赋值
        if error == 0 or coe == 0 or tcpa == 0:
            continue

        # 误差在一定范围内，不调整
        #if error >= -0.1 and error <= 0.1:
        #    coe = 1.0
        
        # 写入反馈词典
        feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, coe]))
        if feedback_coe_key not in feedback_coe_dict:
            feedback_coe_dict[feedback_coe_key] = feedback_coe_value
            print(feedback_coe_value)
        

    print ("Calculated fiducial feedback coe...", file=sys.stderr)

def output_data_dict(dict_data, file_name):
    """
    功能：输出词典
    参数：词典存储路径
    """

    with open(file_name, 'w') as f:
        for key, value in dict_data.items():
            value = '\t'.join(map(str, value))
            f.write(key + '\t' + value + '\n')
    print("save data into dict", file=sys.stderr)

# 读取配置文件
config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)
entity_dim = config["DIM"].get("ENTITY_DIM")
user_dim = config["DIM"].get("USER_DIM")
plan_dim = config["DIM"].get("PLAN_DIM")
unit_dim = config["DIM"].get("UNIT_DIM")
fiducial = int(config["FEEDBACK"].get("FIDUCIAL_THRESHOLD"))
max_coe = float(config["FEEDBACK"].get("MAX_COE"))
min_coe = float(config["FEEDBACK"].get("MIN_COE"))
kp = float(config["FEEDBACK"].get("PID_KP"))
kp_down = float(config["FEEDBACK"].get("PID_KP_DOWN"))
kp_up = float(config["FEEDBACK"].get("PID_KP_UP"))
right_levels = config["FEEDBACK"].get("RIGHT_LEVELS").split(',')
left_levels = config["FEEDBACK"].get("LEFT_LEVELS").split(',')
min_pro_global = float(config["FEEDBACK"].get("MIN_PRO"))
bak_cmatch = config["BANK_ACCOUNT"].get("BAK_CMATCH").split(',')
base_data = sys.stdin.read()
week_data = sys.argv[1]
data_for_bak = sys.argv[2]
eps = 1e-6
# 策略新增
BRAKE = "BRAKE"
NORMAL = "NORMAL"

# 全局变量
data_dict = {} # 存储当天的反馈数据
week_dict = {} # 存储七天的反馈数据
bank_account_dict = {} # 存储结果提供给bank_account使用
feedback_coe_dict = {} # 反馈词典

if __name__ == '__main__':
    load_week_dict(week_data) 
    load_unit_dict(base_data)
    fiducial_feedback_coe(data_dict)
    fiducial_feedback_coe(week_dict)
    output_data_dict(bank_account_dict, data_for_bak)
