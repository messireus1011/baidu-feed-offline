#!/bin/sh

source ~/.bashrc
source ./conf/run.conf
need_date=`date -d "3 day ago" +"%Y%m%d"`

cur_time=`date "+%Y%m%d %H %M"`
cur_day=`echo ${cur_time} | awk '{print $1}'`
cur_hour=`echo ${cur_time} | awk '{print $2}'`
cur_min=`echo ${cur_time} | awk '{print $3}'`
cur_dayhour=${cur_day}${cur_hour}
cur_dayhourmin=${cur_day}${cur_hour}${cur_min}
one_dayhour=`date -d "-1 hour" "+%Y%m%d%H"`

# 唐刚
# schema:
# 1,unitid,cmatch,ratio  
# 2,userid,cmatch,ratio
${HADOOP_CLIENT} fs -D fs.default.name=${HADOOP_DEFAULT_NAME} -D hadoop.job.ugi=${HADOOP_UGI} -cat afs://tianqi.afs.baidu.com:9902/app/ecom/native-ad-price/tanggang01/online/novel_bidratio_dict_online/novel_bidratio_list.online > ${BADCASE_DIR}/userid
# 电商
wget -O ${BADCASE_DIR}/ecom_transtype45_reach_adjust_coe.txt xafj-sys-rpm420.xafj.baidu.com:/home/users/mengwenlin/420_local_tasks/jd_unit_reach_adjust_data/ecom_transtype45_reach_adjust_coe.txt --user=work --password=EcomAds_2022
cat ${BADCASE_DIR}/ecom_transtype45_reach_adjust_coe.txt >> ${BADCASE_DIR}/userid
# 陈剑
wget -O ${BADCASE_DIR}/dianshang_user_file http://zongkong.baidu.com/home/work/zongkong/userdata/32/as_fankuixishu_set_dict/as_fankuixishu_set_dict_base.txt
cat ${BADCASE_DIR}/dianshang_user_file >> ${BADCASE_DIR}/userid

${HADOOP_CLIENT} fs -D fs.default.name=${HADOOP_DEFAULT_NAME} -D hadoop.job.ugi=${HADOOP_UGI} -cat afs:/app/ecom/native-ad-price/chenjunhao02/feedback/badcase/*.txt >> ${BADCASE_DIR}/userid

mysql="/home/work/.jumbo/bin/mysql -h 100.66.154.42 -P9030 -u admin -pfeedBd2023 -N -e" #新机器
#mysql="/home/work/.jumbo/bin/mysql -h 10.138.28.228 -P9030 -u admin -pBes_report -N -e"    #主物理机使用保定集群数据库
#mysql="/home/work/.jumbo/bin/mysql -h 10.9.96.206 -P9030 -u admin -pBes_report -N -e"    #备用：使用华南集群数据库

# 重试次数
if [ -s "${BADCASE_DIR}/userid" ];then
    $mysql "set query_timeout=120;
        select 
            distinct userid, unitid, trans_type, deep_trans_type
        from shoubai_online_data.shoubai_pay_cvt_v3
        where date > ${need_date};
    " > ${BADCASE_DIR}/user_to_unit
    if [ $? -ne 0 ]; then
        echo "gen palo data failed at ${cur_dayhourmin}"
        exit -1
    fi
fi

cat ${BADCASE_DIR}/userid | python3 script/badcase_unit.py ${BADCASE_DIR}/user_to_unit > ${BADCASE_DIR}/dict_tmp
if [[ $? -ne 0 ]];then
    echo "Failed to get badcase dict at ${cur_dayhourmin}"
    exit -1
fi

#cat ${BADCASE_DIR}/tmp90 >> ${BADCASE_DIR}/dict_tmp

cp ${BADCASE_DIR}/dict_tmp ${BADCASE_DIR}/bak/dict_${cur_dayhourmin}
mv ${BADCASE_DIR}/dict_tmp ${BADCASE_DIR}/dict
