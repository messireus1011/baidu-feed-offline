#!/usr/bin/env python
# -*- coding: utf-8-*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: predict_env.py
Author: chenjunhao02(chenjunhao02@baidu.com)
Date: 2023/06/01 10:22:24
"""

from datetime import datetime, timedelta
from argparse import _get_action_name
from hashlib import new
import numpy as np
import time
import sys
import copy
import random
import json
import torch
import configparser

eps = 1e-6
class Env(object):
    """
    env 
    """
    def __init__(self, filename, ob_dim, cur_hour):
        """
        __init__
        """
        self.ori_data = {}
        self.total_data = {}
        self.action_data = {}
        self.keys = []
        self.key_list = []
        self.file_name = filename
        self.ob_dim = ob_dim
        self.cur_hour = cur_hour
        self.load_data()
        
    def load_data(self):
        """
        # load_data
        # 查表的最终形式是 dic[uid][hour] = [系数, t-1 ~ t对应的量]
        """
        for line in open(self.file_name):
            items = line.strip().split("\t")
            # schema
            dayhour, dim, dimid, cmatch, trans_type, deep_trans_type, \
                    record, conv, obid, tcharge, charge, coe = items
            record, conv, obid, tcharge, charge, coe = map(float, [record, conv, obid, tcharge, charge, coe])

            date = dayhour[:8]
            hour = int(dayhour[8:])
            today = datetime.now().strftime('%Y%m%d')
            hour_check = self.cur_hour
            if date != today: continue
            if hour >= hour_check: continue
            #today = "20230602"
            #if cmatch != "719":
            #    continue
            # if record < 1: continue
            #if int(dimid) % 10 in [0,2]: continue
            
            key = '\t'.join([dim, dimid, cmatch, trans_type, deep_trans_type])
            
            # 总数据存放，用于筛选
            if key not in self.total_data:
                self.total_data[key] = [0.0] * 5

            self.total_data[key][0] += record
            self.total_data[key][1] += conv
            self.total_data[key][2] += obid
            self.total_data[key][3] += tcharge
            self.total_data[key][4] += charge
            # 分时数据存放，用于模型
            if key not in self.action_data:
                self.action_data[key] = [1.0] * hour_check
            if record > 0:
                self.action_data[key][hour] = coe / record
            
            # t时刻的action得到t+1时刻的量
            hour = int(hour) + 1
            if key not in self.ori_data:
                self.ori_data[key] = [[0.0] * self.ob_dim] * (hour_check + 1)
            tcpa = 0
            if record > 0:
                tcpa = obid / record
            if conv > 0 and tcharge > 0:
                tcpa = tcharge / conv

            vals = np.array([tcpa, 0.0, 0.0, 0.0, 0.0, 0.0, \
                    record, conv, charge, tcharge])
            self.ori_data[key][hour] = vals
            #print("???", key, hour, vals)
                
        #self.keys = list(self.ori_data.keys())
        #self.n = len(self.keys)
        #print('total number of user: {}'.format(self.n))

    def filter(self):
        """
        filter
        """
        for key in self.total_data:
            record, conv, obid, tcharge, charge = self.total_data[key]
            #print(key, self.total_data[key])
            # 门槛
            if charge <= 0.0 or conv < 0.0 or record < 10.0:
                continue
            tcpa = 0
            tcpa = obid / record
            if conv >= 1 and tcharge > 0:
                tcpa = tcharge / conv
            if charge < 2 * tcpa and conv < 2:
                continue
            self.key_list.append(key)
        return self.key_list

    def get_unit_key(self, index):
        """
        get_unit_key
        """
        unit_key = self.key_list[index]
        return unit_key

    def get_unit_ob(self, key):
        """
        get_unit_ob
        """
        unit_ob = self.ori_data[key]
        return unit_ob
        
    def get_unit_action(self, key):
        """
        get_unit_action
        """
        unit_action = self.action_data[key]
        return unit_action
    

    def step(self, key, t):
        """
        step
        查表得到t时刻的状态
        """
        res = self.ori_data[key][t]
        return res

    def reset(self):
        """
        reset
        """
        return np.zeros(self.ob_dim)
    
    def run_ins(self, begin, end, model, input_target_return, T):
        """
        input:
            begin, end: 样本集的起始和终止位置
            model: 调参模型
            target_return: 期望回报
        output:
            分小时的state和action, state的组建和model有关
        """
        
        act_dim = model.act_dim
        state_dim = model.state_dim
        device = model.device
        # todo
        state_mean = 0
        state_std = 1
        pre_key_list = []
        s, a, r, rtg, timesteps, mask = [], [], [], [], [], []
        for i in range(begin, end):
            state, action, reward, return_to_go, time_step = [], [], [], [], []
            # 初始空r,s,a
            ori_state = model.get_state(action, state, self.ob_dim, 0)
            state.append(ori_state)
            reward.append(0)
            return_to_go.append(input_target_return)
            time_step.append(0)
            key = self.get_unit_key(i)
            pre_key_list.append(key)
            unit_action = self.get_unit_action(key)
            unit_action = np.array(unit_action).reshape(-1, act_dim)
            unit_ob = self.get_unit_ob(key)
            # timestep从0开始，到24结束
            # 初始输入： return, state, action, time： [target_return],  [state_0], [], [0]
            # 每一轮： 
            #    action = get_action
            #    ob, r = Env.step
            #    R = R + [R[-1] - r]
            #    s, a, t = s + get_state(ob), a + [action], t + timestep
            # action和observations维度对应

            # 最终得到的是0~t时刻的序列，预测t时刻的action
            for t in range(0, T):
                action_t = unit_action[t][0]
                state_t = model.get_state(unit_action, unit_ob, self.ob_dim, t + 1)
                reward_t = model.get_reward(unit_ob, self.ob_dim, t + 1)
                state.append(state_t)
                action.append(action_t)
                reward.append(reward_t)
                cur_reward = reward[-1]
                scale = 1
                pred_return = return_to_go[-1] - (cur_reward / scale)
                return_to_go.append(pred_return)
                time_step.append(t+1)

            s.append(np.array(state).reshape(1, -1, state_dim))
            a.append(np.array(action).reshape(1, -1, act_dim))
            r.append(np.array(reward).reshape(1, -1, 1))
            rtg.append(np.array(return_to_go).reshape(1, -1, 1))
            timesteps.append(np.array(time_step).reshape(1, -1, 1))
        states = torch.from_numpy(np.concatenate(s, axis=0)).to(dtype=torch.float32, device=device)
        actions = torch.from_numpy(np.concatenate(a, axis=0)).to(dtype=torch.float32, device=device)
        rewards = torch.from_numpy(np.concatenate(r, axis=0)).to(dtype=torch.float32, device=device)
        target_return = torch.from_numpy(np.concatenate(rtg, axis=0)).to(dtype=torch.float32, device=device)
        timesteps = torch.from_numpy(np.concatenate(timesteps, axis=0)).to(dtype=torch.long, device=device)
        #print("state", states.shape, "a", actions.shape, "r", rewards.shape, "tt", target_return.shape, "ti", timesteps.shape)
        #print("state", states, "actions", actions, "rewards", rewards, "trg", target_return, "time", timesteps)
        action = model.get_action(
            (states.to(dtype = torch.float32) - state_mean) / state_std,
            actions.to(dtype = torch.float32),
            rewards.to(dtype = torch.float32),
            target_return.to(dtype = torch.float32),
            timesteps.to(dtype=torch.long),
            )
        
        return pre_key_list, action, states

