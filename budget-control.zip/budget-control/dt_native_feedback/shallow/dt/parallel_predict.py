#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: predict.py
Author: chenjunhao02(chenjunhao02@baidu.com)
Date: 2023/05/30 15:22:24
"""

import numpy as np
import time
from parallel_predict_env import Env
import copy
import json
import sys
#sys.path.append(r"/home/disk2/chenjunhao02/exp_flexible_native_feedback/shallow")
from models.dt_model import *
from pathlib import Path

np.set_printoptions(precision=3)
eps = 1e-6

if __name__ == "__main__":
    start_time = time.time()
    #base_data = sys.stdin.read()
    file_name = sys.argv[1]
    model_name = str(sys.argv[2])
    cur_hour = int(sys.argv[3]) - 1
    state_file_name = sys.argv[4]

    config = configparser.ConfigParser()
    conf_path = Path('/home/disk2/chenjunhao02/dt_native_feedback/shallow/conf/dt_model.ini')
    config.read(conf_path)
    default_config = config['DEFAULT']
    state_dim = int(default_config['state_dim'])
    act_dim = int(default_config['act_dim'])
    batch_size = int(default_config['batch_size'])

    # 初始化
    ob_dim = 10
    # 表示 tcharge - charge = 0
    return_to_go = 0
    env = Env(file_name, ob_dim, cur_hour) 
    dt_model = DTModel(state_dim, act_dim, 'cpu')
    dt_model.load_model(model_name)
    
    dic = {}
    # 预测
    key_list = env.filter()
    total_num = len(key_list)
    print("len of keys", total_num, file=sys.stderr)
    if total_num < 1:
        sys.exit()
    print("dt start", file=sys.stderr)
    iter_num = total_num // batch_size
    if total_num % batch_size != 0:
        iter_num += 1 
    for i in range(0, iter_num):
        begin = i * batch_size
        end = min(begin + batch_size, total_num)
        #print(begin, end, file=sys.stderr)
        env.run_ins(begin, end, dt_model, return_to_go, cur_hour)
        pre_key_list, actions, states = env.run_ins(begin, end, dt_model, return_to_go, cur_hour)
        
        for i in range(0, len(actions)):
            try:
                feedback_coe = actions[i].detach().cpu().numpy()[0]
            except:
                pass
            key = pre_key_list[i]
            state = states[i][-1].detach().cpu().numpy()
            cof, error = state[0], state[1]
            # 误差在一定范围内，不调整
            #if error >= 0.9 - eps and error <= 1.1 + eps:
            #    feedback_coe = 1.0
            ## 刹车处采样不充分,规则兜底
            #pid = 1 - cof * 0.7 * error
            #if pid <= 0.5 + eps:
            #    feedback_coe = 0.5
            feedback_coe = round(feedback_coe, 4)
            feedback_coe = max(min(feedback_coe, 2), 0.5)
            dim, agg_dim, cmatch, trans_type, deep_trans_type = key.split("\t")
            feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
            # 词典输出
            print(feedback_coe_value)
            # 中间结果记录
            res = feedback_coe_value
            for i in state:
                res = res + "\t" + str(i)
            dic[res] = 0
    
    with open(state_file_name, 'w') as f:
        for key in dic:
            f.write(key + '\n')
    end_time = time.time()
    print("程序运行时间：", end_time - start_time, file=sys.stderr)
