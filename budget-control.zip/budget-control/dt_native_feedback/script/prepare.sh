mkdir vrelation
mkdir cyc_res
mkdir log
mkdir user_dim_data
mkdir ocpx_feedback_dict
mkdir bank_account_dict

mkdir -r shallow/middle_data/adjust_user/
mkdir -r shallow/middle_data/agg_diff_data/
mkdir -r shallow/middle_data/aggid_map_data/
mkdir -r shallow/middle_data/conv_adjust_data/
mkdir -r shallow/middle_data/data_for_bak/
mkdir -r shallow/middle_data/dt_for_bak/
mkdir -r shallow/middle_data/ocpx_data/
mkdir -r shallow/middle_data/palo_data/
mkdir -r shallow/middle_data/week_data/

mkdir -r deep/middle_data/agg_diff_data/
mkdir -r deep/middle_data/aggid_map_data/
mkdir -r deep/middle_data/conv_adjust_data/
mkdir -r deep/middle_data/data_for_bak/
mkdir -r deep/middle_data/ocpx_data/
mkdir -r deep/middle_data/palo_data/
mkdir -r deep/middle_data/shallow_data/
