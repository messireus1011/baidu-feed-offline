# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/05/06
"""

import sys
import os

plan_data = sys.argv[1]
consume_hour_ratio_file = sys.argv[2]
week_num = int(sys.argv[3])
print("week_num:%d" % week_num, file=sys.stderr)

# 大盘流量分布
ratio_dict = {}
for line in open(consume_hour_ratio_file):
    try:
        hour, ratio = line.strip().split("\t")
        ratio_dict[int(hour)] = float(ratio)
    except:
        continue

result = {}
for line in open(plan_data, 'r', encoding='gbk'):
    items = line.strip().split("\x01\x01")
    
    plan_id = items[0]
    cyc_ori = items[5]
    if cyc_ori == "NULL":
        continue

    tmp = cyc_ori.split("\x01")[week_num]
    if week_num == 0:
        today_cyc = int(tmp.split("<")[1])
    else:
        try:
            today_cyc = int(tmp)
        except:
            continue

    ratio_left_list = []    
    ratio_sum = 0.0
    for hour in range(0, 24):
        ratio_left = round(1 - ratio_sum, 1)
        ratio_left_list.append(ratio_left)

        flag = 1 if today_cyc & (1 << (23 - hour)) > 0 else 0
        if flag == 1:
            ratio_sum += ratio_dict[hour]
    
    result[plan_id] = ratio_left_list

for key in result:
    line_str = key + "\t" + '#'.join(map(str, result[key]))
    print(line_str)
