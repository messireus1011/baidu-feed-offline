# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/05/06
"""

import sys
import os

plan_cyc = sys.stdin.read()
upu_map = sys.argv[1]

# 计划剩余流量
plan_data = {}
# user-plan-unit 映射
upu_dict = {}
user_data = {}
for line in plan_cyc.strip().split("\n"):
    items = line.strip().split('\t')
    plan, left_ratio_list = items
    plan_data[plan] = left_ratio_list
print("load plan_cyc", file=sys.stderr)

# 载入 user-plan-unit 映射
for line in open(upu_map, 'r'):
    items = line.strip().split('\t')
    user, plan, unit = items
    if plan in plan_data:
        left_ratio_list = plan_data[plan]

    # unit/plan都是有唯一映射的剩余流量
    upu_dict[unit] = left_ratio_list
    upu_dict[plan] = left_ratio_list

    # 记录一个user中所有剩余流量的出现次数
    if user not in user_data:
        user_data[user] = {}
    if left_ratio_list not in user_data[user]:
        user_data[user][left_ratio_list] = 0
    user_data[user][left_ratio_list] += 1

print("load upu case", file=sys.stderr)

# 统计user中出现频次最高的剩余流量
for user in user_data:
    high = 0
    for left_ratio_list in user_data[user]:
        count = user_data[user][left_ratio_list]
        if count > high:
            high = count
            upu_dict[user] = left_ratio_list
print("calc user high freq left raio", file=sys.stderr)

for dimid in upu_dict:
    left_ratio_list = upu_dict[dimid]
    print(dimid + "\t" + left_ratio_list)
print("save cyc res", file=sys.stderr)
