#!/bin/sh

source ~/.bashrc

set -x

vrelation_dir="/home/disk2/chenjunhao02/flexible_native_feedback/vrelation"
vrelation_file="/home/disk2/chenjunhao02/flexible_native_feedback/vrelation/vrelation.txt"

# 获取账户-实体映射
try_num=0
while [[ ${try_num} -lt 3 ]]; do
    wget -O ${vrelation_file}_tmp ftp://feed02:feed02@yy-feed02.bcc-bdbl.baidu.com/home/users/yangye03/dict_online/feed_budget/ido/user_entity_dict/vrelation.txt
    md5sum ${vrelation_file}_tmp > ${vrelation_dir}/local_vrelation.txt.md5
    wget -O ${vrelation_dir}/remote_vrelation.txt.md5 ftp://feed02:feed02@yy-feed02.bcc-bdbl.baidu.com/home/users/yangye03/dict_online/feed_budget/ido/user_entity_dict/vrelation.txt.md5
    remote=`cat ${vrelation_dir}/remote_vrelation.txt.md5 | awk '{ print $1 }'`
    loca=`cat ${vrelation_dir}/local_vrelation.txt.md5 | awk '{ print $1 }'`
    if [ "$remote" != "$loca" ];then
        if [[ ${try_num} -eq 2 ]]; then
            rm -rf ${vrelation_file}_tmp
            echo "Failed to get vrelation at `date "+%Y%m%d %H %M"`"
            exit -1
        fi
    else
        echo "doing" > ${vrelation_dir}/vrelation_state.txt
        mv ${vrelation_file}_tmp ${vrelation_file}
        echo "done" > ${vrelation_dir}/vrelation_state.txt
        echo "vrelation data is ready at `date "+%Y%m%d %H %M"`"
        break
    fi
    try_num=`expr ${try_num} + 1`
done
