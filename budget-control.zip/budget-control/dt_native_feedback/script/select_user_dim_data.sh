# 更新账户-实体映射
# 先确保没有并行在修改，否则等待2m
source ./shallow/conf/run.conf
try_num=0
while [[ ${try_num} -lt 3 ]]; do
    vrelation_state=`cat ${VRELATION_DIR}/vrelation_state.txt`
    if [ "${vrelation_state}" == "doing" ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "Failed to get vrelation data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
            echo "done" >> ./state/run_state.txt
            exit -1
        fi
        sleep 2m
    else
        echo "get vrelation"
        break
    fi
    try_num=`expr ${try_num} + 1`
done

user_dim_file=${USER_DIM_DIR}/user_dim_file

for entityid in 429285974 429138698 428976852 200272105
do
    grep $entityid ${VRELATION_FILE} | awk '{FS=OFS="\t"}{print $2}' >> ${user_dim_file}_tmp
done

mv ${user_dim_file}_tmp ${user_dim_file}
