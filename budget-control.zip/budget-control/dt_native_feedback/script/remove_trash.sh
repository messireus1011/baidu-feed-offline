#!/bin/sh

source ~/.bashrc

remove_day=`date -d "-10 day" +'%Y%m%d'`

rm -rf user_dim_data/user_dim_${remove_day}*
rm -rf shallow/middle_data/conv_adjust_data/conv_adjust_${remove_day}*
rm -rf shallow/badcase/bak/dict_${remove_day}*
rm -rf shallow/middle_data/data_for_bak/data_for_bak_${remove_day}*
rm -rf shallow/middle_data/ocpx_data/ocpx_${remove_day}*
rm -rf shallow/middle_data/palo_data/palo_${remove_day}*
rm -rf shallow/middle_data/week_data/week_${remove_day}*
rm -rf shallow/middle_data/agg_diff_data/agg_diff_${remove_day}*
rm -rf shallow/middle_data/aggid_map_data/aggid_map_${remove_day}*
rm -rf shallow/middle_data/tuiquan/bak/tuiquan_unit_${remove_day}*
rm -rf shallow/bayes_data/${remove_day}*
rm -rf shallow/bayes_data/bayes_data_${remove_day}*
rm -rf shallow/ocpx_feedback_dict/dict_${remove_day}*
rm -rf shallow/log/run_log_${remove_day}*
rm -rf shallow/ocpx_feedback_dict/dict_${remove_day}*
rm -rf shallow/ocpx_feedback_dict/learning_${remove_day}*

rm -rf deep/middle_data/data_for_bak/data_for_bak_${remove_day}*
rm -rf deep/middle_data/ocpx_data/ocpx_${remove_day}*
rm -rf deep/middle_data/palo_data/palo_${remove_day}*
rm -rf deep/middle_data/agg_diff_data/agg_diff_${remove_day}*
rm -rf deep/middle_data/conv_adjust_data/conv_adjust_${remove_day}*
rm -rf deep/middle_data/shallow_data/shallow_data_${remove_day}*
rm -rf deep/bayes_data/${remove_day}*
rm -rf deep/bayes_data/bayes_data_${remove_day}*
rm -rf deep/ocpx_feedback_dict/dict_${remove_day}*
rm -rf /home/work/chenjunhao02/crontab_job/ocpc_deep_ad_pk_ratio_dict/bak/*_${remove_day}

remove_day=`date -d "-7 day" +'%Y%m%d'`
rm -rf /home/work/zhuyuyuan/native_shallow_feedback/PID_COM/generate_data_v12/bak/bid_framework_unit_${remove_day}*
echo "remove success at ${remove_day}"
