#!/bin/sh

source ~/.bashrc

set -x

if [ $# -eq 1 ]; then
    echo "shoudong run"
    one_hour_ago=$1
else
    echo "auto run"
    one_hour_ago=`date -d "1 hour ago" +"%Y%m%d%H"`
fi
echo "begin" ${one_hour_ago}

hadoop_turing=/home/work/chenjunhao02/hadoop_turing/hadoop/bin/hadoop

output_path=userpath.unitid_bid_sum/${one_hour_ago}
storage_path=/home/disk2/chenjunhao02/new_native_feedback/turing_data/${one_hour_ago}

# 探测是否已经完成
if [ -f ${storage_path}/_SUCCESS ];then
    echo "the file exist"
    exit -1
fi

try_num=0
while [[ ${try_num} -lt 24 ]]; do
    ${hadoop_turing} fs -test -e ${output_path}/_SUCCESS
    if [ $? -ne 0 ];then
        echo "data is not ready"
        sleep 10m
        if [[ ${try_num} -eq 23 ]]; then
            echo "data is not ready in 12 hours"
            exit -1
        fi
    else
        echo "data is ready"
        break
    fi
done

mkdir ${storage_path}

try_num=0
while [[ ${try_num} -lt 3 ]]; do
    ${hadoop_turing} fs -cat ${output_path}/part-* > ${storage_path}/unitid_bid_sum
    if [ $? -ne 0 ]; then
        sleep 3m
        if [[ ${try_num} -eq 2 ]]; then
            echo "get data failed"
            exit -1
        fi
    else
        echo "get data success"
        echo "========================================"
        touch ${storage_path}/_SUCCESS
        break
    fi
done
