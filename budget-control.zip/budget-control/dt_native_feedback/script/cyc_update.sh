#!/bin/sh

source ~/.bashrc
source ./shallow/conf/run.conf

set -x
HADOOP="/home/work/majing05/hadoop/bin/hadoop"
 
dump_plan_path="afs://shaolin.afs.baidu.com:9902/user/feed_search_online/feedbs_dump_file/{0,1,2,3}/"
work_root="/home/disk2/chenjunhao02/flexible_native_feedback/cyc_res"
plan_ori=${work_root}/plan_ori
consume_hour_ratio=${work_root}/consume_hour_ratio_dict.txt
plan_cyc=${work_root}/plan_cyc
upu_map=${work_root}/upu_map
cyc_res=${work_root}/cyc_res.txt

run_state=`cat ${work_root}/cyc_res_state.txt`
if [ "${run_state}" == "doing" ]; then
    exit 0
else
    echo "last task has done, start this task"
fi

flag=0
for i in {1..23}
do
    daytime=`date -d "$i hour ago" +%Y%m%d`
    hour=`date -d "$i hour ago" +%H`
    echo $daytime
    echo $hour
    test_path=${dump_plan_path}/$daytime/$hour/PlanTable.txt.formated
    num=`$HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -ls ${test_path} | grep PlanTable.txt.formated | wc -l` 
    if [ $num -eq 4 ];then
        flag=$i
        break
    fi
done
 
if [ $flag -le 0 ];then
    echo "flag is zero"
    exit -1
fi
 
daytime=`date -d "$flag hour ago" +%Y%m%d`
hour=`date -d "$flag hour ago" +%H`
plan_file=$dump_plan_path/$daytime/$hour/PlanTable.txt.formated
$HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -text $plan_file > $plan_ori
 
plan_size=`cat $plan_ori | wc -l`
if [ $plan_size -lt 10000 ];then
    echo "plan is too small"
    exit -1
fi
 
week_num=$(((`date +%w`+6)%7))
python3 script/process_cyc.py $plan_ori $consume_hour_ratio $week_num > $plan_cyc
if [[ $? -ne 0 ]];then
    echo "Failed to get plan cyc at `date "+%Y%m%d %H %M"`"
    exit -1
fi

cur_day=`date "+%Y%m%d"`
yes_day=`date -d "-1 day $cur_day" +'%Y%m%d'`
cur_dayhour=${cur_day}' '${cur_hour}
cur_dayhourmin=${cur_day}${cur_hour}${cur_min}
#mysql="/home/work/.jumbo/bin/mysql -h 10.138.28.228 -P9030 -u admin -pBes_report -N -e"    #主物理机使用保定集群数据库
mysql="/home/work/.jumbo/bin/mysql -h 10.99.1.172 -P9030 -u admin -pBes_report -N -e"    #备用：使用华南集群数据库
$mysql "use bes_report;"

$mysql "set query_timeout=120;
    select distinct userid, planid, unitid
    from shoubai_online_data.shoubai_pay_cvt_v3
    where date in (${cur_day}, ${yes_day});
    " > $upu_map

cat $plan_cyc | python3 script/get_cyc_res.py $upu_map > ${cyc_res}_tmp
if [[ $? -ne 0 ]];then
    echo "Failed to get cyc res at `date "+%Y%m%d %H %M"`"
    exit -1
fi
echo "doing" > ${work_root}/cyc_res_state.txt
mv ${cyc_res}_tmp ${cyc_res}
echo "done" > ${work_root}/cyc_res_state.txt
echo "vrelation data is ready at `date "+%Y%m%d %H %M"`"
