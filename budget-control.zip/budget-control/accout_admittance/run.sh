
daytime=`date -d "1 day ago" +%Y%m%d`
echo $daytime

mkdir -p data/$daytime

if [ ! -d "output" ]; then
    mkdir output
fi

HADOOP=/home/users/yangye03/tools/hadoop_client/hadoop_turing/hadoop/bin/hadoop
conv_dis_path=userpath.user_conv_delay_dis/${daytime}/
conv_dis_check_file=userpath.user_conv_delay_dis/${daytime}/_SUCCESS

# check file
for ((i=0; i<15; i++))
do
    ${HADOOP} fs -test -e $conv_dis_check_file
    if [ $? -eq 0 ]; then
        break
    fi
    sleep 60m
done

# schema: userid, trans_type, deep_trans_type, convs, convs_delay 
${HADOOP} fs -text $conv_dis_path/part* > conv_dis_data

awk 'BEGIN{FS=OFS="\t"}{if($2 != 3) next; conv[$1]+=$4; conv_delay[$1]+=$5;}END{for(i in conv) print i, conv[i], conv_delay[i]}' conv_dis_data | sort -t$'\t' -k3gr > conv_dis_data_clear
awk 'BEGIN{FS=OFS="\t"}{if($2>=3 && $3*1.0/$2 > 0.2) print $0}' conv_dis_data_clear > conv_high_latency_users

if [ `cat conv_high_latency_users | wc -l ` -lt 10 ]; then
    echo "conv_high_latency_users is too small"
    exit 1
fi

md5sum conv_high_latency_users > conv_high_latency_users.md5
cp conv_high_latency_users data/$daytime
cp conv_high_latency_users.md5 data/$daytime

mv conv_high_latency_users output/
mv conv_high_latency_users.md5 output/

# clear history file
delete_day=`date -d "7 days ago" +%Y%m%d`
rm -rf data/${delete_day}

