"""
author:yangye03 
date:20221121
"""
import sys
import numpy as np
import tensorflow as tf

#!/usr/bin/env python
# coding=utf-8

def load_base_file(base_file, day_check, cmatch_check, hour_check):
    """ load base file """

    # initialization
    charge_arr = {}
    conv_arr = {}
    obid_arr = {}
    charge_T_arr = {}
    conv_T_arr = {}

    conv_obid_sum_arr = {}
    obid_sum_arr = {}
    conv_sum_arr = {}
    click_sum_arr = {}
    eshow_sum_arr = {}

    for T in range(int(hour_check) + 1):
        charge_T_arr[T] = {}
        conv_T_arr[T] = {}

    for line in open(base_file):
        try:
            items = line.strip().split("\t")
            dayhour = items[0]
            unitid = items[1]
            cmatch = items[4]
            pricing_type = items[5]
            is_ocpc_deep = items[6]
            trans_type = items[7]
            deep_trans_type = items[8]
            eshow_sum = float(items[9])
            clk_sum = float(items[10])
            conv_sum = float(items[11])
            new_conv_sum = float(items[12])
            obid_sum = float(items[13])
            conv_obid_sum = float(items[14])
            charge_sum = float(items[15])

            daytime = dayhour[:8]
            hour = int(dayhour[8:])
        except:
            continue

        if is_ocpc_deep == '1' and deep_trans_type != '28': continue

        if cmatch != cmatch_check: continue
        if daytime != day_check: continue
        if hour > hour_check: continue

        #print line
        charge_arr[unitid] = charge_arr.get(unitid, 0.0) + charge_sum
        conv_arr[unitid] = conv_arr.get(unitid, 0.0) + new_conv_sum

        if unitid not in charge_T_arr[hour]:
            charge_T_arr[hour][unitid] = 0.0
        charge_T_arr[hour][unitid] += charge_sum

        if unitid not in conv_T_arr[hour]:
            conv_T_arr[hour][unitid] = 0
        conv_T_arr[hour][unitid] += new_conv_sum

        conv_obid_sum_arr[unitid] = conv_obid_sum_arr.get(unitid, 0) + conv_obid_sum
        conv_sum_arr[unitid] = conv_sum_arr.get(unitid, 0) + conv_sum
        click_sum_arr[unitid] = click_sum_arr.get(unitid, 0) + clk_sum
        eshow_sum_arr[unitid] = eshow_sum_arr.get(unitid, 0) + eshow_sum
        obid_sum_arr[unitid] = obid_sum_arr.get(unitid, 0) + obid_sum

    # calc obid
    for unitid in charge_arr:
        if conv_sum_arr[unitid] > 0:
            obid_arr[unitid] = conv_obid_sum_arr[unitid] / conv_sum_arr[unitid]
        else:
            obid_arr[unitid] =  obid_sum_arr[unitid] / (click_sum_arr[unitid] + eshow_sum_arr[unitid])
    
    # calc T_accumulation
    for unitid in charge_arr:
        for T in range(int(hour_check) + 1):
            if unitid not in charge_T_arr[T]:
                charge_T_arr[T][unitid] = 0.0
            if unitid not in conv_T_arr[T]:
                conv_T_arr[T][unitid] = 0.0

            if T <= 0: continue
            charge_T_arr[T][unitid] = charge_T_arr[T][unitid] + charge_T_arr[T - 1][unitid]
            conv_T_arr[T][unitid] = conv_T_arr[T][unitid] + conv_T_arr[T - 1][unitid]
    
    return charge_arr, conv_arr, obid_arr, charge_T_arr, conv_T_arr

def load_cyc(file):
    """ load cyc """
    result = {}
    for line in open(file):
        try:
            plan_id, cyc_res = line.strip().split("\t")
            cyc_item = cyc_res.split("#")
            
            cyc_list = map(float, cyc_item)
            result[plan_id] = cyc_list
        except:
            continue

    return result

def load_reach_adjust_coe_avg(file, cmatch_check):
    """ load_reach_adjust_coe_avg """
    ratio_sum_arr = {}
    eshow_sum_arr = {}
    action_T_arr = {}
    for t in range(24):
        ratio_sum_arr[t] = {}
        eshow_sum_arr[t] = {}
        action_T_arr[t] = {}

    
    for line in open(file):
        try:
            items = line.strip().split("\t")
            unitid = items[0]
            cmatch = items[1]
            hour = int(items[2])
            ratio_sum = float(items[3])
            eshow_sum = float(items[4])
            
            if cmatch != cmatch_check:
                continue
            
            ratio_sum_arr[hour][unitid] = ratio_sum_arr[hour].get(unitid, 0) + ratio_sum
            eshow_sum_arr[hour][unitid] = eshow_sum_arr[hour].get(unitid, 0) + eshow_sum
        except:
            continue

    for hour in range(24):
        for unitid in ratio_sum_arr[hour]:
            if ratio_sum_arr[hour][unitid] > 0 and eshow_sum_arr[hour][unitid] > 0:
                action_T_arr[hour][unitid] = ratio_sum_arr[hour][unitid] / eshow_sum_arr[hour][unitid]

    return action_T_arr

def get_conv_norm(conv, size):
    """ get_conv_norm """
    conv_norm = round(float(conv) / float(size), 1)
    conv_norm = max(conv_norm, 0.0)
    conv_norm = min(conv_norm, 1.0)

    return conv_norm

def get_excess_ratio(conv, charge, obid):
    """ get_excess_ratio """
    ratio = 0.0
    charge = float(charge)
    conv = float(conv)
    obid = float(obid)
    tcharge = obid * conv

    if charge >= 5 * obid:
        if tcharge <= 0:
            ratio = round(charge / obid - 1, 2)
        else:
            ratio = round(charge / tcharge - 1, 2)

    ratio = round(ratio, 2)
    ratio = max(ratio, -0.5)
    ratio = min(ratio, 1.0)
    
    return ratio

def get_left_flow_ratio(cyc_rec, unitid, T):
    """ get left flow ratio """
    default_list = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.9, 0.9, 0.8, 0.8, 0.8, 0.7, 0.7, 0.6, \
            0.6, 0.5, 0.5, 0.4, 0.4, 0.3, 0.2, 0.2, 0.1]
    if unitid in cyc_rec:
        left_ratio = round(cyc_rec[unitid][int(T)], 2)
    else:
        left_ratio = round(default_list[int(T)], 2)

    return left_ratio

def get_consume_fea(unitid, charge_T_arr, T, unit_obid, size):
    """ get_consume_fea """
    unit_obid = float(unit_obid)

    result = 0.0
    if T < 1:
        result = round(float(charge_T_arr[T][unitid]) / unit_obid / size, 2)
    else:
        charge_curr_hour = float(charge_T_arr[T][unitid]) - float(charge_T_arr[T - 1][unitid])
        result = round(charge_curr_hour * 1.0 / unit_obid / size, 2)
    
    result = min(result, 1.0)
    result = max(result, 0)

    return result

def get_curr_hour(T):
    """ get_curr_hour """
    ratio = round(float(T) / 23, 2)

    return ratio


def get_curr_state_x(unit_list, state_size, conv_arr, charge_arr, obid_arr, cyc_rec, \
        T, charge_T_arr, conv_T_arr, action_T_arr):
    """ get curr state """

    state_size_real = state_size
    state = np.empty(shape=(0, state_size_real))
    for unitid in unit_list:
        unit_conv = int(conv_arr[unitid])
        unit_obid = int(obid_arr[unitid])
        unit_charge = int(charge_arr[unitid])    

        # fea1: current cv
        fea1_cv = get_conv_norm(unit_conv, 20)

        # fea2: fb_ratio
        #fea2_fb = get_feedback_ratio(unit_conv, unit_charge, unit_obid)
        fea2_fb = get_excess_ratio(unit_conv, unit_charge, unit_obid)

        # fea3: left flow ratio
        fea3_left_flow = get_left_flow_ratio(cyc_rec, unitid, T)

        # fea4: curr_hour
        fea4_curr_hour = get_curr_hour(T)
        
        # fea5: action_list
        # if no consume, default 1.0
        fea5_action_1 = 1.0 if T - 1 < 0 else action_T_arr[T - 1].get(unitid, 1.0)
        fea5_action_2 = 1.0 if T - 2 < 0 else action_T_arr[T - 2].get(unitid, 1.0)
        fea5_action_3 = 1.0 if T - 3 < 0 else action_T_arr[T - 3].get(unitid, 1.0)
        fea5_action_4 = 1.0 if T - 4 < 0 else action_T_arr[T - 4].get(unitid, 1.0)
        fea5_action_5 = 1.0 if T - 5 < 0 else action_T_arr[T - 5].get(unitid, 1.0)
        fea5_action_6 = 1.0 if T - 6 < 0 else action_T_arr[T - 6].get(unitid, 1.0)

        fea6_fb_1 = 0.0 if  T - 1 < 0 else get_excess_ratio(conv_T_arr[T - 1][unitid], \
                charge_T_arr[T - 1][unitid], unit_obid)
        fea6_fb_2 = 0.0 if  T - 2 < 0 else get_excess_ratio(conv_T_arr[T - 2][unitid], \
                charge_T_arr[T - 2][unitid], unit_obid)
        fea6_fb_3 = 0.0 if  T - 3 < 0 else get_excess_ratio(conv_T_arr[T - 3][unitid], \
                charge_T_arr[T - 3][unitid], unit_obid)
        fea6_fb_4 = 0.0 if  T - 4 < 0 else get_excess_ratio(conv_T_arr[T - 4][unitid], \
                charge_T_arr[T - 4][unitid], unit_obid)
        fea6_fb_5 = 0.0 if  T - 5 < 0 else get_excess_ratio(conv_T_arr[T - 5][unitid], \
                charge_T_arr[T - 5][unitid], unit_obid)
        fea6_fb_6 = 0.0 if  T - 6 < 0 else get_excess_ratio(conv_T_arr[T - 6][unitid], \
                charge_T_arr[T - 6][unitid], unit_obid)

        # fea7: consume_list get_consume_fea(charge_T_arr, T, unit_obid, size):
        fea7_consume_1 = 0.0 if T - 1 < 0 else get_consume_fea(unitid, charge_T_arr, T - 1, unit_obid, 5)
        fea7_consume_2 = 0.0 if T - 2 < 0 else get_consume_fea(unitid, charge_T_arr, T - 2, unit_obid, 5)
        fea7_consume_3 = 0.0 if T - 3 < 0 else get_consume_fea(unitid, charge_T_arr, T - 3, unit_obid, 5)
        fea7_consume_4 = 0.0 if T - 4 < 0 else get_consume_fea(unitid, charge_T_arr, T - 4, unit_obid, 5)
        fea7_consume_5 = 0.0 if T - 5 < 0 else get_consume_fea(unitid, charge_T_arr, T - 5, unit_obid, 5)
        fea7_consume_6 = 0.0 if T - 6 < 0 else get_consume_fea(unitid, charge_T_arr, T - 6, unit_obid, 5)


        state = np.append(state, [[fea1_cv, fea2_fb, fea3_left_flow, fea4_curr_hour, \
            fea5_action_1, fea5_action_2, fea5_action_3, fea5_action_4, fea5_action_5, fea5_action_6, \
            fea6_fb_1, fea6_fb_2, fea6_fb_3, fea6_fb_4, fea6_fb_5, fea6_fb_6, \
            fea7_consume_1, fea7_consume_2, fea7_consume_3, fea7_consume_4, fea7_consume_5, fea7_consume_6]], axis=0)
    
    state = state.astype('float32')
    
    #print ("state value")
    #print state
    return state

def get_unit_list(charge_arr, obid_arr, check_num):
    """ get_unit_list """
    unit_list = []
    for unitid in charge_arr:
        charge = charge_arr[unitid]
        obid = obid_arr.get(unitid, 0)
        if obid > 0 and charge > (check_num * obid):
            unit_list.append(unitid)
    
    return unit_list


if __name__ == '__main__':
    base_file = sys.argv[1]
    cyc_file = sys.argv[2]
    reach_file = sys.argv[3]
    day_check = sys.argv[4]
    hour_check = int(sys.argv[5])
    cmatch_check = sys.argv[6]

    charge_arr, conv_arr, obid_arr, charge_T_arr, conv_T_arr = load_base_file(base_file, \
            day_check, cmatch_check, hour_check)
    cyc_rec = load_cyc(cyc_file)
    action_T_arr = load_reach_adjust_coe_avg(reach_file, cmatch_check)

    print "check"
    print len(charge_arr)
    print len(charge_T_arr)
    print len(cyc_rec)
    print len(action_T_arr)

    # generate state
    state_size = 22
    check_num = 5
    unit_list = get_unit_list(charge_arr, obid_arr, check_num)
    #print "unit_list"
    #print unit_list
    state = get_curr_state_x(unit_list, state_size, conv_arr, charge_arr, obid_arr, cyc_rec, \
        hour_check, charge_T_arr, conv_T_arr, action_T_arr)

    # load model
    meta_path = "./model_conv/17000/my-model.meta"
    model_path= "./model_conv/17000/"

    graph = tf.Graph()
    saver = tf.train.import_meta_graph(meta_path, graph=graph)
    sess = tf.Session(graph = graph)
    ckpt = tf.train.latest_checkpoint(model_path)
    saver.restore(sess, ckpt)

    s = graph.get_operation_by_name('s').outputs[0]

    result_file_path = "./unit_action_" + str(cmatch_check) + ".txt"
    result_f = open(result_file_path, 'w')
    # predict
    num = 0
    for index in range(len(unit_list)):
        unitid = unit_list[index]

        feed_dict = {s:[state[index]]}
        a1 = graph.get_tensor_by_name("Actor/eval/a/Tanh:0")
        a2 = graph.get_tensor_by_name("Actor/eval/add:0")
        [[p1]], [[p2]] = sess.run([a1, a2], feed_dict=feed_dict)
        action_value = p2
    
        # action check
        
        line = '\t'.join(map(str, ["1", unitid, cmatch_check, action_value]))
        if num == 0:
            result_f.write(line)
        else:
            result_f.write("\n" + line)   
        num = num + 1




