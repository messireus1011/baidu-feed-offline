# author:yangye03
# time: 20221120

HADOOP="/home/users/yangye03/tools/hadoop_client/cornac-client/hadoop/bin/cornac"
PYTHON="/home/users/yangye03/.jumbo/bin/python"
MYSQL="/home/users/yangye03/.jumbo/bin/mysql"

daytime=`date +%Y%m%d`
hour=`date +%H`

# fetch cyc file
wget ftp://feed02:feed02@yy-feed02.bcc-bdbl.baidu.com//home/users/yangye03/dict_online/bid_learning/cyc_process/unit_cyc -O unit_cyc
size1=`cat unit_cyc | wc -l`
if [ $size1 -lt 1000 ];then
    echo "unit_cyc is too small"
    exit -1
fi

# fetch reach file
mysql_str="select unitid, cmatch, hour, sum(reach_adjust_coe) as ratio_sum, sum(page_views+clicks) as eshow_sum from shoubai_pay_cvt_new where date= '${daytime}' and cmatch in ('545', '719', '669') and (is_ocpc_deep = 0 or deep_trans_type='28') group by 1, 2, 3;"
${MYSQL} -h 10.138.28.235 -P9030 -u admin -pBes_report -D bes_report -s -e "$mysql_str" > reach_file
size2=`cat reach_file | wc -l`
if [ $size2 -lt 1000 ];then
    echo "reach_file is too small"
    exit -1
fi

# fetch base file
minutes="10"
base_file_name="afs:/app/ecom/native-ad-price/chenjunhao02/feedback/conv_adjust_data/conv_adjust_${daytime}${hour}${minutes}"

try_times=15
num=0
file_exist=0
while [ $num -lt $try_times ]
do
    echo "$num"
    ${HADOOP} fs -test -e ${base_file_name}
    if [ $? == 0 ];then
        file_exist=1
        break
    fi
    let num++
    sleep 60s
done

if [ $file_exist -eq 0 ];then
    echo "base file not exists, exit"
    exit -1
fi

${HADOOP} fs -text ${base_file_name} > base_file
size3=`cat base_file | wc -l`
if [ $size3 -lt 1000 ];then
    echo "base_file is too small"
    exit -1
fi

# generate_action_file
#action_file="unit_action_545.txt"
#select_unit="check_unit"
#awk 'BEGIN{FS=OFS="\t"}ARGIND==1{rec[$1]=1}ARGIND==2{if($2 in rec) {ratio = $4; if(ratio < 0.7) ratio = 0.7; if(ratio > 1.3) ratio = 1.3; print $1,$2,$3,ratio}}' $select_unit  $action_file > exp_unit

# 669
action_file_669="unit_action_669.txt"
${PYTHON} process.py "base_file" "unit_cyc" "reach_file" $daytime $hour "669"

awk 'BEGIN{FS=OFS="\t"}{if(1) {ratio = $4; if(ratio < 0.5) ratio = 0.5; if(ratio > 2.0) ratio = 2.0; print $1,$2,$3,ratio}}' $action_file_669 > exp_unit_669

# 545
action_file_545="unit_action_545.txt"
${PYTHON} process.py "base_file" "unit_cyc" "reach_file" $daytime $hour "545"

awk 'BEGIN{FS=OFS="\t"}{if(1) {ratio = $4; if(ratio < 0.5) ratio = 0.5; if(ratio > 2.0) ratio = 2.0; print $1,$2,$3,ratio}}' $action_file_545 > exp_unit_545

# 545
action_file_719="unit_action_719.txt"
${PYTHON} process.py "base_file" "unit_cyc" "reach_file" $daytime $hour "719"

awk 'BEGIN{FS=OFS="\t"}{if(1) {ratio = $4; if(ratio < 0.5) ratio = 0.5; if(ratio > 2.0) ratio = 2.0; print $1,$2,$3,ratio}}' $action_file_719 > exp_unit_719

cat exp_unit_669 exp_unit_545 exp_unit_719 > exp_unit

cp exp_unit exp_unit.$daytime$hour


# put to afs
put_path=afs:/app/ecom/native-ad-price/chenjunhao02/feedback/bid_learning/
${HADOOP} fs -rm afs:/app/ecom/native-ad-price/chenjunhao02/feedback/bid_learning/exp_unit.$daytime$hour
${HADOOP} fs -put exp_unit.$daytime$hour afs:/app/ecom/native-ad-price/chenjunhao02/feedback/bid_learning/
rm exp_unit.$daytime$hour

delete_day=`date -d "30 days ago" +%Y%m%d`
${HADOOP} fs -rm afs:/app/ecom/native-ad-price/chenjunhao02/feedback/bid_learning/exp_unit.${delete_day}*






