
turingh=/home/users/pengdahao/tools/turing-client/hadoop/bin/hadoop

${turingh} fs -cat userpath.material_allocation_bid_ratio_dict/material_allocation_bid_ratio_dict.txt > allocation_res
#awk 'BEGIN{FS=OFS="\t"}{print $1, $2, $3, $4, 1+($5-1)*0.8;}' allocation_res > allocation_res2

${turingh} fs -cat userpath.material_allocation_dict_exp/material_allocation_bid_ratio_dict.txt > explore_res

num1=`cat allocation_res | wc -l`
num2=`cat explore_res | wc -l`

echo $num1
echo $num2

if [ $num1 -lt 1000 ];then
    echo "allocation_res is too small"
    exit
fi

if [ $num2 -lt 1000 ];then
    echo "explore_res is too small"
    exit
fi

awk 'BEGIN{FS=OFS="\t"}ARGIND==1{key=$1"\t"$2"\t"$3;rec[key]=1}ARGIND==2{key2=$1"\t"$2"\t"$3;if(!(key2 in rec)) print $0}' allocation_res explore_res > explore_add_material

cat explore_add_material allocation_res | awk 'BEGIN{FS=OFS="\t"}{print $0}' > merge_alloc_explore_res

${turingh} fs -rm userpath.material_allocation_bid_ratio_dict/material_allocation_bid_ratio_dict.txt
${turingh} fs -put merge_alloc_explore_res  userpath.material_allocation_bid_ratio_dict/material_allocation_bid_ratio_dict.txt
