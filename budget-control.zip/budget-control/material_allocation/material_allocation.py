#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  7 13:45:21 2023

@author: yangye03
"""

import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
from scipy.optimize import curve_fit
from scipy.optimize import minimize
import numpy as np
import warnings
import math

def process_idea_sign_data(file):
    """ fetch the map of idea_videsign"""
    print ("start process idea sign data")
    map_idea_sign = {}
    for line in open(file):
        try:
            com_idea_id, video_sign = line.strip().split("\t")
            map_idea_sign[com_idea_id] = video_sign
        except:
            continue
    print ("end process idea sign data")
    return map_idea_sign

def process_post_data(file):
    """ fetch sign post status """
    print ("start process post data")
    post_results_unit = {}
    post_results_unit_sign = {}
    for line in open(file):
        if len(line.strip().split("\t")) != 7:
            continue
        cmatch, unit_id, video_sign, click, price, conv, ocpc_bid = line.strip().split("\t")
        key_unit = cmatch + "_" + unit_id
        key_unit_sign = cmatch + "_" + unit_id + "_" + video_sign
    
        if key_unit not in post_results_unit:
            post_results_unit[key_unit] = {}
            post_results_unit[key_unit]['price'] = 0.0
            post_results_unit[key_unit]['conv'] = 0.0
        post_results_unit[key_unit]['price'] += float(price)
        post_results_unit[key_unit]['conv'] += float(conv)
    
        if key_unit_sign not in post_results_unit_sign:
            post_results_unit_sign[key_unit_sign] = {}
            post_results_unit_sign[key_unit_sign]['price'] = 0.0
            post_results_unit_sign[key_unit_sign]['conv'] = 0.0
            post_results_unit_sign[key_unit_sign]['cnt'] = 0.0
            post_results_unit_sign[key_unit_sign]['obid'] = 0.0
        
        post_results_unit_sign[key_unit_sign]['price'] += float(price)
        post_results_unit_sign[key_unit_sign]['conv'] += float(conv)
        post_results_unit_sign[key_unit_sign]['cnt'] += 1
        post_results_unit_sign[key_unit_sign]['obid'] += float(ocpc_bid)

    print ("end process post file")
    return [post_results_unit, post_results_unit_sign] 

def process_simulation_data(file, map_idea_sign):
    """ fetch the original map of cpa_conv """
    print ("start process simulation data")
    results = {}
    sucess_results = {}
    for line in open(file):
        if len(line.strip().split("\t")) != 10:
            continue

        event_day, cmatch, user_id, unit_id, com_idea_id, is_win, bucket, ctrq, price, convq = \
                        line.strip().split("\t")
    
        if com_idea_id not in map_idea_sign:
            continue
        video_sign = map_idea_sign[com_idea_id]
        
        key_unit = cmatch + "_" + unit_id
        if key_unit not in results:
            results[key_unit] = {}
            sucess_results[key_unit] = {}
        
        if video_sign not in results[key_unit]:
            results[key_unit][video_sign] = []
            sucess_results[key_unit][video_sign] = [0, 0, 0, 0] # price, conv, cnt, cpa
    
        # add the original cpa conv
        conv = float(convq)/1000000
        if conv <= 0: 
            continue
        price = float(price)/100
        cpa = price / conv
        results[key_unit][video_sign].append([cpa, conv])
    
        # record charge and conv for success ads
        if is_win == '1':
            sucess_results[key_unit][video_sign][0] += price
            sucess_results[key_unit][video_sign][1] += conv
            sucess_results[key_unit][video_sign][2] += 1
    
    print ("end process simulation data")
    return [results, sucess_results]

def process_results(results, sucess_results, post_results_unit_sign):
    """ sort, accumulation, normalization """
    print ("start process results")
    for key_unit in results:
        for video_sign in list(results[key_unit].keys()):
            if video_sign not in sucess_results[key_unit]:
                res = results[key_unit].pop(video_sign)
                continue
            if sucess_results[key_unit][video_sign][0] <= 0:
                res = results[key_unit].pop(video_sign)
                continue
            if sucess_results[key_unit][video_sign][1] <=0:
                res = results[key_unit].pop(video_sign)
                continue
            if sucess_results[key_unit][video_sign][2] <= 10:
                res = results[key_unit].pop(video_sign)
                continue
        
            # if there is not enough post conv, skip
            post_conv_threshold = 3
            key_unit_sign = key_unit + "_" + video_sign
            if key_unit_sign not in post_results_unit_sign:
                res = results[key_unit].pop(video_sign)
                continue
            if post_results_unit_sign[key_unit_sign]['conv'] < post_conv_threshold:
                res = results[key_unit].pop(video_sign)
                continue
            
            success_cpa = sucess_results[key_unit][video_sign][0] / \
                            sucess_results[key_unit][video_sign][1]
            sucess_results[key_unit][video_sign][3] = success_cpa
        
            def less_than_2obid(x):
                """ filter less_than_2obid """
                return x[0] < 2 * success_cpa
            results[key_unit][video_sign] = \
                    list(filter(less_than_2obid, results[key_unit][video_sign]))
        
            # sort and accumulate
            results[key_unit][video_sign] = sorted(results[key_unit][video_sign], \
                key = lambda x:x[0], reverse=False)
            results[key_unit][video_sign] = [[results[key_unit][video_sign][x][0], \
                sum(results[key_unit][video_sign][y][1] for y in range(0, x + 1))] if x > 0 else \
                [results[key_unit][video_sign][0][0], results[key_unit][video_sign][0][1]] \
                for x in range(0, len(results[key_unit][video_sign]))]
        
            # normalization
            x_base = success_cpa
            #y_base = post_results_unit_sign[key_unit_sign]['conv']
            y_base = list(map(max, *(results[key_unit][video_sign])))[1]
            results[key_unit][video_sign] = [[results[key_unit][video_sign][x][0] / x_base, \
                results[key_unit][video_sign][x][1] / y_base] \
                for x in range(0, len(results[key_unit][video_sign]))]
        
    print ("end process results")
    return [results, sucess_results]

def process_curve_fit(results, sucess_results, post_results_unit_sign):
    """ fetch curve_fit_results """
    print ("start process_curve_fit")
    
    visit_num = 0
    model_num = 0
    model_results = {}
    for key_unit in results:
        for video_sign in list(results[key_unit].keys()):
            key_unit_sign = key_unit + "_" + video_sign
        
        
            # fetch the model params:[a, b, c]           
            x_data = [results[key_unit][video_sign][x][0] for x in range(0, len(results[key_unit][video_sign]))]
            y_data = [results[key_unit][video_sign][y][1] for y in range(0, len(results[key_unit][video_sign]))]

        
            def model(x, a, b, c):
                """ model """
                """ p0 = [1, 1, 1] """
                y = a * np.exp(x) / (1 + b * np.exp(x)) - 0.5 * c
                return y
        
            def model_v2(x, a, b, c):
                """ model_v2 """
                """ p0 = [-5.0, 5.0, 1.0] """
                a, b, c = np.array([a, b, c]).astype('float64')
                x = np.array(x).astype('float64')
                y = (1 + np.exp(a + b)) * c / (1 + np.exp(a * x + b))
                return y

        
            visit_num += 1
            model_num += 1
            try:
                #parmams, pcov = curve_fit(model, x_data, y_data, p0=[1, 1, 1])
                parmams, pcov = curve_fit(model_v2, x_data, y_data, p0=[-5.0, 5.0, 1.0])
                [a, b, c]  = parmams
            
                # record params
                if key_unit not in model_results:
                    model_results[key_unit] = {}
                model_results[key_unit][video_sign] = [a, b, c, 1.0]
            
                #adjust by post conv
                conv_predict = model_v2(1.0, *parmams)
                conv_post = post_results_unit_sign[key_unit_sign]['conv']
                adjust_ratio = conv_post * 1.0 / conv_predict
                model_results[key_unit][video_sign][3] = adjust_ratio
            
            except:
                model_num -= 1
                print ("curve fit failed")
                continue

    print ("end process_curve_fit model visit:%d sucess:%d" % (visit_num, model_num))
    return model_results

def process_material_allocation(model_results, post_results_unit_sign):
    """ process_material_allocation """
    mt_alloc_results = {}
    for key_unit in model_results:
        mt_num = len(model_results[key_unit])
        if  mt_num < 2:
            continue
        
        cost_unit_post = 0.0
        conv_unit_post = 0.0
        cnt_unit_post = 0.0
        obid_unit_post = 0.0
        for video_sign in model_results[key_unit]:
            key_unit_sign = key_unit + "_" + video_sign
            cost_unit_post += post_results_unit_sign[key_unit_sign]['price']
            conv_unit_post += post_results_unit_sign[key_unit_sign]['conv']
            cnt_unit_post += post_results_unit_sign[key_unit_sign]['cnt']
            obid_unit_post += post_results_unit_sign[key_unit_sign]['obid']
        cpa_unit_post = cost_unit_post * 1.0 / conv_unit_post
        obid_unit_post = obid_unit_post * 1.0 / 100 / cnt_unit_post
 
        if cpa_unit_post > obid_unit_post * 1.2:
            cpa_unit_post = obid_unit_post * 1.2
        if cpa_unit_post < obid_unit_post * 0.8:
            cpa_unit_post = obid_unit_post * 0.8
    
        def model_adjust(x, a, b, c, d):
            """ mode _adjust """
            y = (a * np.exp(x) / (1 + b * np.exp(x)) - 0.5 * c) * d

            return y
             
        def model_adjust_v2(x, a, b, c, d):     
            """ model_adjust_v2 """
            a, b, c, d = np.array([a, b, c, d]).astype('float64')
            x = np.array(x).astype('float64')
            y = ((1 + np.exp(a + b)) * c / (1 + np.exp(a * x + b))) * d
            return y
    
        # object function
        def objective(x):
            """ objective """
            #print ("objective")
            cv_expect = 0.0
            index = 0
            for video_sign in model_results[key_unit]:
                [a, b, c, d] = model_results[key_unit][video_sign]
                cv_predict = model_adjust_v2(x[index], a, b, c, d)
                cv_expect = cv_expect + cv_predict * 1.0
                index += 1
            #print (cv_expect)
            return -cv_expect
    
        # constraints: cpa_post >= cpa_predict
        def cons_cpa(x):
            """ cons_cpa"""
            # compute post cpa
            #print ("cons_cpa")
            #print(obid_unit_post)
            #print(cpa_unit_post)
        
            cv_unit_expect = 0.0
            cost_unit_expect = 0.0
            index = 0
            for video_sign in model_results[key_unit]:
                key_unit_sign = key_unit + "_" + video_sign
                cpa_sign_post = post_results_unit_sign[key_unit_sign]['price'] * 1.0 / \
                    post_results_unit_sign[key_unit_sign]['conv']
            
                [a, b, c, d] = model_results[key_unit][video_sign]
                print(model_results[key_unit][video_sign])
                cv_predict = model_adjust_v2(x[index], a, b, c, d)
                #print ("x:%f cpa_predict:%f cv_predict:%f" % (x[index], cpa_sign_post *x[index],  cv_predict))
                cv_unit_expect += cv_predict
                cost_unit_expect += (cv_predict * cpa_sign_post * x[index])
                index += 1
            
            cpa_unit_predict = cost_unit_expect * 1.0 / cv_unit_expect
            #print ("cpa_post:%f cpa_predict:%f cv_predict:%f" % (cpa_unit_post, cpa_unit_predict, cv_unit_expect))
            return cpa_unit_post - cpa_unit_predict
    
        cons_cpa_res = ({'type': 'ineq', 'fun': cons_cpa},)
   
        # boundary_conds 
        bnds = []
        boundary_conds = (0.7, 1.3)
        for i in range(0, len(model_results[key_unit])):
            bnds.append(boundary_conds)

        # fetch the solution
        x0 = [1.0] * mt_num
        solution = minimize(objective, x0, constraints=cons_cpa_res, bounds=bnds, \
                    method='SLSQP', options={'maxiter':100000,})
        #print(solution)
    
        if (solution.success == True):
            if key_unit not in mt_alloc_results:
                mt_alloc_results[key_unit] = {}
        
            index = 0
            for video_sign in model_results[key_unit]:
                mt_alloc_results[key_unit][video_sign] = solution.x[index]
                index += 1

    print ("process_material_allocation")
    return mt_alloc_results    

def run():
    """ run """
    file_idea_sign = "./idea_sign_map"
    file_post_data = "./post_data"
    file_cpa_conv_ori = "./simulation_data"
    map_idea_sign = process_idea_sign_data(file_idea_sign)
    [post_results_unit, post_results_unit_sign] = process_post_data(file_post_data)
    [results, sucess_results] = process_simulation_data(file_cpa_conv_ori, map_idea_sign)
    [results, sucess_results] = process_results(results, sucess_results, post_results_unit_sign)
    model_results = process_curve_fit(results, sucess_results, post_results_unit_sign)
    mt_alloc_results = process_material_allocation(model_results, post_results_unit_sign)

    f_out = open("./obid_charge_cmatch_correct.txt", 'w')
    num = 0
    for key_unit in mt_alloc_results:
        for video_sign in mt_alloc_results[key_unit]:
            cmatch, unit = key_unit.strip().split("_")
            ratio = mt_alloc_results[key_unit][video_sign]
            res_str = "\t".join(map(str, [cmatch, unit, video_sign, "1.0", ratio]))
            
            if num == 0:
                f_out.write(res_str)
            else:
                f_out.write("\n" + res_str)
            num += 1
    f_out.close()

if __name__ == '__main__':
    run()
