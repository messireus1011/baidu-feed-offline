!/bin/bash
if [ $# -lt 2 ];then
    DATE=`date +%Y%m%d`
else
    DATE=$1
fi
DATE_9D_AGO=`date +%Y%m%d -d "${DATE} 9 days ago"`
MYSQL="/home/disk1/liuguangze/.jumbo/bin/mysql"

cd shell_T3
sh run.sh ${DATE}
sh sql.sh ${DATE}
sh key.sh ${DATE}
cd ..

cd shell_T14
sh run.sh ${DATE}
sh sql.sh ${DATE}
cd ..
# for i in 0518 0519 0520 0521 0522 0523 0524 0525 0526 0527 0528 0529 0530 0531 0601 0602 0603 0604 0605 0606 0607 0608 0609 0610 0611 0612 0613 0614 0615 0616
# do 
#     echo "Running ${i}"
#     sh key.sh ${i}
# done
