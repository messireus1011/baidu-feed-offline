#!/bin/bash
DATE=$1
DATE_2D_AGO=`date +%Y%m%d -d "${DATE} 2 days ago"`
DATE_5D_LATER=`date +%Y%m%d -d "${DATE} 5 days"`
DATE_9D_AGO=`date +%Y%m%d -d "${DATE} 9 days ago"`
MYSQL="/home/disk1/liuguangze/.jumbo/bin/mysql"
echo "today: $DATE, data date: $DATE_2D_AGO, earliest created: ${DATE_9D_AGO}, latest created: ${DATE_5D_LATER}"
echo "Dealing with sql..."


# 重点客户
# schema: 账户id, video_url, 探索比例，失效日期，客户名称
rm ./material_explore_white_data.txt
wget http://zongkong.baidu.com/home/work/zongkong/userdata/8/material_explore_white/material_explore_white_data.txt

# 修改编码格式为utf-8
vim material_explore_white_data.txt << EOF
:set fileencoding=utf-8
:wq
EOF

# 将视频url转为视频id
python create_sign.py

${MYSQL} -u root -p1027685358nadv sugar << EOF

drop view if exists distinct_video;
drop view if exists distinct_key_customers;
drop view if exists today_total;

drop table if exists key_customers;
create table if not exists key_customers(userid bigint(20) not null, video_sign varchar(100) not null, explore_ratio decimal(3,2) not null, create_date date not null, exp_time date not null,username varchar(30) not null, primary key(userid, video_sign, create_date));
LOAD DATA LOCAL INFILE './key_customers_video_sign.txt' INTO TABLE key_customers FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n' ;

create view today_total as select event_day, program_video_sign, id_type, merge_conv_num, charge, merge_tcharge from monitor_material_explore where event_day=${DATE_2D_AGO};

create table distinct_video(event_day date not null, program_video_sign varchar(100) not null, charge decimal(15,8) default 0, video_conv bigint(10) default 0, is_explore int(1), primary key(program_video_sign)) as
select event_day, program_video_sign, sum(charge) as charge, sum(merge_conv_num) as video_conv, max(id_type) as is_explore from today_total where program_video_sign is not null group by program_video_sign;

create table distinct_key_customers(video_sign varchar(100) not null, username varchar(30) not null, create_date date, primary key(video_sign, username)) as
select video_sign, username, min(create_date) as create_date from key_customers group by 1, 2;
 
delete from distinct_key_customers where create_date < ${DATE_9D_AGO};
delete from distinct_key_customers where create_date > ${DATE_5D_LATER};

insert into explore_key_customers 
select t1.username as username, t1.create_date as create_date, IFNULL(t2.event_day, ${DATE_2D_AGO}) as event_day, sum(IFNULL(t2.video_conv, 0)) as conv, sum(IFNULL(t2.charge, 0)) as charge
from distinct_key_customers t1 
left join distinct_video t2 
on t2.program_video_sign = t1.video_sign
group by 1,2,3
on duplicate key update conv=conv+values(conv), charge=charge+values(charge);

drop table if exists distinct_video;
drop table if exists distinct_key_customers;
drop view if exists today_total;
EOF