export HADOOP="/home/disk1/liuguangze/hadoop_client/native-video-client/hadoop/bin/hadoop"

# ========================= config start =========================
DUMP_VIDEO_SIGN="afs://shaolin.afs.baidu.com:9902/user/turing_dataflow/ecom/liuguangze/dump_video_sign"
ATQ_INPUT="afs://cnw-xa-main.afs.baidu.com:9902/user/native-video/wangyingting/video_inte_score_opre_o"
# ========================= config end ===========================

set -x

DATE=$1
DATE_3D_AGO=`date +%Y%m%d -d "${DATE} 3 days ago"`

# dump
rm ./data/dump_video_sign
${HADOOP} fs -getmerge ${DUMP_VIDEO_SIGN}/${DATE}/23 ./data/dump_video_sign

# T+3
rm ./data/new_video_sign
mysql -hxafj-sys-rpm569.xafj.baidu.com -uroot -Dnad_video_data -p'wpj@mysql' -P3306 nad_video_data -e "select video_sign from coldboot_video_sign where date between ${DATE_3D_AGO} and ${DATE}" > ./data/new_video_sign

# atq
rm ./data/atq
DATE_ATQ=`${HADOOP} fs -ls ${ATQ_INPUT}/*/_SUCCESS | tail -1 | awk -F'/' '{print $(NF-1)}'`
${HADOOP} fs -get ${ATQ_INPUT}/${DATE_ATQ}/data_${DATE_ATQ} ./data/atq

# 优质新物料
python gen_user_video_sign.py > ./output/high_quality_new.${DATE}

# 优质物料
python gen_high_quality_material.py > ./output/high_quality.${DATE}
