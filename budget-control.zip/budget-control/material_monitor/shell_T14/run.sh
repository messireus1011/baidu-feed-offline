#! /bin/bash
# DATE = $1
DATE_2D_AGO=`date +%Y%m%d -d "$1 2 days ago"`
DATE_16D_AGO=`date +%Y%m%d -d "$1 16 days ago"`

# 获取新物料
rm ./new_video_sign/new_video_sign.${DATE_2D_AGO}
mysql -hxafj-sys-rpm569.xafj.baidu.com -uroot -Dnad_video_data -p'wpj@mysql' -P3306 nad_video_data -e "select video_sign, time from coldboot_video_sign where date between ${DATE_16D_AGO} and ${DATE_2D_AGO}" > ./new_video_sign/new_video_sign.${DATE_2D_AGO}

# 获取优质新物料和优质物料
# schema：userid， video_sign
rm ./high_quality_new/high_quality_new.${DATE_2D_AGO}
sh ./extract.sh ${DATE_2D_AGO}

cp ./output/high_quality.${DATE_2D_AGO} ./high_quality
cp ./output/high_quality_new.${DATE_2D_AGO} ./high_quality_new

