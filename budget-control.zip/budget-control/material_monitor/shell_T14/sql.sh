#!/bin/bash
DATE=$1
DATE_2D_AGO=`date +%Y%m%d -d "${DATE} 2 days ago"`
MYSQL="/home/disk1/liuguangze/.jumbo/bin/mysql"
echo "today: $DATE, data date: $DATE_2D_AGO"
echo "Dealing with sql..."
${MYSQL} -u root -p1027685358nadv sugar << EOF

drop view if exists hqn_expl;
drop view if exists new_m;
drop view if exists hqn;
drop table if exists expl;
drop table if exists hq;

drop table if exists new_material;
create table if not exists new_material(video_sign varchar(30) not null, time datetime not null, primary key(video_sign, time));
# drop first line
LOAD DATA LOCAL INFILE './new_video_sign/new_video_sign.${DATE_2D_AGO}' INTO TABLE new_material FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n' IGNORE 1 LINES;

drop table if exists high_quality_new_material;
drop table if exists high_quality_material;
create table if not exists high_quality_new_material(userid int, video_sign varchar(100) not null, primary key(userid, video_sign));
create table if not exists high_quality_material(userid int, video_sign varchar(100) not null, primary key(userid, video_sign));
LOAD DATA LOCAL INFILE './high_quality_new/high_quality_new.${DATE_2D_AGO}' INTO TABLE high_quality_new_material FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n';
LOAD DATA LOCAL INFILE './high_quality/high_quality.${DATE_2D_AGO}' INTO TABLE high_quality_material FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n';

create table if not exists explore_material_overall_T14(event_day date not null, expl_ratio decimal(5,4), expl_num bigint(20), expl_mcharge_ratio decimal(5,4), hqn_expl_mcharge_to_expl_mcharge_ratio decimal(5,4), hqn_expl_mcharge_to_hqn_mcharge_ratio decimal(5,4), hqn_mcharge_ratio decimal(5,4), new_mcharge_ratio decimal(5,4), hq_mcharge_ratio decimal(5,4), primary key(event_day));

drop view if exists today_total;
create view today_total as select event_day, program_video_sign, id_type, merge_conv_num, charge from monitor_material_explore where event_day=${DATE_2D_AGO};

create view expl as select program_video_sign, charge  from today_total where id_type=1;
create view hqn as select program_video_sign, id_type, charge from today_total where today_total.program_video_sign in (select video_sign from high_quality_new_material);
create view new_m as select charge from today_total where today_total.program_video_sign in (select video_sign from new_material);
create view hqn_expl as select charge from hqn where hqn.id_type=1;
create view hq as select program_video_sign, id_type, charge from today_total where today_total.program_video_sign in (select video_sign from high_quality_material);

delete from explore_material_overall_T14 where event_day = ${DATE_2D_AGO};
insert into explore_material_overall_T14(event_day, expl_ratio, expl_num, expl_mcharge_ratio, hqn_expl_mcharge_to_expl_mcharge_ratio, hqn_expl_mcharge_to_hqn_mcharge_ratio, hqn_mcharge_ratio, new_mcharge_ratio, hq_mcharge_ratio) values (
(select event_day from today_total limit 1), 
(select (select t1.expl from (select count(distinct program_video_sign) as expl from today_total where id_type=1) t1)/(select t2.total_count from (select count(distinct program_video_sign) as total_count from today_total) t2)), 
(select count(distinct program_video_sign) from today_total where id_type=1), 
(select (select sum(charge) from expl)/(select sum(charge) from today_total)), 
(select (select sum(charge) from hqn_expl)/(select sum(charge) from expl)),  
(select (select sum(charge) from hqn_expl)/(select sum(charge) from hqn)), 
(select (select sum(charge) from hqn)/(select sum(charge) from today_total)), 
(select (select sum(charge) from new_m)/(select sum(charge) from today_total)),
(select (select sum(charge) from hq)/(select sum(charge) from today_total))
); 

drop view if exists today_total;
drop table if exists high_quality_material;
drop table if exists high_quality_new_material;
drop table if exists new_material;
drop view if exists hqn_expl;
drop view if exists new_m;
drop view if exists hqn;
drop view if exists expl;
drop view if exists hq;

EOF
