"""
author: guozhichen01
"""
# -*- coding: UTF-8 -*-
import sys

video_sign2atq = {}
with open('./data/atq', 'r') as f:
    for line in f:
        arr = line.strip().split('\t')
        video_sign = arr[0]
        atq = float(arr[1])
        video_sign2atq[video_sign] = atq


new_video_sign = set()
with open('./data/new_video_sign', 'r') as f:
    for line in f:
        video_sign = line.strip()
        new_video_sign.add(video_sign)


user2video_sign = {}
with open('./data/dump_video_sign', 'r') as f:
    for line in f:
        # unit_id[0], video_sign[1], user_id[2], cust_id[3], plan_id[4], ftype[5], trans_type[6], ocpc_bid[7], winfo_id[8], index_type[9], video_url[10]
        arr = line.strip().split('\x01')
        video_sign = arr[1]
        user_id = arr[2]
        
        [new_set, old_set] = user2video_sign.setdefault(user_id, [set(), set()])
        # 新物料
        if video_sign in new_video_sign:
            new_set.add(video_sign)
        else:
            old_set.add(video_sign)


for user_id, [new_set, old_set] in user2video_sign.iteritems():
    
    sum_atq = 0.0
    for video_sign in old_set:
        atq = video_sign2atq.get(video_sign, 0.0)
        sum_atq += atq
    avg_atq = sum_atq / len(old_set) if len(old_set) != 0 else 0

    if len(new_set) != 0:
        for video_sign in new_set:
            atq = video_sign2atq.get(video_sign, 0.0)
            if atq > avg_atq:
                print('\t'.join([user_id, video_sign]))

    if len(old_set) != 0:
        for video_sign in old_set:
            atq = video_sign2atq.get(video_sign, 0.0)
            if atq > avg_atq:
                print('\t'.join([user_id, video_sign]))


