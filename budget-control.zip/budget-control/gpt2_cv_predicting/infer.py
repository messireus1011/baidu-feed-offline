"""
@author: yangye03@baidu.com
@date: 20230724
"""

import tarfile
import os
import json
import configparser
import requests
import sys
import shutil
import re
from tqdm import tqdm, trange
import numpy as np
import tensorflow as tf
from tensorflow.core.protobuf import rewriter_config_pb2
from tensorflow.python.client import device_lib
import time
from datetime import datetime
import csv
import argparse
from sys import exit
import codecs

def load_model(meta_path, model_path):
    """ 加载模型 """
    graph = tf.Graph()
    saver = tf.train.import_meta_graph(meta_path, graph=graph)
    
    sess = tf.Session(graph = graph)
    ckpt = tf.train.latest_checkpoint(model_path)
    
    saver.restore(sess, ckpt)

    return [sess, graph]

def load_ins(ins_file, sample_len = 200000):
    """ 加载ins """
    ins_feas = {}
    ins_cpa = {}
    ins_cv = {}

    cnt = 0
    for line in open(ins_file):
        # 最多加载sample_len行
        cnt += 1
        if cnt > sample_len: break

        if line.strip() == "": continue
        userid, trans_type, deep_trans_type, sign, bucket, shows, acp_avg, ctr_avg, cvr_avg, cpa_avg, cv_acc = line.strip().split("\x01")
        
       
        key = userid + "\t" + trans_type + "\t" + deep_trans_type + "\t" + sign
        if key not in ins_feas:
            ins_feas[key] = []
            ins_cpa[key] = []
            ins_cv[key] = []
        
        ins_feas[key].append([trans_type, deep_trans_type, shows, acp_avg, ctr_avg, cvr_avg])
        ins_cpa[key].append([cpa_avg])
        ins_cv[key].append([cv_acc])

    return [ins_feas, ins_cpa, ins_cv]


def do_predict(meta_path, model_path, config, ins_file):
    """ 模型推理 """
    """ 输出: acp, ctr, cvr 目标cpa 实际cv 预估cv """ 
    # 读取配置
    sequence_size = int(config['DEFAULT']['sequence_size'])   # 序列的长度
    feature_size = int(config['DEFAULT']['feature_size'])     # feature的大小
    
    # 加载模型 
    sess, graph = load_model(meta_path, model_path)
    ins_feas, ins_cpa, ins_cv = load_ins(ins_file)

    for key in ins_feas:
        feature_list_curr = []
        cpa_list_curr = []
        cv_list_curr = []

        for index in range(len(ins_feas[key]) + 50):

            # 超过sequence_size 部分是补充预估的，没有对应的ins_fea, ins_cpa等数据
            curr_index = index if index < len(ins_feas[key]) else len(ins_feas[key]) - 1;
            
            # 对一个key (user * sign), 不断加入新的token进行预估
            feature_list_curr.append(ins_feas[key][curr_index])
            cpa_list_curr.append(ins_cpa[key][curr_index])
            cv_list_curr.append([0])
           

            # 截断
            feature_list_curr2 = feature_list_curr[-1 * sequence_size : ]
            cpa_list_curr2 = cpa_list_curr[-1 * sequence_size : ]
            cv_list_curr2 = cv_list_curr[-1 * sequence_size : ]
           
            # padding: 长度不足sequence_size的话，补齐到sequence_size
            # 默认值：feature-> [0, 0, 0], cpa->[0], cv->[0]
            feature_list = np.array(feature_list_curr2, dtype=np.float32)
            cpa_list = np.array(cpa_list_curr2, dtype=np.float32)
            cv_list = np.array(cv_list_curr2, dtype=np.float32)

            feature_list = np.concatenate([feature_list, 
                                          np.zeros((sequence_size - len(feature_list), feature_size))
                                          ])
            cpa_list = np.concatenate([cpa_list, 
                                       np.zeros((sequence_size - len(cpa_list), 1))
                                      ])
            cv_list = np.concatenate([cv_list, 
                                      np.zeros((sequence_size - len(cv_list), 1))
                                     ]) 

            
            
            # 请求预估结果
            place_feas = graph.get_operation_by_name('place_feas').outputs[0]
            place_cpa = graph.get_operation_by_name('place_cpa').outputs[0]
            place_cv = graph.get_operation_by_name('place_cv').outputs[0]
            feed_dict = {place_feas: [feature_list],
                         place_cpa: [cpa_list], 
                         place_cv: [cv_list]}
            
            #########################################
            # 打印所有tensor的name                  #
            # for n in graph.as_graph_def().node:   #
            #     print (n.name)                    #
            #########################################
            
            #result = graph.get_tensor_by_name("model/cv_preds_tanh:0")
            result2 = graph.get_tensor_by_name("model/cv_preds/c_fc/c:0")
            [[val2]] = sess.run([result2], feed_dict=feed_dict)
            
            #curr_index = len(feature_list_curr) - 1
            cv_predict = val2[curr_index][0]

            #
            #cv_list_curr[-1] = [cv_predict]
            #cv_list_curr[-1] = ins_cv[key][index]
            if curr_index < len(ins_feas[key]) - 1:
                cv_list_curr[-1] = ins_cv[key][curr_index]
            else:
                cv_list_curr[-1] = [cv_predict]
            #
            #print(curr_index)
            #if index < sequence_size:
            #    log_str = '\t'.join(map(str, [key] + ins_feas[key][index]\
            #            + ins_cpa[key][index] + ins_cv[key][index] + [cv_predict]))
            #else:
            #    log_str = '\t'.join(map(str, [key] + ins_feas[key][sequence_size-1]\
            #            ins_cpa[key][index] + ins_cv[key][index] + [cv_predict]))
            log_str = '\t'.join(map(str, [key] + ins_feas[key][curr_index]\
                    + ins_cpa[key][curr_index] + ins_cv[key][curr_index] + [cv_predict]))
            print (log_str)

if __name__ == '__main__':
    config = configparser.ConfigParser()
    config.read('conf/train.conf')
    meta_path = 'model_path/cv_predcit.ckpt-100000.meta'
    model_path = 'model_path/'
    ins_file = './data/ins.0810full'
    do_predict(meta_path, model_path, config, ins_file) 
