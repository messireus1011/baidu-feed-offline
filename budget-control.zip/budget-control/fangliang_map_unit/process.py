#!/usr/bin/python
#coding=utf-8

"""
Brief:
Author: liushouhua@baidu.com
Date: 2022-04-28 11:49:13
"""
import sys

def fetch_map_file(file):
    """ fetch_map_file """
    plan_arr_unit = {}
    user_arr_unit = {}
    entity_arr_unit = {}
    
    plan_arr_user = {}
    user_arr_user = {}
    entity_arr_user = {}

    max_num = 5

    for line in open(file):
        items = line.strip().split("\t")
        entity_id = items[0]
        user_id = items[1]
        plan_id = items[2]
        unit_id = items[3]
        trans_type = items[4]
        deep_trans_type = items[5]
        
        key1 = ','.join(map(str, [plan_id, trans_type, deep_trans_type]))
        key2 = ','.join(map(str, [user_id, trans_type, deep_trans_type]))
        key3 = ','.join(map(str, [entity_id, trans_type, deep_trans_type]))

        #print key1
        #print key2
        #print key3

        if key1 not in plan_arr_unit:
            plan_arr_unit[key1] = []
            plan_arr_user[key1] = []
        
        if key2 not in user_arr_unit:
            user_arr_unit[key2] = []
            user_arr_user[key2] = []
        
        if key3 not in entity_arr_unit:
            entity_arr_unit[key3] = []
            entity_arr_user[key3] = []

        if len(plan_arr_unit[key1]) < max_num:
            plan_arr_unit[key1].append(unit_id)
            plan_arr_user[key1].append(user_id)
        
        if len(user_arr_unit[key2]) < max_num:
            user_arr_unit[key2].append(unit_id)
            user_arr_user[key2].append(user_id)
        
        if len(entity_arr_unit[key3]) < max_num:
            entity_arr_unit[key3].append(unit_id);
            entity_arr_user[key3].append(user_id);

    f = open('output_file.txt', 'w')
    num = 0
    for key in plan_arr_unit:
        unit_str = ','.join(map(str, plan_arr_unit[key]))
        user_str = ','.join(map(str, plan_arr_user[key]))
        line_str = "1" + "\t" + key + "\t" + unit_str + ";" + user_str
        if num != 0:
            line_str = "\n" + line_str
        num = num + 1

        f.write(line_str)

    for key in user_arr_unit:
        unit_str = ','.join(map(str, user_arr_unit[key]))
        user_str = ','.join(map(str, user_arr_user[key]))
        line_str = "2" + "\t" + key + "\t" + unit_str + ";" + user_str
        if num != 0:
            line_str = "\n" + line_str
        num = num + 1
        
        f.write(line_str)

    for key in entity_arr_unit:
        unit_str = ','.join(map(str, entity_arr_unit[key]))
        user_str = ','.join(map(str, entity_arr_user[key]))
        line_str = "3" + "\t" + key + "\t" + unit_str + ";" + user_str
        if num != 0:
            line_str = "\n" + line_str
        num = num + 1
        
        f.write(line_str)

    f.close()

if __name__ == "__main__":
    print ("main")
    exec(sys.argv[1])
