MYSQL="/home/users/yangye03/.jumbo/bin/mysql"
PYTHON="/home/users/yangye03/.jumbo/bin/python"
HADOOP="/home/users/yangye03/tools/hadoop_client/cornac-client/hadoop/bin/cornac"

daytime=`date -d "1 day ago" +%Y%m%d`

# fetch base_file
mysql_str=" select userid, planid, unitid, trans_type, deep_trans_type, sum(pay)/100 + sum(cpmpay)/100000 as charge from shoubai_pay_cvt_new where date='${daytime}' group by 1,2,3,4,5 order by 6 desc;"

${MYSQL} -h 10.138.28.235 -P9030 -u admin -pBes_report -D bes_report -s -e "$mysql_str" > base_file

size1=`cat base_file | wc -l`
if [ $size1 -lt 1000 ];then
    echo "base_file is too small"
    exit -1
fi

# merge entity_id
wget ftp://feed02:feed02@yy-feed02.bcc-bdbl.baidu.com/home/users/yangye03/dict_online/feed_budget/ido/user_entity_dict/output/u_e_dict -O u_e_dict

awk 'BEGIN{FS=OFS="\t"}ARGIND==1{entity[$1]=$2}ARGIND==2{eid=entity[$1];print eid, $0}' u_e_dict base_file > base_file_merge_eid

size2=`cat base_file_merge_eid | wc -l`
if [ $size2 -lt 1000 ];then
    echo "base_file_merge_eid is too small"
    exit -1
fi

# generate output file
${PYTHON} process.py 'fetch_map_file("base_file_merge_eid")'

size3=`cat output_file.txt | wc -l`
if [ $size3 -lt 1000 ];then
    echo "output_file.txt is too small"
    exit -1
fi

# put to afs
AFS_PATH="afs:/app/ecom/native-ad-price/yangye03/fangliang_map/"
cp output_file.txt output_file.txt.${daytime}
${HADOOP} fs -put output_file.txt.${daytime} afs:/app/ecom/native-ad-price/yangye03/fangliang_map/
rm output_file.txt.${daytime}

# delete old file
delete_day=`date -d "30 day ago" +%Y%m%d`
delete_file=output_file.txt.${delete_day}
${HADOOP} fs -rmr afs:/app/ecom/native-ad-price/yangye03/fangliang_map/${delete_file}

