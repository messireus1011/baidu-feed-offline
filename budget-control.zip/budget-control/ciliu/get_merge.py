#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 10:58:06 2022

@author: chenjunhao02
功能：词典合并
"""

import os
import sys

yesterday = sys.argv[1]
today = sys.argv[2]
user_file = sys.argv[3]
data_dict = {}
user_dict = {}

## 次留申请名单
#for line in open(user_file, 'r'):
#    userid = line.strip()
#    user_dict[userid] = 1
# 跳过新次留的uid
for line in open(user_file, 'r'):
    userid = line.strip()
    user_dict[userid] = 1

# 用户昨天次留率
for line in open(yesterday, 'r'):
    try:
        userid, target_ratio = line.strip().split('\x01')
        #if userid not in user_dict:
        if userid in user_dict:
            continue
        data_dict[userid] = float(target_ratio)
    except ValueError as value_err:
        continue

# 用户今天次留率
for line in open(today, 'r'):
    try:
        userid, target_ratio = line.strip().split('\x01')
        #if userid not in user_dict:
        if userid in user_dict:
            continue
        # 直接替换昨天次留率
        data_dict[userid] = float(target_ratio)
    except ValueError as value_err:
        continue

for userid in data_dict:
    target_ratio = data_dict[userid]
    print("\t".join(map(str, [userid, target_ratio])))
