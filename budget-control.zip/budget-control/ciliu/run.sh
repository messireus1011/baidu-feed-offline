if [ $# -eq 1 ]; then
    cur_day=$1
elif [ $# -eq 0 ];then
    cur_time=`date "+%Y%m%d %H %M"`
    cur_day=`echo ${cur_time} | awk '{print $1}'`
    cur_hour=`echo ${cur_time} | awk '{print $2}'`
    cur_min=`echo ${cur_time} | awk '{print $3}'`
fi

one_day=`date -d "-1 day $cur_day" +'%Y%m%d'`
two_day=`date -d "-2 day $cur_day" +'%Y%m%d'`
three_day=`date -d "-3 day $cur_day" +'%Y%m%d'`
four_day=`date -d "-4 day $cur_day" +'%Y%m%d'`
five_day=`date -d "-5 day $cur_day" +'%Y%m%d'`

#turing=/home/zhuyuyuan/zyytools/hadoop_install/turing-client_yy/hadoop/bin/hadoop
turing=/home/zhuyuyuan/zyytools/hadoop_install/turing-client-cjh/hadoop/bin/hadoop
# 客户当天目标次留率
target_ratio=./middle_data/target_ratio/target_ratio_${cur_day}
# 后验数据
qidx_data=./middle_data/qidx_data/qidx_data_file_${cur_day}
# 先验数据
pre_qidx_data=./middle_data/pre_qidx_data/pre_qidx_data_file_${cur_day}
# 分cmatch数据
total_cmatch_data=./middle_data/total_cmatch_data/total_cmatch_data_${cur_day}
# 阈值变化数据
thr_charge_data=./middle_data/thr_charge_data/thr_charge_data_${cur_day}

while true; do
    ${turing} fs -test -e userpath.ciliu_qidx_data/${cur_day}/_SUCCESS && ${turing} fs -test -e userpath.ciliu_pre_qidx_data/${cur_day}/_SUCCESS &&
    ${turing} fs -test -e userpath.ciliu_target_ratio/${cur_day}/_SUCCESS && ${turing} fs -test -e userpath.ciliu_target_ratio/${one_day}/_SUCCESS &&
    ${turing} fs -test -e userpath.ciliu_total_cmatch_data/${cur_day}/_SUCCESS
    if [ $? -eq 0 ];then
        echo "data is ready"
        break
    fi
    echo "data is not ready"
    sleep 30m
done

${turing} fs -cat userpath.ciliu_qidx_data/${cur_day}/part-* > ${qidx_data}_origin && ${turing} fs -cat userpath.ciliu_pre_qidx_data/${cur_day}/part-* > ${pre_qidx_data}_origin &&
${turing} fs -cat userpath.ciliu_target_ratio/${cur_day}/part-* > ${target_ratio}_today && ${turing} fs -cat userpath.ciliu_target_ratio/${one_day}/part-* > ${target_ratio}_yesterday &&
${turing} fs -cat userpath.ciliu_total_cmatch_data/${cur_day}/part-* > ${total_cmatch_data}_origin
if [ $? -ne 0 ];then
    echo "turing_output_file of ${cur_day} download failed..."
    python sendAlarmMsg.py -h -r 'chenjunhao02' -c "ciliu get turing failed"
    exit 1
else
    echo "turing_output_file of ${cur_day} download succ"
fi

old_retention_user=/home/zhuyuyuan/chenjunhao02/ciliu/old_ciliu/old_retention_user_dict.txt
skip_user=/home/zhuyuyuan/chenjunhao02/ciliu/skip_user
awk '{FS=OFS="\t"}{print $1}' $old_retention_user > $skip_user
# 取出需要生效的user数据
#awk '{FS=OFS="\x01"}ARGIND==1{uid[$1]=1}ARGIND==2{if($1 in uid) print $0}' ciliu_user ${qidx_data}_origin > ${qidx_data}
#awk '{FS=OFS="\x01"}ARGIND==1{uid[$1]=1}ARGIND==2{if($1 in uid) print $0}' ciliu_user ${pre_qidx_data}_origin > ${pre_qidx_data}
#awk '{FS=OFS="\x01"}ARGIND==1{uid[$1]=1}ARGIND==2{if($1 in uid) print $0}' ciliu_user ${total_cmatch_data}_origin > ${total_cmatch_data}
awk '{FS=OFS="\x01"}ARGIND==1{uid[$1]=1}ARGIND==2{if($1 in uid) next; print $0}' $skip_user ${qidx_data}_origin > ${qidx_data}
awk '{FS=OFS="\x01"}ARGIND==1{uid[$1]=1}ARGIND==2{if($1 in uid) next; print $0}' $skip_user ${pre_qidx_data}_origin > ${pre_qidx_data}
awk '{FS=OFS="\x01"}ARGIND==1{uid[$1]=1}ARGIND==2{if($1 in uid) next; print $0}' $skip_user ${total_cmatch_data}_origin > ${total_cmatch_data}
# 获取今日目标次留率
#python3 get_merge.py ${target_ratio}_yesterday ${target_ratio}_today ciliu_user > ${target_ratio}
python3 get_merge.py ${target_ratio}_yesterday ${target_ratio}_today $skip_user > ${target_ratio}
if [ $? -ne 0 ]; then
    echo "get merge target ratio failed at ${cur_day}"
    python sendAlarmMsg.py -h -r 'chenjunhao02' -c "zyy get merge target ratio failed at ${cur_day}"
    exit -1
fi
# 求门槛
python3 get_thr_new.py ${qidx_data} ${pre_qidx_data} ${total_cmatch_data} bak/ciliu_deeproiq_filter_dict.txt_${four_day} bak/ciliu_deeproiq_filter_dict.txt_${one_day} ${target_ratio} ${thr_charge_data} > ciliu_deeproiq_filter_dict.txt_tmp
if [ $? -ne 0 ]; then
    echo "get ciliu thr failed at ${cur_day}"
    python sendAlarmMsg.py -h -r 'chenjunhao02' -c "zyy get ciliu thr failed at ${cur_day}"
    exit -1
fi

mv ciliu_deeproiq_filter_dict.txt_tmp ciliu_deeproiq_filter_dict.txt
cp ciliu_deeproiq_filter_dict.txt bak/ciliu_deeproiq_filter_dict.txt_${cur_day}

# 合并次留和七留
cat ciliu_deeproiq_filter_dict.txt > retention_deeproiq_filter_dict.txt
cat qiliu_deeproiq_filter_dict.txt >> retention_deeproiq_filter_dict.txt
# 备份
cp retention_deeproiq_filter_dict.txt bak/retention_deeproiq_filter_dict.txt_${cur_day}

## merge 人工词典
#wget -O retention_deeproiq_filter_zk.txt http://zongkong.baidu.com/home/work/zongkong/userdata/86/retention_deeproiq_filter/retention_deeproiq_filter_zk.txt &&
#python3 get_merge_dict.py retention_deeproiq_filter_dict.txt retention_deeproiq_filter_zk.txt > final_retention_deeproiq_filter_dict.txt
#if [ $? -eq 0 ];then
#    echo "merge badcase success"
#    cp final_retention_deeproiq_filter_dict.txt bak/final_retention_deeproiq_filter_dict.txt_${cur_day}
#    mv final_retention_deeproiq_filter_dict.txt retention_deeproiq_filter_dict.txt
#fi
#
## 推送
#${turing} fs -rm userpath.retention_deeproiq_filter_dict/retention_deeproiq_filter_dict.txt
#${turing} fs -put retention_deeproiq_filter_dict.txt userpath.retention_deeproiq_filter_dict/
