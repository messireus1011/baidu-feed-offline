#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 10:58:06 2022

@author: chenjunhao02
功能：词典合并
"""

import os
import sys

today = sys.argv[1]
yesterday = sys.argv[2]
dic = {}

# 今天词典
# 原始词典
for line in open(today, 'r'):
    dim, cmatch, deep_trans_type, uid, coe = line.strip().split('\t')
    key = uid + "\t" + cmatch
    if key not in dic:
        dic[key] = [dim, cmatch, deep_trans_type, uid, int(coe)]
       

# 昨天词典，如果昨天有今天没有的话新增
# zk
for line in open(yesterday, 'r'):
    try:
        dim, cmatch, deep_trans_type, uid, coe = line.strip().split('\t')
        coe = int(coe)
    except ValueError as value_err:
        continue
    key = uid + "\t" + cmatch
    old_coe = 0
    if key in dic:
        old_coe = dic[key][4]
    # 取大的
    if coe > old_coe:
        dic[key] = [dim, cmatch, deep_trans_type, uid, coe]
    #if key not in dic:
    #    dic[key] = [dim, cmatch, deep_trans_type, uid, coe]

for key in dic:
    print("\t".join(map(str, dic[key])))
