#!/usr/bin/env python3
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: main.py
Author: sundaren(sundaren@baidu.com)
Date: 2023/04/07 18:22:24
"""

import numpy as np
import torch

from decision_transformer.training.trainer import Trainer


class SequenceTrainer(Trainer):
    """
    SequenceTrainer
    """

    def train_step(self):
        """
        train_step
        """
        

        states, actions, rewards, rtg, timesteps, attention_mask = self.get_batch(self.batch_size)
        action_target = torch.clone(actions)

        state_preds, action_preds, reward_preds = self.model.forward(
            states, actions, rewards, rtg[:, : -1], timesteps, attention_mask = attention_mask,
        )

        act_dim = action_preds.shape[2]
        action_preds = action_preds.reshape(-1, act_dim)[attention_mask.reshape(-1) > 0]
        action_target = action_target.reshape(-1, act_dim)[attention_mask.reshape(-1) > 0]

        loss = self.loss_fn(
            None, action_preds, None,
            None, action_target, None,
        )

        self.optimizer.zero_grad()
        loss.backward()
        
        # grad clip
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), .25)
        self.optimizer.step()

        mean_loss = 5
        max_loss = 5

        with torch.no_grad():
            mean_loss = torch.mean(abs(action_preds - action_target)).detach().cpu().item()
            max_loss = torch.max(abs(action_preds - action_target)).detach().cpu().item()
            self.diagnostics['training/mean_action_error'] = mean_loss
            self.diagnostics['training/max_action_error'] = max_loss
           
        mean_loss = min(mean_loss, 1)
        max_loss = min(max_loss, 1)
        return [loss.detach().cpu().item(), action_preds, action_target, rewards, reward_preds, mean_loss, max_loss]



