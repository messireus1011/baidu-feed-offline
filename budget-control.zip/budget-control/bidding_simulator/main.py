#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: main.py
Author: sundaren(sundaren@baidu.com)
Date: 2023/04/07 18:22:24
"""

import numpy as np
import time
from env import Env
import copy
import json
import sys
from models.pid_model import *

np.set_printoptions(precision=3)
eps = 1e-6

def eva_func(observations, ob_dim):
    """
    eva_func
    """
    total_charge = ok_charge = 0.0
    for item in observations:
        a = np.zeros(ob_dim)
        for t in range(23):
            a += item[t]

        cv = a[7]
        charge = a[8]
        tcharge = a[9]
        
        cur_diff = charge / (tcharge + eps) - 1
        total_charge += charge
        if cur_diff > -0.2 and cur_diff < 0.2:
            ok_charge += charge
    print(ok_charge / total_charge)

if __name__ == "__main__":
    file_name = sys.argv[1]
    output_idx = str(sys.argv[2])

    sample_len = 500
    ob_dim = 10
    env = Env(file_name, sample_len, ob_dim = ob_dim, sep = '\x01')   

    # env的输出格式是定的：show, clk, cv, charge, tcharge, accu_show, accu_clk, accu_cv, accu_charge, accu_tcharge
    keys = list(env.keys)
    ins_len = min(sample_len, len(keys))

    observations = []
    actions = []
    pid_model = PidModel(3, 1, 'cpu', 1.4)

    for idx in range(ins_len):
        # 输入ins的标号idx和model，输出该ins分小时的state和action
        ins_ob, action_list = env.run_ins(idx, pid_model, 0.0) 
        observations.append(ins_ob)
        actions.append(action_list)

    observations = np.array(observations)
    actions = np.array(actions)

    # 统一下存储的格式
    # observations = [[ob_0], [ob_1], .... [ob_23]]
    # actions = [[a_0], [a_1], ..., [a_23]]
    # a_i 产生了 ob_i
    #observations.dump('datas/observations_' + output_idx)
    #actions.dump('datas/actions_' + output_idx)
    eva_func(observations, ob_dim)


 
