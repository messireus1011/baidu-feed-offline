#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: predict.py
Author: chenjunhao02(chenjunhao02@baidu.com)
Date: 2023/05/30 15:22:24
"""

import numpy as np
import time
from predict_env import Env
import copy
import json
import sys
from models.dt_model import *

np.set_printoptions(precision=3)
eps = 1e-6

if __name__ == "__main__":
    #base_data = sys.stdin.read()
    file_name = sys.argv[1]
    model_name = str(sys.argv[2])
    cmatch = str(sys.argv[3])
    cur_hour = int(sys.argv[4]) - 1
    state_file_name = sys.argv[5]

    config = configparser.ConfigParser()
    config.read('confs/dt_model.conf')
    default_config = config['DEFAULT']
    state_dim = int(default_config['state_dim'])
    act_dim = int(default_config['act_dim'])

    # 初始化
    ob_dim = 10
    # 表示 tcharge - charge = 0
    return_to_go = 0
    env = Env(file_name, ob_dim, cmatch, cur_hour) 
    dt_model = DTModel(state_dim, act_dim, 'cpu')
    dt_model.load_model(model_name)
    
    dic = {}
    # 预测
    key_list = env.filter()
    for key in key_list:
        #if keys[idx] != 8045155897:
        #    continue
        action, states = env.run_ins(key, dt_model, return_to_go, cur_hour)
        states = states.detach().cpu().numpy()
        # 词典输出
        print(action)

        # 中间结果记录
        state = states[-1]
        res = action
        for i in state:
            res = res + "\t" + str(i)
        dic[res] = 0
    with open(state_file_name, 'w') as f:
        for key in dic:
            f.write(key + '\n')
