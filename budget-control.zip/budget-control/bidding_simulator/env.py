#!/usr/bin/env python
# -*- coding: utf-8-*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: env.py
Author: sundaren(sundaren@baidu.com)
Date: 2023/04/07 18:22:24
"""


from argparse import _get_action_name
from hashlib import new
import numpy as np
import time
import sys
import copy
import random
import json
import torch

DATA_DIM = 10

class Env(object):
    """
    env 
    """
    def __init__(self, filename, sample_num, ob_dim, sep):
        """
        __init__
        """
        self.ori_data = {}
        self.keys = []
        self.file_name = filename
        self.sample_num = sample_num
        self.sep = sep
        self.ob_dim = ob_dim
        self.load_data()
        
    def load_data(self):
        """
        # load_data
        # 查表的最终形式是 dic[uid][hour] = [系数, t-1 ~ t对应的量]
        """
        for line in open(self.file_name):
            data = line.strip().split(self.sep)
            # schema
            # key, hour, param, show, clk, cv, charge, tcharge, \
            uid, cmatch, hour, param, show, clk, cv, charge, tcharge, \
                    obid, bias, factor, accu_show, accu_clk, \
                    accu_cv, accu_charge, accu_tcharge = map(float, data)
            uid, cmatch = data[0], data[1]
            hour = int(hour) + 1
            key = uid + "/t" + cmatch
            #key = int(key)

            vals = np.array([obid, clk, cv, charge, tcharge, \
                    accu_show, accu_clk, \
                    accu_cv, accu_charge, accu_tcharge])
            
            if key not in self.ori_data:
                #print("ttt", key)
                self.ori_data[key] = {}

                #if len(self.ori_data.keys()) % 100 == 0:
                #    print(len(self.ori_data.keys()))

            # filename order by key
            if len(self.ori_data.keys()) > self.sample_num:
                break
            
            if hour not in self.ori_data[key]:
                self.ori_data[key][hour] = []
            self.ori_data[key][hour].append([param, vals])
       
        #print(self.ori_data[8198631823])
        self.keys = list(self.ori_data.keys())
        self.n = len(self.keys)
        print('total number of user: {}'.format(self.n))

         
    def get_res(self, param, ins_data, hour):
        """
        get_res
        """
        res = np.zeros(self.ob_dim)
        last_max_p = -1
        # t 时刻的量在 t 下标里
        if hour in ins_data:
            for val in ins_data[hour]:
                # 反馈系数
                p = val[0]
                # 对应的量
                r = val[1]
                if param >= p and param >= last_max_p:  
                    res = r
                    last_max_p = p
        # print("hour", hour - 1, last_max_p, res)
        return res
        
    def step(self, index, t, param):
        """
        step
        查表得到t时刻的状态
        """
        sample_key = self.keys[index]        
        ins_data = self.ori_data[sample_key]
        res = self.get_res(param, ins_data, t)
        return res

    def get_key(self, index):
        """
        获得uid
        """
        return self.keys[index]

    def reset(self):
        """
        reset
        """
        return np.zeros(self.ob_dim)
    
    def run_ins(self, ins_index, model, target_return):
        """
        input:
            ins_index：样本编号
            model: 调参模型
            target_return: 期望回报
        output:
            分小时的state和action, state的组建和model有关
        """
    
        # 打印 id 校验数据
        # print(self.get_key(ins_index))
        # env返回observation, observation再产生state
        observations = []

        act_dim = model.act_dim
        state_dim = model.state_dim
        device = model.device

        # todo
        state_mean = 0
        state_std = 1

        # 初始states
        state = model.get_state(observations, self.ob_dim, 0)
        states = torch.from_numpy(state).reshape(1, state_dim).to(device=device, dtype=torch.float32)
        observations.append(np.zeros(self.ob_dim))
        # 初始空action和reward
        actions = torch.zeros((0, act_dim), device=device, dtype=torch.float32)
        rewards = torch.zeros(0, device=device, dtype=torch.float32)

        # todo：兼容dt模型
        ep_return = target_return
        target_return = torch.tensor(ep_return, device=device, dtype=torch.float32).reshape(1, 1)
        timesteps = torch.tensor(0, device=device, dtype=torch.long).reshape(1, 1)


        # timestep从0开始，到24结束
        # 初始输入： return, state, action, time： [target_return],  [state_0], [], [0]
        # 每一轮： 
        #    action = get_action
        #    ob, r = Env.step
        #    R = R + [R[-1] - r]
        #    s, a, t = s + get_state(ob), a + [action], t + timestep
        # action和observations维度对应

        # 每一轮输入 Rt St 得到 At
        # 根据 At 查表得到新的 Rt+1 St+1
        for t in range(0, 24):
            # pending
            actions = torch.cat([actions, torch.zeros((1, act_dim), device=device)], dim=0)
            rewards = torch.cat([rewards, torch.zeros(1, device=device)])
            
            # 根据Rt St 得到 At
            # 倒着按self.max_length截断
            action = model.get_action(
                (states.to(dtype = torch.float32) - state_mean) / state_std,
                actions.to(dtype = torch.float32),
                rewards.to(dtype = torch.float32),
                target_return.to(dtype = torch.float32),
                timesteps.to(dtype=torch.long),
                )
            # print("action", action)
            actions[-1] = action
            try:
                action = action.detach().cpu().numpy()   
            except:
                pass

            # At 之后 得到了新的 Rt+1 St+1
            # 这里应该是获得 t + 1 时刻的量了, 注意这是查表获得的某时刻的量，不是累积值
            observation = self.step(ins_index, t + 1, action)
            observations.append(observation)
            #print("observations", t + 1, observations)

            # 这里才是累积，获得当前t + 1时刻的累积值
            cur_state = model.get_state(observations, self.ob_dim, t + 1)
            cur_reward = model.get_reward(observations, self.ob_dim, t + 1)

            # 算 t+1 的 return 和 timesteps
            scale = 1
            pred_return = target_return[0, -1] - (cur_reward / scale)
            target_return = torch.cat(
                    [target_return, pred_return.reshape(1, 1)], dim=1)
            timesteps = torch.cat(
                    [timesteps,
                    torch.ones((1, 1), device=device, dtype=torch.long) * (t + 1)], dim = 1)

            cur_state = torch.from_numpy(cur_state).to(device=device).reshape(1, state_dim)
            states = torch.cat([states, cur_state], dim=0)
            #if t <= 23:
            #    print('--' * 20, t+1)
            #    print('observation', observation)
            #    print('states', cur_state)
            #    print('reward', cur_reward)
            #    print('actions', action)
            #    print('target_return', target_return[0,-1])
        try:
            ac = actions.cpu().numpy()
        except:
            ac = actions.detach().numpy()
        return observations, ac 
    
