#!/usr/bin/env python
# -*- coding: gbk -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: dqn.py
Author: sundaren(sundaren@baidu.com)
Date: 2023/04/07 18:22:24
"""


import numpy as np
import time
import sys
import copy
import random
import json

DATA_DIM = 10
eps = 1e-6


class RandomWalkModel:
    """
    RandomWalkModel
    """
    def __init__(self, state_dim, action_dim, device, p_param):
        """
        __init__
        """
        self.state_dim = state_dim
        self.act_dim = action_dim
        self.device = device
        self.p_param = p_param
        return None
    
    def get_reward(self, observations, ob_dim, timesteps):
        """
        get_reward
        """
        def get_diff(charge, tcharge):
            """
            get_diff
            """
            if charge < eps:
                return 1
            diff = charge / (tcharge + eps)
            diff = min(diff, 5)
            return diff

        accu_ob = np.zeros(ob_dim)
        last_accu_cv = last_accu_charge = last_accu_tcharge = 0.0
        accu_cv = accu_charge = accu_tcharge = 0.0
        reward = 0.0
        items = observations[timesteps]
        obid, clk, cv, charge, tcharge, \
                accu_show, accu_clk, accu_cv, accu_charge, accu_tcharge = items
        reward = (accu_charge - accu_tcharge) / (obid + eps)

        # only last reward
        reward = 0
        if timesteps == 24:
            #print("aaaaaaaaa", reward)
            reward = -(accu_charge / (accu_tcharge + eps) - 1)
            reward = max(-0.5, min(reward, 1))
        return reward
            
        #return 0


    def get_state(self, observations, ob_dim, t):
        """
        get_state
        """

        a = np.zeros(ob_dim)
        obid = 0
        for i in range(1, t + 1):
            a += observations[i]
            obid = observations[i][0]
            #print("origin", i, observations[i])
        total_cv = a[7]
        total_charge = a[8]
        total_tcharge = a[9]
        
        # state = [total_cv, total_charge, total_tcharge]
        state = [obid, total_cv, total_charge, total_tcharge]
        return np.array(state)

    def get_result(self, states):
        """
        get_result
        """
        last_state = states[-1]
        total_cv = last_state[0]
        total_charge = last_state[1]
        total_tcharge = last_state[2]
        cur_diff = total_charge / (total_tcharge + eps) - 1
        return cur_diff, total_charge

    def get_action(self, states, actions, rewards, target_return, timesteps):
        """
        get_action
        """

        def roll_dice():
            """
            roll_dice
            """
            result = random.gauss(0, 1) + 1
            return result if result >= 0.5 and result <= 2 else roll_dice()
        
        last_state = states[-1]
        obid = last_state[0]
        total_cv = last_state[1]
        total_charge = last_state[2]
        total_tcharge = last_state[3]
        cur_diff = total_charge / (total_tcharge + eps) - 1
        cur_diff = min(cur_diff, 2)
        #new_action =  1 - self.p_param * cur_diff * min(total_cv / 10, 1.0)
        # 随机
        #new_action = round(random.uniform(0.5, 2), 2)
        # 高斯随机
        new_action = round(roll_dice(), 2)
        return new_action


