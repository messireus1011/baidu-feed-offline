#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: dqn.py
Author: sundaren(sundaren@baidu.com)
Date: 2023/04/07 18:22:24
"""


import numpy as np
import time
import sys
import copy
import random
import json
import numpy as np
import torch
import wandb
import argparse
import pickle
import random
import sys
import configparser
import tensorflow as tf

DATA_DIM = 10
eps = 1e-6


class DDPGModel:
    """
    DDPGModel
    """
    def __init__(self, state_dim, action_dim, device):
        """
        __init__
        """
        self.state_dim = state_dim
        self.act_dim = action_dim
        self.device = device
        self.graph = tf.Graph()
        self.sess = tf.Session(graph = self.graph)
        self.s = ""
    
    def load_model(self, model_name):
        """
        load_model
        """
        meta_path = "/home/disk2/sundaren/chenjunhao02/bidding_simulator/learning_model/my-model.meta"
        model_path = "/home/disk2/sundaren/chenjunhao02/bidding_simulator/learning_model/"

        saver = tf.train.import_meta_graph(meta_path, graph=self.graph)
        self.sess = tf.Session(graph = self.graph)
        ckpt = tf.train.latest_checkpoint(model_path)
        saver.restore(self.sess, ckpt)

        self.s = self.graph.get_operation_by_name('s').outputs[0]

    # 剩余流量
    def get_left_flow_ratio(self, T):
        """ get left flow ratio """
        default_list = [1.0, 1.0, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.8, 0.8, 0.7, 0.7, 0.6, 0.6, 0.5, \
                0.5, 0.5, 0.4, 0.3, 0.3, 0.2, 0.2, 0.1, 0.0]

        T = int(T)
        left_ratio = round(default_list[T], 2)
        return left_ratio

    # 归一化转化
    def get_conv_norm(self, conv, size):
        """ get_conv_norm """
        conv_norm = round(float(conv) / float(size), 1)
        conv_norm = max(conv_norm, 0.0)
        conv_norm = min(conv_norm, 1.0)
        return conv_norm

    # 计算溢出率
    def get_excess_ratio(self, tcpa, charge, tcharge):
        """ get_excess_ratio """
        ratio = 0.0
        tcharge, charge, tcpa = map(float, [tcharge, charge, tcpa])

        if charge >= 5 * tcpa:
            if tcharge <= 0:
                ratio = round(charge / tcpa - 1, 2)
            else:
                ratio = round(charge / tcharge - 1, 2)
        
        ratio = round(ratio, 2)
        ratio = max(ratio, -0.5)
        ratio = min(ratio, 1.0)
        return ratio

    # 期望转化
    def get_consume_fea(self, accum_data_arr, T, tcpa, size):
        """ get_consume_fea """

        result = 0.0
        # 归一化
        if T < 1:
            result = round(float(accum_data_arr[T]["chg"]) / tcpa / size, 2)
        else:
            charge_curr_hour = float(accum_data_arr[T]["chg"]) - float(accum_data_arr[T - 1]["chg"])
            result = round(charge_curr_hour * 1.0 / tcpa / size, 2)

        result = min(result, 1.0)
        result = max(result, 0)

        return result

    def get_curr_hour(self, T):
        """ get_curr_hour """
        ratio = round(float(T) / 23, 2)
        return ratio

    def get_state(self, actions, obversitions, ob_dim, timesteps, state_size):
        """
        利用起range(0, timesteps + 1)的数据，计算 timesteps 的累积状态s
        obversitions的index和小时区间为一一对应
        timestep t要用到 obversitions t 的数据
        """
        accu_ob = np.zeros(ob_dim)
        obid, show, clk, conv, charge, tcharge = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        T = timesteps
        accum_data_arr = {}
        
        for t in range(1, T + 1):
            item = obversitions[t]
            coe = actions[t]
            if t not in accum_data_arr:
                accum_data_arr[t] = {}
            accum_data_arr[t]["chg"] = obversitions[t][8]
            accum_data_arr[t]["tchg"] = obversitions[t][9]
            accum_data_arr[t]["coe"] = coe

        for t in range(1, T + 1):
            if t <= 1: continue
            accum_data_arr[t]["chg"] = accum_data_arr[t]["chg"] + accum_data_arr[t - 1]["chg"]
            accum_data_arr[t]["tchg"] = accum_data_arr[t]["tchg"] + accum_data_arr[t - 1]["tchg"]
            

        state_size_real = state_size
        state = np.empty(shape=(0, state_size_real))
        count = 0
            
        record = clk
        T = timesteps

        # fea1: 当前转化
        fea1_cv = self.get_conv_norm(conv, 20)
        tcpa = obid

        # fea2: 整体溢出率
        fea2_fb = self.get_excess_ratio(tcpa, charge, tcharge)
            
        # fea3: 剩余流量
        fea3_left_flow = self.get_left_flow_ratio(T)
            
        # fea4: 当前小时
        fea4_curr_hour = self.get_curr_hour(T)

        ### 下面为分小时特征，时间窗口为6
        # fea5: action_list
        # if no consume, default 1.0
        fea5_action_1 = 1.0 if T - 1 < 1 else accum_data_arr[T - 1].get("coe", 1.0)
        fea5_action_2 = 1.0 if T - 2 < 1 else accum_data_arr[T - 2].get("coe", 1.0)
        fea5_action_3 = 1.0 if T - 3 < 1 else accum_data_arr[T - 3].get("coe", 1.0)
        fea5_action_4 = 1.0 if T - 4 < 1 else accum_data_arr[T - 4].get("coe", 1.0)
        fea5_action_5 = 1.0 if T - 5 < 1 else accum_data_arr[T - 5].get("coe", 1.0)
        fea5_action_6 = 1.0 if T - 6 < 1 else accum_data_arr[T - 6].get("coe", 1.0)

        # fea6: 分小时累积溢出率，结合 fea5，目的是为了看分小时调解后的溢出率变化情况
        fea6_fb_1 = 0.0 if  T - 1 < 1 \
                else self.get_excess_ratio(tcpa, accum_data_arr[T - 1]["chg"], accum_data_arr[T - 1]["tchg"])
        fea6_fb_2 = 0.0 if  T - 2 < 1 \
                else self.get_excess_ratio(tcpa, accum_data_arr[T - 2]["chg"], accum_data_arr[T - 2]["tchg"])
        fea6_fb_3 = 0.0 if  T - 3 < 1 \
                else self.get_excess_ratio(tcpa, accum_data_arr[T - 3]["chg"], accum_data_arr[T - 3]["tchg"])
        fea6_fb_4 = 0.0 if  T - 4 < 1 \
                else self.get_excess_ratio(tcpa, accum_data_arr[T - 4]["chg"], accum_data_arr[T - 4]["tchg"])
        fea6_fb_5 = 0.0 if  T - 5 < 1 \
                else self.get_excess_ratio(tcpa, accum_data_arr[T - 5]["chg"], accum_data_arr[T - 5]["tchg"])
        fea6_fb_6 = 0.0 if  T - 6 < 1 \
                else self.get_excess_ratio(tcpa, accum_data_arr[T - 6]["chg"], accum_data_arr[T - 6]["tchg"])

        # fea7: 分小时消费速度
        fea7_consume_1 = 0.0 if T - 1 < 1 else self.get_consume_fea(accum_data_arr, T - 1, tcpa, 5)
        fea7_consume_2 = 0.0 if T - 2 < 1 else self.get_consume_fea(accum_data_arr, T - 2, tcpa, 5)
        fea7_consume_3 = 0.0 if T - 3 < 1 else self.get_consume_fea(accum_data_arr, T - 3, tcpa, 5)
        fea7_consume_4 = 0.0 if T - 4 < 1 else self.get_consume_fea(accum_data_arr, T - 4, tcpa, 5)
        fea7_consume_5 = 0.0 if T - 5 < 1 else self.get_consume_fea(accum_data_arr, T - 5, tcpa, 5)
        fea7_consume_6 = 0.0 if T - 6 < 1 else self.get_consume_fea(accum_data_arr, T - 6, tcpa, 5)
            
        state = [fea1_cv, fea2_fb, fea3_left_flow, fea4_curr_hour, \
                fea5_action_1, fea5_action_2, fea5_action_3, fea5_action_4, fea5_action_5, fea5_action_6, \
                fea6_fb_1, fea6_fb_2, fea6_fb_3, fea6_fb_4, fea6_fb_5, fea6_fb_6, \
                fea7_consume_1, fea7_consume_2, fea7_consume_3, fea7_consume_4, fea7_consume_5, fea7_consume_6]
            
        return np.array(state)
        
    def get_reward(self, obversitions, ob_dim, timesteps):
        """
        get_reward
        """
        def get_diff(charge, tcharge):
            """
            get_diff
            """

            if charge < eps:
                return 1
            diff = charge / (tcharge + eps)
            diff = min(diff, 5)
            return diff

        accu_ob = np.zeros(ob_dim)
        last_accu_cv = last_accu_charge = last_accu_tcharge = 0.0
        accu_cv = accu_charge = accu_tcharge = 0.0
        reward = 0.0
        items = obversitions[timesteps]
        obid, clk, cv, charge, tcharge, \
                accu_show, accu_clk, accu_cv, accu_charge, accu_tcharge = items
        
        #for t in range(1, timesteps+1):
        #    last_accu_cv = accu_ob[7]
        #    last_accu_charge = accu_ob[8]
        #    last_accu_tcharge = accu_ob[9]
        #    item = obversitions[t]
        #    accu_ob += item
        #    accu_cv = accu_ob[7]
        #    charge = accu_ob[8]
        #    tcharge = accu_ob[9]        
        #diff = get_diff(charge, tcharge)
        #last_diff = get_diff(last_accu_charge, last_accu_tcharge)

        #if last_diff > eps:
        #    reward = abs(last_diff - 1) - abs(diff - 1)
        
        reward = (accu_charge - accu_tcharge) / (obid + eps)

        # a delayed return
        reward = 0
        if timesteps == 24:
            reward = accu_charge / (accu_tcharge + eps) - 1
            reward = max(-0.5, min(reward, 1))
        return reward
    
    def get_action(self, states, actions, rewards, target_return, timesteps):
        """
        get_action
        """
        last_state = states[-1]
        feed_dict = {self.s:[last_state]}
        a1 = self.graph.get_tensor_by_name("Actor/eval/a/Tanh:0")
        a2 = self.graph.get_tensor_by_name("Actor/eval/add:0")
        [[p1]], [[p2]] = self.sess.run([a1, a2], feed_dict=feed_dict)
        action = max(min(p2, 2), 0.5)

        return action
