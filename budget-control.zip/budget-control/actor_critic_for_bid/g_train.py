""" author: yangye03 """

import datetime
time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)

import sys
import argparse

import math
import numpy as np

import six

import paddle
import paddle.fluid as fluid

import random
from func import *

#
# first step: prepare the data
#


######################## global parameters ######################
EPISODE = 11 # Episode limitation
UNIT_SIZE = 10 # step limitation in one episode
TEST = 10 # the number of experiment test every 100 episode
STATE_SIZE = 1000 # the dimension of state
ACTION_SIZE = 16 # the dimension of action
LEARNING_RATE = 0.001
##################################################################


def get_rand_state(s_dim):
    """ generate random state """
    state = np.zeros(s_dim, dtype=float).astype('float32')
    rand_val = np.random.randint(s_dim)
    state[rand_val] = 1.0

    state = state.reshape(1, s_dim).astype('float32')
    return state

def get_rand_action(a_dim):
    """ generate random state """
    action = np.zeros(a_dim, dtype=float).astype('float32')
    rand_val = np.random.randint(a_dim)
    action[rand_val] = 1.0

    action = action.reshape(1, a_dim).astype('float32')
    return action

def simulate(state, action, s_dim):
    """ generate random simulate result """
    state = get_rand_state(s_dim)
    reward = np.array([np.random.normal(0, 1)]).reshape(1, 1).astype('float32')

    return state, reward


###############################  actor network and function ##################################
actor_program = fluid.Program()
with fluid.program_guard(actor_program):
    a_state = fluid.layers.data(name='a_state', shape=[STATE_SIZE], dtype='float32')
    a_action = fluid.layers.data(name='a_action', shape=[ACTION_SIZE], dtype='float32')
    a_q_value = fluid.layers.data(name='a_q_value', shape=[1], dtype='float32')

    a_hidden1 = fluid.layers.fc(input=a_state, size=128, act='relu')
    a_hidden2 = fluid.layers.fc(input=a_hidden1, size=256, act='relu')

    actor_all_act_prob = fluid.layers.fc(input=a_hidden2, size=ACTION_SIZE, act='softmax')
    #print "actor_neg_log_prob"
    #print actor_all_act_prob
    # program for test
    actor_program_test = actor_program.clone(for_test=True)

    actor_neg_log_prob = fluid.layers.sum(fluid.layers.log(actor_all_act_prob) * a_action)
    #print "action"
    #print a_action
    #print "actor_neg_log_prob"
    #print actor_neg_log_prob
    actor_loss_value = fluid.layers.mean(actor_neg_log_prob * a_q_value)
    #print "actor_loss_value"
    #print actor_loss_value

    actor_opt = fluid.optimizer.Adam(learning_rate=LEARNING_RATE)
    actor_opt.minimize(loss=actor_loss_value)

def actor_learn(exe, program, state, action, q_value):
    """ actor train """
    [loss] = exe.run(program, feed={'a_state':state,
            'a_action':action, 'a_q_value':q_value},
            fetch_list=[actor_loss_value])

    return loss

def actor_choose_action(exe, program, state, action_map_reverse):
    """ actor predict fun """
    [all_act_prob] = exe.run(program,
            feed={'a_state':state},
            fetch_list=[actor_all_act_prob])
    #print all_act_prob
    #print all_act_prob.shape[0]
    #print all_act_prob.shape[1]
    action_num = []
    action_value = []
    for index in range(all_act_prob.shape[0]):
        num = np.random.choice(range(all_act_prob.shape[1]), p=all_act_prob[index])
        action_num.append(num)

        ratio = action_map_reverse[num]
        action_value.append(ratio)

        action = (np.eye(all_act_prob.shape[1])[action_num]).astype('float32')

    return action, action_value

###############################################################################################

###############################  critic network and function ##################################
critic_program = fluid.Program()
with fluid.program_guard(critic_program):
    c_state = fluid.layers.data(name='c_state', shape=[STATE_SIZE], dtype='float32')
    c_action = fluid.layers.data(name='c_action', shape=[ACTION_SIZE], dtype='float32')
    c_reward = fluid.layers.data(name='c_reward', shape=[1], dtype='float32')

    c_input = fluid.layers.concat(input=[c_state, c_action], axis=1)
    c_hidden1 = fluid.layers.fc(input=c_input, size=128, act='relu')
    c_hidden2 = fluid.layers.fc(input=c_hidden1, size=256, act='relu')
    c_predict = fluid.layers.fc(input=c_hidden2, size=1, act=None)

    # program for test
    critic_program_test = critic_program.clone(for_test=True)

    #print "critic"
    #print c_predict
    #print c_reward

    critic_square_error = fluid.layers.square_error_cost(input=c_predict, label=c_reward)
    critic_loss_value = fluid.layers.mean(critic_square_error)

    critic_opt = fluid.optimizer.Adam(learning_rate=LEARNING_RATE)
    critic_opt.minimize(loss=critic_loss_value)

def critic_learn(exe, program, state, action, reward):
    """ critic train """
    #print "critic_learn"
    #print state
    #print action
    [loss] = exe.run(program, feed={'c_state':state,
            'c_action':action,
            'c_reward':reward},
            fetch_list=[critic_loss_value])
    return loss

def critic_get_q_value(exe, program, state, action):
    """ critic predict fun """
    [predict] = exe.run(program, feed={'c_state':state,
            'c_action':action},
            fetch_list=[c_predict])
    return predict


##############################################################################################

use_cuda = False
place = fluid.CUDAPlace(0) if use_cuda else fluid.CPUPlace()
exe = fluid.Executor(place)

startup_program = fluid.default_startup_program()
exe.run(startup_program)

EPISODE = 1 # Episode limitation
UNIT_SIZE = 10 # step limitation in one episode

state_map = load_state_file("state_file.txt")
action_map_reverse = load_action_file_reverse("action_file.txt")

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print("start load pv %s" % (time))

pv_rec = load_pv_sample("res0805_2")

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print("load pv finished %s" % (time))

unit_rec = load_unit("unit_obid")

for ep in range(EPISODE):
    unit_list = get_unit_for_train(unit_rec, UNIT_SIZE)

    # initialization
    w_arr = {}
    conv_arr = {}
    charge_arr = {}
    obid_arr = {}
    for unitid in unit_list:
        w_arr[unitid] = 1.0
        conv_arr[unitid] = 0.0
        charge_arr[unitid] = 0.0
        obid_arr[unitid] = unit_rec[unitid]

    state = get_ori_state(len(unit_list), STATE_SIZE) 

    # step 0
    T=0
    for search_id in pv_rec[T]:
        advstr = pv_rec[T][search_id]
        auction_res = gsp(advstr, w_arr)
        if len(auction_res) <= 1: continue

        for adv in auction_res:
            unitid = adv[2]
            charge_arr[unitid] += adv[6]
            conv_arr[unitid] += adv[8]


    for T in range(1, 24):
        if T not in pv_rec: continue

        # update the state
        state = get_curr_state(unit_list, STATE_SIZE, conv_arr, charge_arr, obid_arr, state_map)
        #print state

        action, action_value = actor_choose_action(exe, actor_program_test, state, action_map_reverse)
        #print action
        #print action_value

        # update w_att
        w_att = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value)
        #print w_att

        # execute T step
        #print T
        for search_id in pv_rec[T]:
            advstr = pv_rec[T][search_id]
            auction_res = gsp(advstr, w_arr)
            if len(auction_res) <= 1: continue

            for adv in auction_res:
                unitid = adv[2]
                charge_arr[unitid] += adv[6]
                conv_arr[unitid] += adv[8]

        # the last hour does not need the second loop
        if T >= 23: continue

        charge_arr_cp = charge_arr.copy()
        conv_arr_cp = conv_arr.copy()

        for t in range(T + 1, 24):
            for search_id in pv_rec[t]:
                advstr = pv_rec[t][search_id]
                auction_res = gsp(advstr, w_arr)
                if len(auction_res) <= 1: continue

                for adv in auction_res:
                    unitid = adv[2]
                    charge_arr_cp[unitid] += adv[6]
                    conv_arr_cp[unitid] += adv[8]

            time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print("finished samples %d %d" % (T, t))

        rewards = calc_rewards_list(unit_list, conv_arr_cp, charge_arr_cp, obid_arr)
        #print rewards

        # update critic network
        loss = critic_learn(exe, critic_program, state, action, rewards)
        print ("critic loss %.5f" % (loss[0]))

        # update actor network
        predict = critic_get_q_value(exe, critic_program_test, state, action)
        #print predict

        loss = actor_learn(exe, actor_program, state, action, predict)
        print ("actor loss %.5f" % (loss[0]))

actor_params_dirname = "actor.model"
critic_params_dirname = "critic.model"

# save actor predict model
fluid.io.save_inference_model(dirname=actor_params_dirname,
        feeded_var_names=['a_state'],
        target_vars=[actor_all_act_prob],
        executor=exe,
        main_program=actor_program_test)

# save critic predict model
fluid.io.save_inference_model(dirname=critic_params_dirname,
        feeded_var_names=['c_state', 'c_action'],
        target_vars=[c_predict],
        executor=exe,
        main_program=critic_program_test)

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)
