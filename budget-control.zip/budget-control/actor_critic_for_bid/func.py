""" author yangye03 """

#!/usr/bin/env python
# coding=utf-8

import random
import numpy as np

def gsp(advstr, w_arr):
    """ gsp auction """
    minbid = 5.0  # reserve price
    win_num = 1   # asn
    hit_num = 0   # the num of ads that is in w_arr
    items = advstr.strip().split("#")
    advlist = []
    for one in items:
        userid, unitid, bid, ctrq, roiq = one.split(",")

        # mutliply bid with the corresponding w
        if unitid in w_arr:
            bid = float(bid) * float(w_arr[unitid])
            hit_num += 1

        # cpm, userid, unitid, bid, ctrq, roiq, price, conv
        adv = [float(bid) * float(ctrq)/1000000,
                userid,
                unitid,
                float(bid),
                float(ctrq)/1000000,
                float(roiq)/1000000,
                minbid,
                0]
        advlist.append(adv)

    if hit_num <= 0: return [] # no ad in w_arr 

    # sort by cpm
    advlist.sort(key = lambda x: x[0], reverse = True)

    # get gsp price
    # only keep the unit that is in w_arr
    adv_num = len(advlist)
    keep_list = []
    for i in range(0, win_num):
        if i >= adv_num: continue

        unitid = advlist[i][2]
        if unitid not in w_arr: continue

        if i < adv_num - 1:
            ctrq = advlist[i][4]
            if ctrq <= 0: continue

            gsp_score = advlist[i + 1][0]
            price = gsp_score / ctrq

            if price > minbid:
                advlist[i][6] = price

    # generate conv by prob
    prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
    value_list = [1, 0]
    conv_num = np.random.choice(value_list, p = prob_list)
    advlist[i][7] = conv_num

    keep_list.append(advlist[i])

    return keep_list


def load_unit(file):
    """ load_unit """
    unit_rec = {}
    for line in open(file):
        if len(line.strip().split("\t")) < 2: continue
        unit, obid = line.split("\t")
        unit_rec[unit]= obid

    return unit_rec

def get_unit_for_train(unit_rec, num):
    """ get_unit_for_train """
    unit_list = random.sample(unit_rec.keys(), num)
    return unit_list

def load_pv_sample(file):
    """ load_pv_sample """
    pv_rec = {}
    for line in open(file):
        items = line.strip().split("\x01")
        hour = int(items[2])
        searchid = items[3]
        ad_num = items[4]
        ad_str = items[5]

        if hour not in pv_rec:
            pv_rec[hour] = {}
        #pv_rec[hour][searchid] = ad_num + "\t" + ad_str
        pv_rec[hour][searchid] = ad_str

    return pv_rec


def load_state_file(file):
    """ load_state_file """
    result = {}
    for line in open(file):
        try:
            conv, excess_ratio, num = line.strip().split('\t')
            key = '\t'.join(map(str, [conv, excess_ratio]))
            result[key] = int(num)
        except:
            continue

    return result

def load_action_file_reverse(file):
    """ load_action_file_reverse """
    result = {}
    for line in open(file):
        try:
            ratio, num = line.strip().split('\t')
            result[int(num)] = float(ratio)
        except:
            continue

    return result

def get_feedback_ratio(conv, charge, obid):
    """ get_feedback_ratio """
    ratio = 1.0
    tcharge = float(obid) * float(conv)
    if tcharge <= 0:
        if float(charge) >= (float(obid) * 1.5):
            ratio = 0.5
    else:
        ratio = round(float(tcharge) / float(charge), 1)
        ratio = max(ratio, 0.7)
        ratio = min(ratio, 1.3)

    return ratio

def calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action):
    """ calc_w_att """
    w_att = {}
    for index in range(len(unit_list)):
        unitid = unit_list[index]
        fb_r = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
        ac_r = action[index]
        w_att[unitid] = fb_r * ac_r

    return w_att

def get_state_num(conv, charge, obid, state_map):
    """ get_state_num """
    conv = int(conv)
    conv = max(conv, 0)
    conv = min(conv, 50)

    excess_ratio = 1.0
    tcharge = float(obid) * float(conv)
    if tcharge <= 0:
        if charge >= (float(obid) * 1.5):
            excess_ratio = 2.0
    else:
        excess_ratio = round(float(charge) / float(tcharge), 1)

    excess_ratio = max(excess_ratio, 0.5)
    excess_ratio = min(excess_ratio, 2.0)

    key = '\t'.join(map(str, [conv, excess_ratio]))

    if key not in state_map:
        return 0

    num = state_map[key]
    return num

def get_ori_state(unit_size, state_size):
    """ get_ori_state """
    num_list = [6 for x in range(unit_size)]
    state = np.eye(state_size)[num_list]

    return state.astype('float32')

def get_curr_state(unit_list, state_size, conv_arr, charge_arr, obid_arr, state_map):
    """ get_curr_state """
    num_list = []
    for unitid in unit_list:
        num = get_state_num(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid], state_map)
        num_list.append(int(num))
    state = (np.eye(state_size)[num_list])

    return state.astype('float32')

def calc_rewards(unit_list, conv_arr, charge_arr, obid_arr):
    """ calc_rewards """
    total = len(unit_list)
    cnt = 0
    for unitid in unit_list:
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])
        if tcharge <= 0:
            if charge < obid:
                cnt += 1
        else:
            if charge > (0.8 * tcharge) and charge < (1.2 * tcharge):
                cnt += 1

    ratio = cnt / total

    return ratio

def calc_rewards_list(unit_list, conv_arr, charge_arr, obid_arr):
    """ calc_rewards_list """
    rewards = []
    for unitid in unit_list:
        val = 0
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])
        if tcharge <= 0:
            if charge < obid:
                val = 1
        else:
            if charge > (0.8 * tcharge) and charge < (1.2 * tcharge):
                val = 1

        rewards.append(val)

    rewards = np.array(rewards).reshape(len(unit_list), 1).astype('float32')
    return rewards

if __name__ == "__main__":
    #advstr = "s1,u1,10,100000,100000#s2,u2,20,100000,100000"
    #res = gsp(advstr)
    #print res

    unit_size = 3
    state_size = 10
    state = get_ori_state(unit_size, state_size)
    print state
