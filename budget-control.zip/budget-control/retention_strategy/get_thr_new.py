#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 10:58:06 2022

@author: chenjunhao02
功能：次留分布补全 + 动态门槛
"""

import pandas as pd
import warnings
warnings.filterwarnings("ignore")
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
import sys
import copy


def read_file():

    # 客户当天目标次留
    for line in open(new_target_ratio_file, 'r'):
        userid, target_ratio = line.strip().split('\t')
        new_target_ratio_dict[userid] = float(target_ratio)
            
        
    # 实际作用名单
    for line in open(worked_unit_file, 'r'):
        dim, cmatch, deep_trans_type, userid, thr = line.strip().split('\t')
        if userid not in worked_unit_dict:
            worked_unit_dict[userid] = {}
        if cmatch not in worked_unit_dict[userid]:
            worked_unit_dict[userid][cmatch] = [dim, cmatch, deep_trans_type, userid, thr]

    # 昨日门槛
    for line in open(deeproiq_filter_file, 'r'):
        dim, cmatch, deep_trans_type, userid, thr = line.strip().split('\t')
        if userid not in deeproiq_filter_dict:
            deeproiq_filter_dict[userid] = {}
        if cmatch not in deeproiq_filter_dict[userid]:
            deeproiq_filter_dict[userid][cmatch] = [dim, cmatch, deep_trans_type, userid, thr]


    # 分cmatch的转化和消费
    cols = ['userid', 'cmatch', 'chg', 'cv', 'dcv']
    data1 = pd.read_csv(total_cmatch_data_file, names=cols, sep='\x01')
    data1.fillna(0, inplace = True)
    data1['chg'] = data1.chg.astype(float)
    data1['cv'] = data1.cv.astype(float)
    data1['dcv'] = data1.dcv.astype(float)
    
    for userid, cmatch,chg, cv, dcv in \
        zip(data1.userid, data1.cmatch, data1.chg, data1.cv, data1.dcv):
        userid,cmatch = str(userid),str(cmatch)
        # cmatch无转化数，不做处理
        if dcv < 1:
            continue
        if userid not in cmatch_data:
            cmatch_data[userid] = {}
        if cmatch not in cmatch_data[userid]:
            cmatch_data[userid][cmatch] = [0.0,0.0,0.0]
        cmatch_data[userid][cmatch][0] = chg
        cmatch_data[userid][cmatch][1] = cv
        cmatch_data[userid][cmatch][2] = dcv
    
    
    # 每个userid存储 topk个 cmatch，转化数小于3的不加入排序
    for userid in cmatch_data:
        top_cmatch[userid] = []
        order_cmatch_data = dict(sorted(cmatch_data[userid].items(),key = lambda x:x[1][0],reverse = True))
        k = 1
        for cmatch in order_cmatch_data:
            dcv = order_cmatch_data[cmatch][2]
            if dcv <= CMATCH_CV_THR:
                continue
            if k > k_total:
                break
            top_cmatch[userid].append(cmatch)
            k = k+1
    
def load_basic_data():
    # 小流量的先验数据
    cols = ['userid', 'cmatch', 'q_idx', 'clk' , 'cv', 'dcv']
    data1 = pd.read_csv(pre_qidx_data_file, names=cols, sep='\x01')
    data1.fillna(0, inplace = True)
    data1['clk'] = data1.clk.astype(float)
    data1['cv'] = data1.cv.astype(float)
    data1['dcv'] = data1.dcv.astype(float)
    
    for userid, cmatch, q_idx, clk, cv, dcv in \
        zip(data1.userid, data1.cmatch, data1.q_idx, data1.clk, data1.cv, data1.dcv):
        
        userid, cmatch = str(userid), str(cmatch)
        key = userid + "\t" + cmatch
        
        # 证明这个userid没有大于3个dcv的频道
        if userid not in cmatch_data:
            # print(userid, " occur error", file=sys.stderr)
            continue
        # cmatch没有满足要求
        if cmatch not in cmatch_data[userid]:
            continue
        
        if userid not in pre_ocpx:
            pre_ocpx[userid] = {}
        if cmatch not in pre_ocpx[userid]:
            pre_ocpx[userid][cmatch] = {}
        if q_idx not in pre_ocpx[userid][cmatch]:
            pre_ocpx[userid][cmatch][q_idx] = {'clk':0.0, 'cv':0.0, 'dcv':0.0}

        pre_ocpx[userid][cmatch][q_idx]['clk'] += clk
        pre_ocpx[userid][cmatch][q_idx]['cv'] += cv
        pre_ocpx[userid][cmatch][q_idx]['dcv'] += dcv
    
    # 后验数据
    cols = ['userid', 'cmatch', 'q_idx', 'clk', 'cv', 'dcv','target_ratio']
    data = pd.read_csv(qidx_data_file, names=cols, sep='\x01')
    data.fillna(0, inplace = True)
    data['clk'] = data.clk.astype(float)
    data['cv'] = data.cv.astype(float)
    data['dcv'] = data.dcv.astype(float)
    data['target_ratio'] = data.target_ratio.astype(float)
    
    for userid, cmatch, q_idx, clk, cv, dcv, target_ratio in \
        zip(data.userid, data.cmatch, data.q_idx, data.clk, data.cv, data.dcv, data.target_ratio):
            
        userid, cmatch = str(userid), str(cmatch)
        thr = 0
        
        
        # 证明这个userid没有大于3个dcv的频道
        if userid not in cmatch_data:
            # print(userid, " occur error", file=sys.stderr)
            continue
        # cmatch没有满足要求
        if cmatch not in cmatch_data[userid]:
            continue
        
        if userid in worked_unit_dict:
            if cmatch in worked_unit_dict[userid]:
                thr = int(float(worked_unit_dict[userid][cmatch][-1])/1e4)
        
        if q_idx < thr:
            continue
        
        
        if userid not in ocpx:
            ocpx[userid] = {}
            ocpx[userid]["total"] = {'clk':0.0, 'cv':0.0, 'dcv':0.0}
            
        if cmatch not in ocpx[userid]:
            ocpx[userid][cmatch] = {}
        if q_idx not in ocpx[userid][cmatch]:
            ocpx[userid][cmatch][q_idx] = {'clk':0.0, 'cv':0.0, 'dcv':0.0}

        ocpx[userid][cmatch][q_idx]['clk'] += clk
        ocpx[userid][cmatch][q_idx]['cv'] += cv 
        ocpx[userid][cmatch][q_idx]['dcv'] += dcv
        
        ocpx[userid]["total"]['clk'] += clk
        ocpx[userid]["total"]['cv'] += cv
        ocpx[userid]["total"]['dcv'] += dcv        
        
        ocpx[userid]["total"]['target_ratio'] = target_ratio
  
    
# 分布补全
def complement_distribution(userid, cmatch, pre_dis, post_dis, tag):
    
    start = list(pre_dis.keys())[-1]
    mid = list(post_dis.keys())[-1]
    end = list(post_dis.keys())[0]
    
    # 原始累积分布
    pre_cv = 0
    cv_cum_dis = {}
    for q_idx in range(start,end+1):
        if q_idx >= mid: 
            if q_idx in post_dis:
                cv = post_dis[q_idx]
            else:
                cv = pre_cv
        else:
            if q_idx in pre_dis:
                cv = pre_dis[q_idx]
            else:
                cv = pre_cv
        pre_cv = cv
        cv_cum_dis[q_idx] = cv
    
    x_fit = []
    y_fit = []
    # 拼接后的累积分布
    for key in cv_cum_dis:
        x_fit.append(key)
        y_fit.append(cv_cum_dis[key])
    
    fit_dis[userid][cmatch][tag] = dict(sorted(zip(x_fit,y_fit)))
    
    
# 补全分布
def get_distribution(userid, cmatch):     
    
    # 如果没有后验，有问题，直接return
    if userid not in ocpx:
        return 0
    if cmatch not in ocpx[userid]:
        return 0
    
    ### 后验分布
    post_data = ocpx[userid][cmatch]
    origin_post_dis = dict(sorted(post_data.items(), key=lambda x: x[0], reverse=True))
    
    idx_thr = 0
    # 过滤门槛
    key = userid + "\t" + cmatch
    if userid in worked_unit_dict:
        if cmatch in worked_unit_dict[userid]:
            idx_thr = int(float(worked_unit_dict[userid][cmatch][-1])/1e4)
            print(key, "thr is ", idx_thr, file=sys.stderr)
    #if idx_thr == 0:
    #    print(key, "doesn't have thr", file=sys.stderr)
        
    # 后验累积分布
    x = []
    y_clk = []
    y_cv = []
    y_dcv = []
    total_post_clk = 0.0
    total_post_cv = 0.0
    total_post_dcv = 0.0

    for q_idx in origin_post_dis:
        if q_idx < idx_thr:
            continue
        clk = origin_post_dis[q_idx]['clk']
        cv = origin_post_dis[q_idx]['cv']
        dcv = origin_post_dis[q_idx]['dcv']
        total_post_clk += clk
        total_post_cv += cv
        total_post_dcv += dcv
        # if total_post_cv > 0:
        if total_post_clk > 0:
            x.append(q_idx)
            y_clk.append(total_post_clk)
            y_cv.append(total_post_cv)
            y_dcv.append(total_post_dcv)
    origin_post_clk_cum_dis = (dict(zip(x,y_clk)))
    origin_post_cv_cum_dis = (dict(zip(x,y_cv)))
    origin_post_dcv_cum_dis = (dict(zip(x,y_dcv)))
    
    # 如果总计不到门槛，则该cmatch不做处理
    if total_post_clk < CMATCH_CLK_THR or total_post_cv < CMATCH_CV_THR:
        return 0 
    
    # 统计数据为分位点做准备
    if userid not in fit_cmatch_data:
        fit_cmatch_data[userid] = {}
    if cmatch not in fit_cmatch_data[userid]:
        fit_cmatch_data[userid][cmatch] = {'clk':total_post_clk, 'cv':total_post_cv, 'dcv':total_post_dcv}
    
    if idx_thr == 0:
        if userid not in fit_dis:
            fit_dis[userid] = {}
        if cmatch not in fit_dis[userid]:
            fit_dis[userid][cmatch] = {}
        fit_dis[userid][cmatch]["clk"] = dict(sorted(zip(x,y_clk)))
        fit_dis[userid][cmatch]["shallow"] = dict(sorted(zip(x,y_cv)))
        fit_dis[userid][cmatch]["deep"] = dict(sorted(zip(x,y_dcv)))
        return 1
    
    ############### 先验补全从这开始 ###############
    # 没先验没法补
    if userid not in pre_ocpx:
        return 0
    if cmatch not in pre_ocpx[userid]:
        return 0
    
    # 先验分布 统计大于阈值的总cv 用于计算pcoc
    thr_total_pre_clk = 0.0
    thr_total_pre_cv = 0.0
    thr_total_pre_dcv = 0.0
    pre_data = pre_ocpx[userid][cmatch]
    origin_pre_dis = dict(sorted(pre_data.items(), key=lambda x: x[0], reverse=True))
    # 获得后验的最小值
    mid = list(origin_post_cv_cum_dis.keys())[-1]
    for q_idx in origin_pre_dis:
        if q_idx >= mid:
            clk = origin_pre_dis[q_idx]['clk']
            cv = origin_pre_dis[q_idx]['cv']
            dcv = origin_pre_dis[q_idx]['dcv']
            thr_total_pre_clk += clk
            thr_total_pre_cv += cv
            thr_total_pre_dcv += dcv
    
    # 如果没有先验数计算 pcoc 补全失败
    if thr_total_pre_cv == 0 or thr_total_pre_dcv == 0:
        return 0
    clk_pcoc = total_post_clk/thr_total_pre_clk
    pcoc = total_post_cv/thr_total_pre_cv
    dpcoc = total_post_dcv/thr_total_pre_dcv
    
    
    # pcoc修正先验分布
    pre_x = []
    pre_y_clk = []
    pre_y_cv = []
    pre_y_dcv = []
    total_pre_clk = 0.0
    total_pre_cv = 0.0
    total_pre_dcv = 0.0
    for q_idx in origin_pre_dis:
        clk = origin_pre_dis[q_idx]['clk'] * clk_pcoc
        cv = origin_pre_dis[q_idx]['cv'] * pcoc
        dcv = origin_pre_dis[q_idx]['dcv'] * dpcoc
        total_pre_clk += clk
        total_pre_cv += cv
        total_pre_dcv += dcv
        pre_x.append(q_idx)
        pre_y_clk.append(total_pre_clk)
        pre_y_cv.append(total_pre_cv)
        pre_y_dcv.append(total_pre_dcv)
    # 矫正后的先验分布
    mod_pre_clk_cum_dis = (dict(zip(pre_x,pre_y_clk)))
    mod_pre_cv_cum_dis = (dict(zip(pre_x,pre_y_cv)))
    mod_pre_dcv_cum_dis = (dict(zip(pre_x,pre_y_dcv)))
    
    # 如果补全后的先验数太少，补全失败(严格点卡的是dcv)
    if total_pre_dcv < CMATCH_CV_THR or total_pre_clk < CMATCH_CLK_THR:
        return 0
    
    # 需要补全的，分位点得用先验数据
    fit_cmatch_data[userid][cmatch]['clk'] = total_pre_clk
    fit_cmatch_data[userid][cmatch]['cv'] = total_pre_cv
    fit_cmatch_data[userid][cmatch]['dcv'] = total_pre_dcv
    
    # 如果需要补全,通过"后验分布"与"修正的先验分布"还原最终分布
    if idx_thr > 0:
        if userid not in fit_dis:
            fit_dis[userid] = {}
        if cmatch not in fit_dis[userid]:
            fit_dis[userid][cmatch] = {}
        complement_distribution(userid, cmatch, mod_pre_clk_cum_dis,origin_post_clk_cum_dis,"clk")
        complement_distribution(userid, cmatch, mod_pre_cv_cum_dis,origin_post_cv_cum_dis,"shallow")
        complement_distribution(userid, cmatch, mod_pre_dcv_cum_dis,origin_post_dcv_cum_dis,"deep")
        return 1

# 按分位点取门槛
def get_quantile_thr(userid, cmatch):
    quantile = quantile_dict[userid]
    total_clk = fit_cmatch_data[userid][cmatch]['clk']
    clk = 0.0
    # 从大往小遍历
    cmatch_clk = sorted(fit_dis[userid][cmatch]["clk"], reverse=True)
    for q_idx in cmatch_clk:
        clk = fit_dis[userid][cmatch]["clk"][q_idx]
        if clk/total_clk >= quantile:
            return q_idx
        

# 递归存入参数
def add_params(i, cmatch_list, param):
    if i >= len(cmatch_list):
        tmp_param = copy.deepcopy(param)
        params.append(tmp_param)
        return
    cmatch = cmatch_list[i]
    for q_idx in fit_dis[userid][cmatch]["shallow"]:
        param[cmatch] = q_idx
        add_params(i+1, cmatch_list, param)

def output_data_dict(dict_data, file_name):
    with open(file_name, 'w') as f:
        for key, value in dict_data.items():
            value = '\t'.join(map(str, value))
            f.write(key + '\t' + value + '\n')
    print("save data into dict", file=sys.stderr)

# 作用的userid+cmatch，需要补全
worked_unit_dict = {}
# 昨日的词典，用作范围限制
deeproiq_filter_dict = {}
# 总数据
cmatch_data = {}
# 补全后的总数据
fit_cmatch_data = {}
# 客户当天目标次留
new_target_ratio_dict = {}
# 后验数据
ocpx = {}
# 先验数据
pre_ocpx = {}
# 拟合后的累积分布
fit_dis = {}
# 分位点
quantile_dict = {}
# 门槛变化的中间数据
middle_data = {}
BIN_STEP = 0.01
MOVE_STEP = 0.1 * 1e6
CV_THR = 20
CMATCH_CV_THR = 3
CMATCH_CLK_THR = 100
k_total = 4
# 存储topk个cmatch
top_cmatch = {}
NO_THR = "NO_THR"
POST_THR = "POST_THR"
FIT_THR = "FIT_THR"
qidx_data_file = sys.argv[1]
pre_qidx_data_file = sys.argv[2]
total_cmatch_data_file = sys.argv[3]
worked_unit_file = sys.argv[4]
deeproiq_filter_file = sys.argv[5]
new_target_ratio_file = sys.argv[6]
middle_data_file = sys.argv[7]

if __name__=="__main__":
    
    read_file()
    load_basic_data()
    
    for userid in ocpx:
        #total_clk = ocpx[userid]["total"]['clk']
        total_cv = ocpx[userid]["total"]['cv']
        total_dcv = ocpx[userid]["total"]['dcv']
        target_ratio = ocpx[userid]["total"]['target_ratio']

        # 获取客户当天目标次留
        if userid in new_target_ratio_dict:
            target_ratio = new_target_ratio_dict[userid]
        
        # cv不够，直投激活，无次留门槛
        if total_dcv < CV_THR:
            print(userid, "cv is not enough", file=sys.stderr)
            continue
        
        cur_ratio = total_dcv / total_cv
        
        final_target = target_ratio
        
        # 所有参数空间
        top_cmatch_list = copy.deepcopy(top_cmatch[userid])
        
        # 获得补全后的累积分布
        other_cmatch_list = []
        for cmatch in cmatch_data[userid]:
            has_cmatch = get_distribution(userid, cmatch)
            # 如果补全失败，则剔除该cmatch
            if has_cmatch == 0:
                # 在头部cmatch则从头部cmatch剔除
                if cmatch in top_cmatch_list:
                    top_cmatch_list.remove(cmatch)
            # 补全成功，如果不在头部cmatch,则加入other_cmatch
            else:
                if cmatch not in top_cmatch_list:
                    other_cmatch_list.append(cmatch)
        
        # 如果没有符合搜参的cmatch，则直接跳过这个uid
        if len(top_cmatch_list) < 1:
            continue
            
        # 待搜索的参数空间
        param_cmatch_list = top_cmatch_list
        # param_cmatch_list = list(fit_dis[userid].keys())
        
        param = {}
        params = []
        add_params(0, param_cmatch_list, param)
        
        max_clk = 0.0
        max_cv = 0.0
        max_dcv = 0.0
        best_param = NO_THR
        best_ratio = 0.0
        first_param = NO_THR
        a = 0
        total_clk = 0
        # 参数搜索
        for param in params:
            remain_clk = remain_cv = remain_dcv = 0.0
            for cmatch in param:
                thr = param[cmatch]
                remain_clk += fit_dis[userid][cmatch]["clk"][thr]
                remain_cv += fit_dis[userid][cmatch]["shallow"][thr]
                remain_dcv += fit_dis[userid][cmatch]["deep"][thr]
            ratio = remain_dcv / (remain_cv + 0.001)
            
            # 不砍的结果
            a += 1
            #if a == len(params):
            if a == 1:
                total_clk = remain_clk
                first_param = param
                print("first", userid, first_param, ratio, final_target, remain_clk, remain_cv, remain_dcv, file=sys.stderr)
            
            # 正式搜参
            if remain_dcv > CV_THR and ratio > final_target:
                if remain_cv > max_cv:
                    max_clk = remain_clk
                    max_cv = remain_cv
                    max_dcv = remain_dcv
                    best_param = param
                    best_ratio = ratio
        
        # 取分位点
        quantile = max_clk/total_clk
        if userid not in quantile_dict:
            quantile_dict[userid] = quantile
        print ("final", userid, best_param, best_ratio, final_target, max_clk, max_cv, max_dcv, file=sys.stderr)
        
        # 如果没有搜到门槛
        if best_param == NO_THR:
            new_thr, his_thr = 0, 0
            if userid in deeproiq_filter_dict:
                if cmatch in deeproiq_filter_dict[userid]:
                    his_thr = float(deeproiq_filter_dict[userid][cmatch][-1])
            key = userid + "\t" + cmatch
            if key not in middle_data:
                middle_data[key] = ["NO THR", his_thr, new_thr]
            continue
 
        # 如果搜到门槛
        # 聚合的cmatch
        final_best_param = {}
        for cmatch in other_cmatch_list:
            deeproiq_thr = get_quantile_thr(userid, cmatch)
            # print("deeproiq_thr",cmatch, deeproiq_thr)
            deeproiq_thr = int(deeproiq_thr * 1e4)
            if deeproiq_thr > 0:
                final_best_param[cmatch] = deeproiq_thr
        
        # 映射一下
        for cmatch in best_param:
            deeproiq_thr = int(best_param[cmatch] * 1e4)
            final_best_param[cmatch] = deeproiq_thr
        
        # 如果过保严重，或者用户次留率严重变化，则直接赋值门槛
        diff =  int(round(best_ratio - final_target,2) * 1e6)
        if abs(diff) > 0.05 * 1e6:
            for cmatch in final_best_param:
                deeproiq_thr = final_best_param[cmatch]
                key = userid + "\t" + cmatch
                his_thr = 0
                if userid in deeproiq_filter_dict:
                    if cmatch in deeproiq_filter_dict[userid]:
                        his_thr = float(deeproiq_filter_dict[userid][cmatch][-1])
                
                # 给历史无门槛赋值
                if his_thr == 0:
                    new_thr = deeproiq_thr
                    if userid not in deeproiq_filter_dict:
                        deeproiq_filter_dict[userid] = {}
                    if cmatch not in deeproiq_filter_dict[userid]:
                        deeproiq_filter_dict[userid][cmatch] = [3, cmatch, 28, userid, new_thr]
                    if key not in middle_data:
                        middle_data[key] = ["NO THR AND OVER TARGET", his_thr, new_thr]
                # 历史有门槛，最多可以浮动50%
                else:
                    new_thr = int(max(min(his_thr * 1.5, deeproiq_thr), his_thr * 0.5))
                    deeproiq_filter_dict[userid][cmatch][-1] = new_thr
                    if key not in middle_data:
                        middle_data[key] = ["HAS THR AND OVER TARGET", his_thr, new_thr]
        
        # 如果正常波动范围之内
        else:
            for cmatch in final_best_param:
                deeproiq_thr = final_best_param[cmatch]
                key = userid + "\t" + cmatch
                his_thr = 0    
                if userid in deeproiq_filter_dict:
                    if cmatch in deeproiq_filter_dict[userid]:
                        his_thr = float(deeproiq_filter_dict[userid][cmatch][-1])
                
                # 如果历史没有门槛，则直接赋值
                if his_thr == 0:
                    new_thr = deeproiq_thr
                    if userid not in deeproiq_filter_dict:
                        deeproiq_filter_dict[userid] = {}
                    if cmatch not in deeproiq_filter_dict[userid]:
                        deeproiq_filter_dict[userid][cmatch] = [3, cmatch, 28, userid, new_thr]
                    if key not in middle_data:
                        middle_data[key] = ["NO THR AND HAS PARAMS", his_thr, new_thr]
                
                # 如果历史有门槛，则新门槛上下限历史的为10%
                else:
                    new_thr = int(max(min(his_thr * 1.1, deeproiq_thr), his_thr * 0.9))
                    deeproiq_filter_dict[userid][cmatch][-1] = new_thr
                    if key not in middle_data:
                        middle_data[key] = ["HAS THR AND HAS PARAMS", his_thr, new_thr]
               

    # 增量更新：为防止客户停投后线上无参数，或者没有计算出新参数，一律采用原参数
    for userid in sorted(deeproiq_filter_dict.keys()):
        for cmatch in deeproiq_filter_dict[userid]:
            dim, cmatch, deep_trans_type, userid, thr = deeproiq_filter_dict[userid][cmatch]
            if float(thr) <= 0:
                continue
            thr = int(round(float(thr),-4))
            # 最终输出保留前两位
            print("\t".join(map(str, [3, cmatch, deep_trans_type, userid, thr])))
    
    # 记录变化过程
    output_data_dict(middle_data, middle_data_file)
