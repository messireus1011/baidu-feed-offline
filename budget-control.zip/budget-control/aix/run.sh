##########################################################################
# File Name: run.sh
# Author: chenjunhao02
# mail: chenjunhao02@baidu.com
# Created Time: Wed 26 Jul 2023 05:10:49 PM CST
#########################################################################
#!/bin/zsh
PATH=/home/edison/bin:/home/edison/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/work/tools/gcc-3.4.5-glibc-2.3.6/bin
export PATH

TURING_CLIENT='/home/work/chenjunhao02/hadoop_turing/hadoop/bin/hadoop'
cur_day=`date "+%Y%m%d"`
yes_day=`date -d "-1 day $cur_day" +'%Y%m%d'`
need_day=`date -d "-30 day $cur_day" +'%Y%m%d'`

# 数据获取uid一个月中有消费日期的日均消费
file=/home/work/chenjunhao02/crontab_job/aix/data/budget_allocation_${cur_day}
tag=0
mysql="/home/work/.jumbo/bin/mysql -h 100.64.7.211 -P9030 -u admin -pBes_report -N -e"
$mysql "use bes_report;"
while [[ ${try_num} -lt 3 ]]; do
    $mysql "set query_timeout=120;
    select userid, sum(chg)/count(date) as avg_chg
        from
        (select date, userid, sum(pay)/100 + sum(cpmpay)/100000 as chg
            from shoubai_online_data.shoubai_pay_cvt_v3
            where date >= ${need_day} and date <= ${yes_day}
            group by 1,2) t1
        group by 1;
    " > ${file}
    if [ $? -eq 0 ]; then
        tag=1
        break
    fi
    try_num=`expr ${try_num} + 1`
    sleep 360s
done

# 文件上传
if [ $tag -eq 1 ]; then
    ${TURING_CLIENT} fs -put ${file} userpath.aix_budget_allocation/
    if [[ $? -ne 0 ]];then
        tag=0
    else
        echo "put a-ix budget_allocation_data success at ${cur_day}"
    fi
fi

# 状态检测
if [ $tag -eq 0 ]; then
    python ../sendAlarmMsg.py -h -r 'chenjunhao02' -c "get a-ix budget_allocation_data failed"
fi
