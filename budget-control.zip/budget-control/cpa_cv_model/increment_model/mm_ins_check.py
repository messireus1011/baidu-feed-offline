
import sys

in_file = sys.argv[1]

input_dict = {}
for line in open(in_file):
    #if len(line.strip().split("\x01")) != 14:
    if len(line.strip().split("\x01")) != 11:
        print(line)
        continue
    #date, userid, trans_type, deep_trans_type, video_sign, buket, show, _, _, _, cpa, cv, _, _ = line.strip().split("\x01")
    #date, userid, trans_type, deep_trans_type, video_sign, buket, show, _, _, _, cpa, cv = line.strip().split("\x01")
    userid, trans_type, deep_trans_type, video_sign, buket, show, _, _, _, cpa, cv = line.strip().split("\x01")
    cpa = cpa if cpa != '""' else 0
    #key = date + '_' + userid + '_' + trans_type + '_' + deep_trans_type
    key = userid + '_' + trans_type + '_' + deep_trans_type
    if key not in input_dict:
        input_dict[key] = {}
    if video_sign not in input_dict[key]:
        input_dict[key][video_sign] = []
    input_dict[key][video_sign].append([float(cpa), float(cv), float(buket)])

total = 0
abnormal = 0
for key in input_dict:
    for video_sign in input_dict[key]:
        total += 1
        cpa_data = [input_dict[key][video_sign][x][0] for x in range(0, len(input_dict[key][video_sign]))]
        cv_data = [input_dict[key][video_sign][x][1] for x in range(0, len(input_dict[key][video_sign]))]
        if cpa_data != sorted(cpa_data) or cv_data != sorted(cv_data):
            abnormal += 1
            #print(key, video_sign, input_dict[key][video_sign])
            print(key, video_sign)
print(total, abnormal, abnormal/total)
