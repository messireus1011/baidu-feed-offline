""" author: yangye03 """

import datetime
time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)

import sys
import argparse

import math
import numpy as np

import six

import paddle
import paddle.fluid as fluid

import random
from func import *

#
# first step: prepare the data
#


######################## global parameters ######################
EPISODE = 11 # Episode limitation
UNIT_SIZE = 10 # step limitation in one episode
TEST = 10 # the number of experiment test every 100 episode
STATE_SIZE = 80 # the dimension of state
ACTION_SIZE = 16 # the dimension of action
LEARNING_RATE = 0.001
##################################################################


def get_rand_state(s_dim):
    """ generate random state """
    state = np.zeros(s_dim, dtype=float).astype('float32')
    rand_val = np.random.randint(s_dim)
    state[rand_val] = 1.0

    state = state.reshape(1, s_dim).astype('float32')
    return state

def get_rand_action(a_dim):
    """ generate random state """
    action = np.zeros(a_dim, dtype=float).astype('float32')
    rand_val = np.random.randint(a_dim)
    action[rand_val] = 1.0

    action = action.reshape(1, a_dim).astype('float32')
    return action

def simulate(state, action, s_dim):
    """ generate random simulate result """
    state = get_rand_state(s_dim)
    reward = np.array([np.random.normal(0, 1)]).reshape(1, 1).astype('float32')

    return state, reward


###############################  actor network and function ##################################
actor_program = fluid.Program()
with fluid.program_guard(actor_program):
    a_state = fluid.layers.data(name='a_state', shape=[STATE_SIZE], dtype='float32')
    a_action = fluid.layers.data(name='a_action', shape=[ACTION_SIZE], dtype='float32')
    a_q_value = fluid.layers.data(name='a_q_value', shape=[ACTION_SIZE], dtype='float32')

    a_hidden1 = fluid.layers.fc(input=a_state, size=32, act='relu', \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))
    a_hidden2 = fluid.layers.fc(input=a_hidden1, size=64, act='relu', \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))

    actor_all_act_prob = fluid.layers.fc(input=a_hidden2, size=ACTION_SIZE, act='softmax', \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))
    
    # program for test
    actor_program_test = actor_program.clone(for_test=True)

    #actor_neg_log_prob = fluid.layers.sum(fluid.layers.log(actor_all_act_prob) * a_action)
    #actor_loss_value = -1 * fluid.layers.reduce_sum(actor_neg_log_prob * a_q_value)

    actor_loss_value = -1 * fluid.layers.reduce_sum(actor_all_act_prob * a_q_value) 

    actor_opt = fluid.optimizer.Adam(learning_rate=LEARNING_RATE)
    actor_opt.minimize(loss=actor_loss_value)

def actor_learn(exe, program, state, action, q_value):
    """ actor train """
    [loss, qval, act, act_all] \
            = exe.run(program, feed={'a_state':state,
            'a_action':action, 'a_q_value':q_value},
            fetch_list=[actor_loss_value, a_q_value, a_action, actor_all_act_prob])

    print ("actor_learn")
    print loss
    print qval
    print act
    print act_all
    #print prob1
    #print prob2

    return loss

def actor_choose_action(exe, program, state, action_map_reverse):
    """ actor predict fun """
    [all_act_prob] = exe.run(program,
            feed={'a_state':state},
            fetch_list=[actor_all_act_prob])
    #print all_act_prob
    #print all_act_prob.shape[0]
    #print all_act_prob.shape[1]
    action_num = []
    action_value = []
    for index in range(all_act_prob.shape[0]):
        #num = np.random.choice(range(all_act_prob.shape[1]), p=all_act_prob[index])
        #num = np.argmax(all_act_prob[index])
        # add disturbance  
        #disturb_list = [-2, -1, 0, 1, 2]
        #disturb_prob = [0.2, 0.2, 0.2, 0.2, 0.2]
        #disturb_num = np.random.choice(disturb_list, p=disturb_prob)
        #print ("disturb num:%d dis:%d" % (num, disturb_num))
        #num = num + disturb_num
        #num = min(num, ACTION_SIZE-1)
        #num = max(num, 0)

        num = np.random.choice(range(all_act_prob.shape[1]))

        action_num.append(num)
        ratio = action_map_reverse[num]
        action_value.append(ratio)

        action = (np.eye(all_act_prob.shape[1])[action_num]).astype('float32')

    return action, action_value, action_num

###############################################################################################

###############################  critic network and function ##################################
critic_program = fluid.Program()
with fluid.program_guard(critic_program):
    c_state = fluid.layers.data(name='c_state', shape=[STATE_SIZE], dtype='float32')
    c_action = fluid.layers.data(name='c_action', shape=[ACTION_SIZE], dtype='float32')
    c_reward = fluid.layers.data(name='c_reward', shape=[1], dtype='float32')

    c_input = fluid.layers.concat(input=[c_state, c_action], axis=1)
    c_hidden1 = fluid.layers.fc(input=c_input, size=32, act='relu', \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))
    c_hidden2 = fluid.layers.fc(input=c_hidden1, size=64, act='relu', \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))
    c_predict = fluid.layers.fc(input=c_hidden2, size=1, act=None, \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))

    # program for test
    critic_program_test = critic_program.clone(for_test=True)

    #print "critic"
    #print c_predict
    #print c_reward

    critic_square_error = fluid.layers.square_error_cost(input=c_predict, label=c_reward)
    critic_loss_value = fluid.layers.mean(critic_square_error)

    critic_opt = fluid.optimizer.Adam(learning_rate=LEARNING_RATE)
    critic_opt.minimize(loss=critic_loss_value)

def critic_learn(exe, program, state, action, reward):
    """ critic train """
    #print "critic_learn"
    #print state
    #print action
    [loss] = exe.run(program, feed={'c_state':state,
            'c_action':action,
            'c_reward':reward},
            fetch_list=[critic_loss_value])
    return loss

def critic_get_q_value(exe, program, state, action):
    """ critic predict fun """
    [predict] = exe.run(program, feed={'c_state':state,
            'c_action':action},
            fetch_list=[c_predict])
    return predict


##############################################################################################

###############################  simplized critic network  ##################################
Q_dict = {}
G_dict = {}
def simple_critic_get_q_value(Q_dict, state_num, ACTION_SIZE):
    """ simple get q value """
    q_value = [] 
    for i in range(len(state_num)):
        for j in range(ACTION_SIZE):
            key_state = state_num[i]
            key_action = j
            key = '\t'.join(map(str, [key_state, key_action]))

            q_value_curr = Q_dict.get(key, 0.0)
            q_value.append(q_value_curr)

    q_value = np.array(q_value).reshape(len(state_num), ACTION_SIZE).astype('float32')
    print "q_value check"
    print q_value
    
    return q_value
##############################################################################################

use_cuda = False
place = fluid.CUDAPlace(0) if use_cuda else fluid.CPUPlace()
exe = fluid.Executor(place)

startup_program = fluid.default_startup_program()
exe.run(startup_program)

EPISODE = 5000 # Episode limitation
UNIT_SIZE = 10000 # step limitation in one episode

state_map = load_state_file("state_file.txt")
action_map_reverse = load_action_file_reverse("action_file.txt")

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print("start load pv %s" % (time))

#pv_rec = load_pv_sample("res0805_2")
#pv_rec = load_pv_sample("top")


#unit_rec = load_unit("unit_obid_charge_5000")
#unit_rec = load_unit("unit_obid_charge_50")
unit_rec = load_unit_with_prob("unit_obid_charge_prob_10000")

# load obid arr all
obid_arr_all = load_unit("unit_obid_charge")

# load gap arr
gap_arr = load_gap("unit_gap")

# big_table
big_table = load_big_table("big_table.txt")

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print("load big table finished %s" % (time))

for ep in range(EPISODE):
    time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print ("epstart %d start %s" % (ep, time))

    #selecting unit for training
    #unit_list = get_unit_for_train(unit_rec, UNIT_SIZE)
    unit_list = get_unit_for_train_with_prob(unit_rec, UNIT_SIZE)
    #unit_list = unit_rec.keys()

    # initialization
    w_arr = {}         # feedback ratio 
    conv_arr = {}      # unit's total conv
    charge_arr = {}    # unit's total charge
    obid_arr = {}      # unit's obid
    for unitid in unit_list:
        w_arr[unitid] = 1.0
        conv_arr[unitid] = 0.0
        charge_arr[unitid] = 0.0
        obid_arr[unitid] = obid_arr_all[unitid]

    state = get_ori_state(len(unit_list), STATE_SIZE) 

    # step 0
    T=0
    for T in range(0, 1):
        hour = ("%02d" % T)
        for unitid in unit_list:
            unit_w = w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))
            if key in big_table:
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]
                #print ("unitid:%s key:%s charge:%f" % (unitid, key, fetch_list[0]))
        
    for T in range(1, 24):
        time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print("start_T samples ep %d %d %s" % (ep, T, time))
        
        # update the state
        cnt = 0
        for i in conv_arr:
            cnt += conv_arr[i]
        print "cnt"
        print cnt
        state, state_num = get_curr_state(unit_list, STATE_SIZE, conv_arr, charge_arr, obid_arr, state_map)
        #print state

        action, action_value, action_num = actor_choose_action(exe, actor_program_test, state, action_map_reverse)
        #print action
        #print action_value

        # update w_arr
        w_arr = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value)
        #print w_arr

        # print gap_arr
        #for unitid in gap_arr:
        #    print ("unit:%s gap:%.2f" % (unitid, gap_arr[unitid]))

        # execute T step
        #print T
        
        hour = ("%02d" % T)
        
        print "check_num"
        check_num = 0
        total_num = 0
        for unitid in unit_list:
            total_num += 1
            unit_w = w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))
            #print key
            if key in big_table:
                check_num += 1
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]
        
        print total_num
        print check_num

        # the last hour does not need the second loop
        if T >= 23: continue

        charge_arr_cp = charge_arr.copy()
        conv_arr_cp = conv_arr.copy()
       
        for t in range(T + 1, 24):
            hour = ("%02d" % t)
        
            for unitid in unit_list:
                unit_w = w_arr[unitid]
                key = '\t'.join(map(str, [unitid, hour, unit_w]))
                if key in big_table:
                    fetch_list = big_table[key]
                    charge_arr_cp[unitid] += fetch_list[0]
                    conv_arr_cp[unitid] += fetch_list[1]

            time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print("finished samples ep %d %d %d %s" % (ep, T, t, time))

        # calc rewards
        rewards = calc_rewards_list(unit_list, conv_arr_cp, charge_arr_cp, obid_arr)
        #rewards = calc_rewards_list2(unit_list, conv_arr_cp, charge_arr_cp, obid_arr)
        print "rewards"
        print rewards
        
        # update gap_arr
        #gap_arr = calc_gap_arr(unit_list, eshow_sum_arr_cp, bid_sum_arr_cp, price_sum_arr_cp)

        # update G_dict Q_dict
        # cumulative avg computing: avg(N) = avg(N-1) + (new_sample - avg(N-1)) / N
        for index in range(len(state_num)):
            reward_current = float(rewards[index])

            key_state = state_num[index]
            key_action = action_num[index]

            key = '\t'.join(map(str, [key_state, key_action]))
            G_dict[key] = G_dict.get(key, 0) + 1

            reward_avg_pre = Q_dict.get(key, 0.0)
            Q_dict[key] = reward_avg_pre * 1.0 + (reward_current - reward_avg_pre) * 1.0 / G_dict[key]

        # get q_value
        q_value = simple_critic_get_q_value(Q_dict, state_num, ACTION_SIZE)

        # update actor network


        # update critic network
        #loss = critic_learn(exe, critic_program, state, action, rewards)
        #print ("critic loss %.5f" % (loss[0]))

        # update actor network
        #predict = critic_get_q_value(exe, critic_program_test, state, action)
        #print "predict"
        #print predict
        
        loss = actor_learn(exe, actor_program, state, action, q_value)
        print ("actor loss %.5f" % (loss[0]))
        #exit("1")

        # print visual
        print ("params visual")
        
        print ("fc_0")
        print (np.array(fluid.global_scope().var('fc_0.w_0').get_tensor()))
        print (np.array(fluid.global_scope().var('fc_0.b_0').get_tensor()))
        print ("fc_1")
        print (np.array(fluid.global_scope().var('fc_1.w_0').get_tensor()))
        print (np.array(fluid.global_scope().var('fc_1.b_0').get_tensor()))
        print ("fc_2")
        print (np.array(fluid.global_scope().var('fc_2.w_0').get_tensor()))
        print (np.array(fluid.global_scope().var('fc_2.b_0').get_tensor()))
        #print ("fc_3")
        #print (np.array(fluid.global_scope().var('fc_3.w_0').get_tensor()))
        #print (np.array(fluid.global_scope().var('fc_3.b_0').get_tensor()))
        #print ("fc_4")
        #print (np.array(fluid.global_scope().var('fc_4.w_0').get_tensor()))
        #print (np.array(fluid.global_scope().var('fc_4.b_0').get_tensor()))
        #print ("fc_5")
        #print (np.array(fluid.global_scope().var('fc_5.w_0').get_tensor()))
        #print (np.array(fluid.global_scope().var('fc_5.b_0').get_tensor()))


        # check predict result
        time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print("finish ep %d %d %s start infer test" % (ep, T, time))

        charge_total = 0
        tcharge_total = 0
        for unitid in unit_list:
            charge_total += charge_arr_cp[unitid]
            tcharge_total += (float(conv_arr_cp[unitid]) * float(obid_arr[unitid]))
            #charge_total += charge_arr[unitid]
            #tcharge_total += (float(conv_arr[unitid]) * float(obid_arr[unitid]))
        if tcharge_total <= 0: tcharge_total = 1.0
        print ("status charge:%.2f tcharge:%.2f ratio:%.2f" \
                % (charge_total, tcharge_total, charge_total / tcharge_total))
        
        if T == 22:
            action_map_reverse_infer = load_action_file_reverse("action_file.txt")
            state_map_reverse_infer, state_num_list_infer = load_state_file_reverse("state_file.txt")

            state_infer = (np.eye(STATE_SIZE)[state_num_list_infer]).astype('float32')
            [all_act_prob] = exe.run(actor_program_test,
                                    feed={'a_state':state_infer},
                                    fetch_list=[actor_all_act_prob])

            result_file = "./results_file/infer.txt.%d_%d" % (ep, T)
            result_f = open(result_file, 'w')
            for i in range(all_act_prob.shape[0]):
                num = np.argmax(all_act_prob[i])
                action_value = action_map_reverse_infer[num]
                state_ori = state_map_reverse_infer[i]
                str_res =  '\t'.join(map(str, [state_ori, action_value]))
                result_f.write(str_res + "\n")
            result_f.close()
            
            dict_file = "./results_file/dict.txt.%d_%d" % (ep, T)
            dict_f = open(dict_file, 'w')
            keys = Q_dict.keys()
            keys.sort()
            for key in keys:
                dict_res = '\t'.join(map(str, [key, Q_dict[key], G_dict[key]]))
                dict_f.write(dict_res + "\n")
            dict_f.close()

    time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print ("ep %d end %s" % (ep, time))

    actor_params_dirname = "actor_model/actor.model.%s" % (ep)
    critic_params_dirname = "critic_model/critic.model.%s" % (ep)

    # save actor predict model
    fluid.io.save_inference_model(dirname=actor_params_dirname,
            feeded_var_names=['a_state'],
            target_vars=[actor_all_act_prob],
            executor=exe,
            main_program=actor_program_test)

    # save critic predict model
    fluid.io.save_inference_model(dirname=critic_params_dirname,
            feeded_var_names=['c_state', 'c_action'],
            target_vars=[c_predict],
            executor=exe,
            main_program=critic_program_test)

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)
