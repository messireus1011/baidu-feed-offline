
PYTHON=/home/users/yangye03/.jumbo/bin/python
daytime=`date -d '1 day ago' +%Y%m%d`
daytime2=`date +%Y%m%d`

sql_str="select userid, unitid,sum(conversions) as cv, sum(pay/100 + cpmpay / 100000.0) as charge, sum(conv_ocpc_bid/100) as tcharge, sum(pay/100 + cpmpay / 100000.0) / sum(conv_ocpc_bid/100) as ratio from shoubai_online_data.shoubai_pay_cvt_v3 where date between "${daytime}" and "${daytime2}" and bidtype=3 and ocpclevel=2 and cmatch = 719 group by 1,2 order by 1,2;"

/home/users/yangye03/.jumbo/bin/mysql -h 10.138.28.235 -P9030 -u admin -pBes_report -D bes_report -e "$sql_str" > user_consume


wget ftp://feed02:feed02@yy-feed02.bcc-bdbl.baidu.com/home/users/yangye03/dict_online/feed_budget/ido/user_entity_dict/output/u_e_dict -O u_e_dict

awk 'BEGIN{FS=OFS="\t"}ARGIND==1{map[$1]=$2}ARGIND==2{user=$1;unit=$2;charge=$4;eid=map[user];key=eid"\t"unit;sum[key]+=charge;}END{for(i in sum) print i, sum[i]}' u_e_dict user_consume > eid_unit_consume

cat eid_unit_consume | sort -t$'\t' -k3gr | head -n 100 | awk 'BEGIN{FS=OFS="\t"}{print $2"\t"$3}' > zhongan_append_units

/home/users/yangye03/.jumbo/bin/python process.py
mv user_father_units_tmp user_father_units
