#!/usr/bin/python3
""" user exploreroad support """

import random

map_rec = {}
for line in open("eid_unit_consume"):
    try:
        eid, unit, charge = line.strip().split("\t")
        if eid not in map_rec:
            map_rec[eid] = []
        map_rec[eid].append((unit, charge))
    except:
        continue

for key in map_rec:
    map_rec[key] = sorted(map_rec[key], key=lambda x:float(x[1]), reverse=True)[:20]

# zhongan append extra
zhongan_eid = ['200272105', '429619325', '428947973', '428976852']
for one in zhongan_eid:
    if one not in map_rec:
        map_rec[one] = []
        
    for line in open("zhongan_append_units"):
        t_unitid, t_consume = line.strip().split("\t")
        map_rec[one].append((t_unitid, t_consume))

eid_dict = {}
for line in open("u_e_dict"):
    try:
        user, eid = line.strip().split("\t");
        eid_dict[user] = eid;
    except:
        continue

user_rec = {}
result_file = open("user_father_units_tmp", "w")
flag = 0
for line in open("user_dict"):
    user = line.strip().split("\t")[0]
    
    if user not in eid_dict:
        continue
    eid = eid_dict[user]

    if eid not in map_rec:
        continue
    
    father_size = 20
    if eid in zhongan_eid:
        father_size = 30
    if father_size > len(map_rec[eid]):
        father_size = len(map_rec[eid])

    unit_str = ""
    select_res = random.sample(map_rec[eid], father_size) 
    for item in select_res:
        unit = item[0]
        if unit_str == "":
            unit_str = str(unit)
        else:
            unit_str = unit_str + "#" + str(unit)

    line_str = str(user) + "\t" + unit_str
    if flag == 0:
        result_file.write(line_str)
        flag = 1
    else:
        result_file.write("\n" + line_str)

result_file.close()

