""" author: yangye03 """
#!/usr/bin/env python
# coding=utf-8
import datetime
import random
from cyc_func import *

import numpy as np
import sys

from scipy.signal import find_peaks
from scipy.misc import electrocardiogram

import tensorflow as tf
######################## global parameters ######################
STATE_SIZE = 22 # the dimension of state
ACTION_SIZE = 31 # the dimension of action
LEARNING_RATE = 0.001
##################################################################


# load obid arr all
obid_arr_all = load_unit("unit_obid_charge")

# load gap arr
gap_arr = load_gap("unit_gap")

# big_table
big_table = load_big_table("big_talbe_nogap.txt_10000_pcoc")

# load cyc
cyc_rec = load_cyc("unit_cyc")

# load test unit
#unit_rec = load_unit_with_prob("unit_obid_charge_prob_10000", "unit_trans_type")
#unit_rec = load_unit_with_prob("unit_obid_charge_prob_test_1000", "unit_trans_type")
unit_rec = load_unit_with_prob("unit_obid_charge_prob_9000", "unit_trans_type")

# select unit for test
unit_list = unit_rec.keys()

def infer_loop(obid_arr_all, gap_arr, big_table, cyc_rec, unit_rec, unit_list, loop_id):
    """ infer_loop """
    meta_path = "./model_conv/" + str(loop_id) + "/my-model.meta"
    model_path= "./model_conv/" + str(loop_id) + "/"

    graph = tf.Graph()
    saver = tf.train.import_meta_graph(meta_path, graph=graph)
    sess = tf.Session(graph = graph)
    ckpt = tf.train.latest_checkpoint(model_path)
    saver.restore(sess, ckpt) 
    s = graph.get_operation_by_name('s').outputs[0]

    # initialization
    w_arr = {}         # bid ratio 
    conv_arr = {}      # unit's total conv
    charge_arr = {}    # unit's total charge
    obid_arr = {}      # unit's obid
    
    charge_T_arr = {}
    conv_T_arr = {}
    action_T_arr = {}

    for hour in range(0, 24):
        charge_T_arr[hour] = {}
        conv_T_arr[hour] = {}
        action_T_arr[hour] = {}
    
    for unitid in unit_list:
        if unitid not in gap_arr:
            gap_arr[unitid] = 1.3
        w_arr[unitid] = gap_arr[unitid]

        obid_arr[unitid] = obid_arr_all[unitid]
        conv_arr[unitid] = 0.0
        charge_arr[unitid] = 0.0

        for hour in range(0, 24):
            charge_T_arr[hour][unitid] = 0.0
            conv_T_arr[hour][unitid] = 0.0
            action_T_arr[hour][unitid] = 1.0


    for T in range(0, 24):
        # get curr state
        state = get_curr_state_x(unit_list, STATE_SIZE, conv_arr, charge_arr, obid_arr, \
            cyc_rec, T, charge_T_arr, conv_T_arr, action_T_arr)

        action_value = []
        for index in range(len(unit_list)):
            unitid = unit_list[index]
            
            feed_dict = {s:[state[index]]}
            a1 = graph.get_tensor_by_name("Actor/eval/a/Tanh:0")
            a2 = graph.get_tensor_by_name("Actor/eval/add:0")
            [[p1]], [[p2]] = sess.run([a1, a2], feed_dict=feed_dict)
            value = p2

            action_value.append(value)

        for index in range(len(unit_list)):
            unitid = unit_list[index]
            if int(obid_arr[unitid]) > 0 and float(charge_arr[unitid]) >= (5 * int(obid_arr[unitid])):
                pass
            else:
                # if the conv is not credible, set the action = 1.0
                action_value[index] = 1.0
    

        # update w_arr
        w_arr = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value, gap_arr)

        # execute T step
        hour = ("%02d" % T)
        
        for index in range(len(unit_list)):
            unitid = unit_list[index]
            unit_w = w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))

            action_T_arr[T][unitid] = action_value[index]
            if key in big_table:
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]
                    
                charge_T_arr[T][unitid] += fetch_list[0]
                conv_T_arr[T][unitid] += fetch_list[1]
            else:
                pass
            if T > 0:
                charge_T_arr[T][unitid] += charge_T_arr[T - 1][unitid]
                conv_T_arr[T][unitid] += conv_T_arr[T - 1][unitid]
        
    # check results
    total_cnt = 0
    valid_cnt = 0
    single_hit_cnt = 0
    double_hit_cnt = 0
    total_charge = 0.0
    total_tcharge = 0.0

    check_charge = {}
    check_tcharge = {}

    for unitid in unit_list:
        conv = float(conv_arr[unitid])
        charge = float(charge_arr[unitid])
        obid = float(obid_arr[unitid])
        tcharge = obid * conv

        total_charge += charge
        total_tcharge += tcharge

        check_charge[unitid] = check_charge.get(unitid, 0.0) + charge
        check_tcharge[unitid] = check_tcharge.get(unitid, 0.0) + tcharge

        total_cnt += 1;
        if conv >= 5:
            valid_cnt += 1

            if charge <= 1.2 * tcharge:
                single_hit_cnt += 1
            
                if charge >= 0.8 * tcharge:
                    double_hit_cnt += 1

    excess_ratio = total_charge / total_tcharge - 1

    if valid_cnt == 0: valid_cnt = 1.0
    single_ratio = single_hit_cnt * 1.0 / valid_cnt
    double_ratio = double_hit_cnt * 1.0 / valid_cnt

    return single_ratio, double_ratio

for index in range(40, 56):
    loop_id = index * 1000
    single_ratio, double_ratio = infer_loop(obid_arr_all, gap_arr, big_table, cyc_rec, unit_rec, unit_list, loop_id)
    print "index:%d\t%.2f\t%.2f" % (index, single_ratio, double_ratio)
