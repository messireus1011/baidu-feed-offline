""" author: yangye03 """

import datetime
time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)

import sys
import argparse
import math
import numpy as np
import six
import random
from ddpg import DDPG

from cyc_func import *

#
# first step: prepare the data
#


######################## global parameters ######################
EPISODE = 11 # Episode limitation
UNIT_SIZE = 10 # step limitation in one episode
TEST = 10 # the number of experiment test every 100 episode
STATE_SIZE = 22 # the dimension of state
ACTION_SIZE = 1 # the dimension of action
OUTPUT_SIZE = 1
PID_TRAIN_NUM = 0
LEARNING_RATE = 0.0002
##################################################################

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print("start load pv %s" % (time))

a_bound = 2.5
RL = DDPG(ACTION_SIZE, STATE_SIZE, a_bound, \
          batch_size = 100, memory_size = 100000000, \
          learning_rate_c = 0.001, learning_rate_r = 0.001)

# load train unit
unit_rec = load_unit_with_prob("unit_obid_charge_prob_9000", "unit_trans_type")
# load cyc
cyc_rec = load_cyc("unit_cyc")
# load obid arr all
obid_arr_all = load_unit("unit_obid_charge")
# load gap arr
gap_arr = load_gap("unit_gap")
# load big_table
big_table = load_big_table("big_talbe_nogap.txt_10000_pcoc")

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print("load big table finished %s" % (time))

train_num = 0
EPISODE = 10000000 # Episode limitation
UNIT_SIZE = 100 # step limitation in one episode
for ep in range(EPISODE):
    time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print ("epstart %d start %s" % (ep, time))

    # get unit for current batch
    unit_list = get_unit_for_train(unit_rec, UNIT_SIZE)

    # initialization
    w_arr = {}         # bid ratio 
    conv_arr = {}      # unit's total conv
    charge_arr = {}    # unit's total charge
    obid_arr = {}      # unit's obid
    
    charge_T_arr = {}
    conv_T_arr = {}
    action_T_arr = {}

    for hour in range(0, 24):
        charge_T_arr[hour] = {}
        conv_T_arr[hour] = {}
        action_T_arr[hour] = {}
    
    for unitid in unit_list:
        if unitid not in gap_arr:
            gap_arr[unitid] = 1.3
        w_arr[unitid] = gap_arr[unitid]

        obid_arr[unitid] = obid_arr_all[unitid]
        conv_arr[unitid] = 0.0
        charge_arr[unitid] = 0.0

        for hour in range(0, 24):
            charge_T_arr[hour][unitid] = 0.0
            conv_T_arr[hour][unitid] = 0.0
            action_T_arr[hour][unitid] = 1.0

    # base tcharge with only gap_param
    base_tcharge = calc_base_tcharge(unit_list, w_arr, obid_arr, gap_arr, big_table)
    #pid_control_res_arr = calc_pid_res(unit_list, obid_arr, gap_arr, big_table)

    # step 0
    T=0
    for T in range(0, 1):
        hour = ("%02d" % T)
        for unitid in unit_list:
            unit_w = w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))
            if key in big_table:
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]

                charge_T_arr[T][unitid] += fetch_list[0]
                conv_T_arr[T][unitid] += fetch_list[1]
            #if T > 0:
            #    charge_T_arr[T][unitid] += charge_T_arr[T - 1][unitid]
            #    conv_T_arr[T][unitid] += conv_T_arr[T - 1][unitid]



    for T in range(1, 24):
        time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print("start_T samples ep %d %d %s" % (ep, T, time))
        
        # update the state
        cnt = 0
        for i in conv_arr:
            cnt += conv_arr[i]
        print "cnt: " + str(cnt)

        # fb ratio list 
        pid_ratio_list = get_fb_ratio(unit_list, conv_arr, charge_arr, obid_arr)

        # get curr state
        state = get_curr_state_x(unit_list, STATE_SIZE, conv_arr, charge_arr, obid_arr, \
                cyc_rec, T, charge_T_arr, conv_T_arr, action_T_arr)

        # get curr action
        action_value_predict_list = []
        action_value_list = []
        for index in range(len(unit_list)):
            state_i = state[index]
            action_i =  RL.choose_action(state_i)
            action_value_predict_list.append(action_i)

            # action disturb
            pid_i = pid_ratio_list[index]
            
            random_f = np.random.uniform()
            var = 0
            if random_f <= 1.5 / 10.0:
                var = 0
            elif random_f <= 6.0 / 10.0:
                var = 0.5
            else:
                var = 1

            action_i_shift = action_i
            if var == 0.5:
                action_i_shift = np.clip(np.random.normal(action_i, 0.5), 0.5, 2.5)
            elif var == 1:
                action_i_shift = np.clip(np.random.normal(pid_i, 0.5), 0.5, 2.5)

            action_value_list.append(action_i_shift)


        # fetch conversion-credible unit (conv >= 5)
        unit_cred_list = []
        state_unit_cred = np.empty(shape=(0, STATE_SIZE))
        action_unit_cred = []
        action_real_unit_cred = []
        pid_ratio_cred_list = []
        
        for index in range(len(unit_list)):
            unitid = unit_list[index]

            #print ("test1 unit:%s charge:%f conv:%d obid:%d" % \
            #        (unitid, float(charge_arr[unitid]), int(conv_arr[unitid]), int(obid_arr[unitid])))
            if int(obid_arr[unitid]) > 0 and float(charge_arr[unitid]) >= (5 * int(obid_arr[unitid])):
                unit_cred_list.append(unitid)
                state_unit_cred = np.append(state_unit_cred, [state[index]], axis=0)
                action_unit_cred.append(action_value_list[index])
                action_real_unit_cred.append(action_value_predict_list[index])
                pid_ratio_cred_list.append(pid_ratio_list[index])

            else:
                # if the conv is not credible, set the action = 1.0
                action_value_list[index] = 1.0
                pid_ratio_list[index] = 1.0
            

        # update w_arr
        w_arr = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value_list, gap_arr)
        w_arr_pid = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, pid_ratio_list, gap_arr)

        # storage for the pid loop
        charge_arr_pid = charge_arr.copy()
        conv_arr_pid = conv_arr.copy()
        for t in range(T, 24):
            hour = ("%02d" % t)
            for index in range(len(unit_list)):
                unitid = unit_list[index]
                unit_w = w_arr_pid[unitid]
                key = '\t'.join(map(str, [unitid, hour, unit_w]))
                if key in big_table:
                    fetch_list = big_table[key]
                    charge_arr_pid[unitid] += fetch_list[0]
                    conv_arr_pid[unitid] += fetch_list[1]

        # execute T step
        hour = ("%02d" % T)
        
        check_num = 0
        total_num = 0
        for index in range(len(unit_list)):
            total_num += 1

            unitid = unit_list[index]
            unit_w = w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))

            action_T_arr[T][unitid] = action_value_list[index]
            if key in big_table:
                check_num += 1
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]
                    
                charge_T_arr[T][unitid] += fetch_list[0]
                conv_T_arr[T][unitid] += fetch_list[1]

            if T > 0:
                charge_T_arr[T][unitid] += charge_T_arr[T - 1][unitid]
                conv_T_arr[T][unitid] += conv_T_arr[T - 1][unitid]
        
        print ("total_num:%d check_num:%d" % (total_num, check_num))


        # the last hour does not need the second loop
        if T > 23: continue

        # if there is no credible unit, continue
        if len(unit_cred_list) <= 0: continue

        # storage for the second loop
        charge_arr_cp = charge_arr.copy()
        conv_arr_cp = conv_arr.copy()
       
        for t in range(T + 1, 24):
            hour = ("%02d" % t)
        
            for unitid in unit_cred_list:
                unit_w = w_arr[unitid]
                key = '\t'.join(map(str, [unitid, hour, unit_w]))
                if key in big_table:
                    fetch_list = big_table[key]
                    charge_arr_cp[unitid] += fetch_list[0]
                    conv_arr_cp[unitid] += fetch_list[1]

            time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print("finished samples ep %d %d %d %s" % (ep, T, t, time))

        
        # fb ratio list 
        #pid_ratio_cred_list = get_fb_ratio(unit_cred_list, conv_arr, charge_arr, obid_arr)

         # calc rewards
        rewards = calc_rewards_list_x_baging(unit_list, unit_cred_list, conv_arr_cp, charge_arr_cp, obid_arr, \
            base_tcharge, pid_ratio_cred_list, state_unit_cred, action_unit_cred, action_real_unit_cred, \
            train_num, PID_TRAIN_NUM, charge_arr_pid, conv_arr_pid)
        #print "rewards"


        # write to memory

        # change rewards
        if train_num >= PID_TRAIN_NUM:
            UNIT_SIZE = 10000
            RL.memory_reset(100000000, 10000)

        for index in range(len(unit_cred_list)):
            state_i = state_unit_cred[index]
            action_i = action_unit_cred[index]
            reward_i = rewards[index]
            debug_value = [0, 0, 0, 0, 0, 0]
            RL.store_transition(state_i, [action_i], reward_i, debug_value)

        RL.learn()
        #RL.dum_param()
        #RL.dump_ins(train_num)

        if train_num % 1000 == 0:
            RL.save(train_num)

        # record the train_num
        train_num += 1
        #sys.exit()
    time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print ("ep %d end %s" % (ep, time))

#state = (np.eye(10)[[1,2]]).astype('float32')
#action = (np.eye(10)[[3,4]]).astype('float32')
#q_value = np.array([23, 25]).reshape(2,1).astype('float32')

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)
