#!/usr/bin/env python
# -*- coding: gbk -*-
########################################################################
#
# Copyright (c) 2022 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: dqn.py
Author: sundaren(sundaren@baidu.com)
Date: 2022/10/29 18:22:24
"""
import tensorflow as tf
import numpy as np
import time
#from cpa import Simulator
from scipy.stats import entropy
#import tensorflow.compat.v1 as tf
#import copy
from scipy.signal import find_peaks
import matplotlib.pyplot as plt
np.set_printoptions(precision=3)

np.random.seed(1)
tf.set_random_seed(1)
#tf.disable_eager_execution()
#tf.disable_v2_behavior() 

#####################  hyper parameters  ####################

#MAX_EPISODES = 200
#MAX_EP_STEPS = 200
#LR_A = 0.0005   # learning rate for actor
#LR_C = 0.0005  # learning rate for critic
#MEMORY_CAPACITY = 10000000
#BATCH_SIZE = 320000

#RENDER = False
#ENV_NAME = 'Pendulum-v0'

###############################  DDPG  ####################################

class DDPG(object):
    """ ddpg """
    def __init__(self, a_dim, s_dim, a_bound, \
                 batch_size, memory_size, learning_rate_c, learning_rate_r):
        """ init """

        self.memory_size = memory_size
        self.batch_size = batch_size
        
        
        # store:  state, action, reward, pid_param, rl_param, pid_diff, rl_diff, pid_cv, rl_cv 
        self.memory = np.zeros((self.memory_size, s_dim + a_dim + 1 + 6), dtype=np.float32)
        self.pointer = 0

        self.critic_error = 0
        self.actor_error = 0

        tf.reset_default_graph()
        self.sess = tf.Session()

        self.a_dim, self.s_dim, self.a_bound = a_dim, s_dim, a_bound,
        self.S = tf.placeholder(tf.float32, [None, s_dim], 's')
        self.R = tf.placeholder(tf.float32, [None, 1], 'r')

        with tf.variable_scope('Actor'):
            self.a = self._build_a(self.S, scope='eval', trainable=True)
        tf.add_to_collection("predict_a", self.a)

        with tf.variable_scope('Critic'):
            self.q = self._build_c(self.S, self.a, scope='eval', trainable=True)
        tf.add_to_collection("predict_q", self.q)


        self.ae_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='Actor/eval')
        self.ce_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='Critic/eval')
    
        q_target = self.R  
        td_error = tf.losses.mean_squared_error(labels=q_target, predictions=self.q)
        self.critic_error = td_error
        self.ctrain = tf.train.AdamOptimizer(learning_rate_c).minimize(td_error, var_list=self.ce_params)

        a_loss = tf.reduce_mean(self.q)
        tf.add_to_collection("a_loss", a_loss)
        self.actor_error = a_loss
        self.atrain = tf.train.AdamOptimizer(learning_rate_r).minimize(a_loss, var_list=self.ae_params)

        self.saver = tf.train.Saver(max_to_keep=1000)
        self.sess.run(tf.global_variables_initializer())

    def memory_reset(self, memory_size, batch_size):
        """ memory_reset """
        self.memory_size = memory_size
        self.batch_size = batch_size
        #self.memory = np.zeros((self.memory_size, self.s_dim + self.a_dim + 1 + 6), dtype=np.float32)
        self.pointer = 0
        print ("mem reset; pointer:%d" % (self.pointer))

    def choose_action(self, s):
        """ choose_action """
        a = self.sess.run(self.a, {self.S: s[np.newaxis, :]})[0][0]
        #q = self.sess.run(self.q, {self.S: s[np.newaxis, :], self.a: [[a]]})
        return a

    def learn(self):
        """ learn """
        select_range = self.memory_size if self.pointer > self.memory_size else self.pointer
        select_num = select_range if self.batch_size > select_range else self.batch_size
        indices = np.random.choice(select_range, select_num, replace=False)
        #if self.pointer > self.memory_size:
        #    indices = np.random.choice(self.memory_size, self.batch_size)
        #else:
        #    indices = np.random.choice(self.pointer, self.batch_size)
   
        bt = self.memory[indices, :]
        bs = bt[:, :self.s_dim]
        ba = bt[:, self.s_dim: self.s_dim + self.a_dim]
        br = bt[:, self.s_dim + self.a_dim: self.s_dim + self.a_dim + 1]

        actor_error, _ = self.sess.run([self.actor_error, self.atrain], {self.S: bs})
        critic_error, _ = self.sess.run([self.critic_error, self.ctrain], {self.S: bs, self.a: ba, self.R: br})

        print ("critic loss: %.4f" % (critic_error))
        print ("actor loss: %.4f" % (actor_error))

    def store_transition(self, s, a, r, values):
        """ store_transition """
        if not hasattr(self, 'pointer'):
            self.pointer = 0
        transition = np.hstack((s, a, [r], values))
        index = self.pointer % self.memory_size
        self.memory[index, :] = transition
        self.pointer += 1
        

    def _build_a(self, s, scope, trainable):
        with tf.variable_scope(scope):
            net = tf.layers.dense(s, 64, activation=tf.nn.softmax, name='l1', trainable=trainable)
            #net2 = tf.layers.dense(net, 64, activation=tf.nn.softmax, name='l2', trainable=trainable)
            #a = tf.layers.dense(net2, self.a_dim, activation=tf.nn.softmax, name='a', trainable=trainable)
            a = tf.layers.dense(net, self.a_dim, activation=tf.nn.tanh, name='a', trainable=trainable)
            #return tf.multiply(a, self.a_bound, name='scaled_a') + self.a_bound
            return a + 1.5
            
            #with tf.variable_scope(scope):
            #net = tf.layers.dense(s, 20, activation=tf.nn.relu, name='l1', trainable=trainable)
            #a = tf.layers.dense(net, self.a_dim, activation=tf.nn.tanh, name='a', trainable=trainable)
            #return tf.multiply(a, self.a_bound, name='scaled_a') + self.a_bound
            #return tf.multiply(a, self.a_bound, name='scaled_a')
            #return a + 1.5

            #net = tf.layers.dense(s, 20, activation=tf.nn.relu, name='l1', trainable=trainable)
            #a = tf.layers.dense(net, self.a_dim, activation=tf.nn.tanh, name='a', trainable=trainable)
            #return tf.multiply(a, self.a_bound, name='scaled_a') + self.a_bound
        
    def _build_c(self, s, a, scope, trainable):
        with tf.variable_scope(scope):
            n_l1 = 60
            w1_s = tf.get_variable('w1_s', [self.s_dim, n_l1], trainable=trainable)
            w1_a = tf.get_variable('w1_a', [self.a_dim, n_l1], trainable=trainable)
            b1 = tf.get_variable('b1', [1, n_l1], trainable=trainable)
            net = tf.nn.relu(tf.matmul(s, w1_s) + tf.matmul(a, w1_a) + b1)
            return tf.layers.dense(net, 1, name='q', trainable=trainable)  # Q(s,a)    
    
    def dump_ins(self, train_num):
        """
        dump_ins
        """
        print ("dump ins: ")
        print ("pointer: %d" % (self.pointer))
        print ("memory: %d" % (self.memory_size))
        idx = 0
        if self.pointer > self.memory_size:
            idx = self.memory_size
        else:
            idx = self.pointer
        np.savetxt("./ins/" + str(train_num) + "_ins.txt", self.memory[:idx, :], delimiter = ',', fmt='%1.3f')
    
    def  dum_param(self):
        """
        dump param
        """
        print ("dump param: ")
        print ("pointer: %d" % (self.pointer))
        variable_names = [v.name for v in tf.trainable_variables()]
        values = self.sess.run(variable_names)
        for k, v in zip(variable_names, values):
            print("Variable: ", k)
            print("Shape: ", v.shape)
            print(v)
        
        
    def save(self, num):
        """
        save
        """
        self.saver.save(self.sess, "./model_conv/" + str(num) + "/my-model")

        
    def close(self):
        """
        close
        """
        self.sess.close()
        del self.sess
     
