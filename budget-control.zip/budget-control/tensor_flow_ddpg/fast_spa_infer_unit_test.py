""" author: yangye03 """
#!/usr/bin/env python
# coding=utf-8
import datetime
import random
from cyc_func import *

import numpy as np
import sys
from ddpg import DDPG

import tensorflow as tf
from scipy.misc import electrocardiogram
from scipy.signal import find_peaks

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)

######################## global parameters ######################
STATE_SIZE = 22 # the dimension of state
ACTION_SIZE = 1 # the dimension of action
LEARNING_RATE = 0.001
##################################################################


meta_path = "./model_conv/791000/my-model.meta"
model_path= "./model_conv/791000/"

graph = tf.Graph()
saver = tf.train.import_meta_graph(meta_path, graph=graph)
sess = tf.Session(graph = graph)
ckpt = tf.train.latest_checkpoint(model_path)
#print("hh")
#print(ckpt)
saver.restore(sess, ckpt)

s = graph.get_operation_by_name('s').outputs[0]
#print s
#state = [np.ones(22, dtype=np.float32)]
#feed_dict = {
#    s:state
#}

#a1 = graph.get_tensor_by_name("Actor/eval/a/Tanh:0")
#a2 = graph.get_tensor_by_name("Actor/eval/add:0")

#[[p1]], [[p2]] = sess.run([a1, a2], feed_dict=feed_dict)
#print p
#print p1
#print p2
#graph_op = graph.get_operations()
#for i in graph_op:
#    print(i)


#sys.exit()
print ("hello")


USE_PREDICT = 1

if len(sys.argv) >= 2:
    USE_PREDICT = int(sys.argv[1])

print "USE"
print USE_PREDICT


# load obid arr all
obid_arr_all = load_unit("unit_obid_charge")
# load gap arr
gap_arr = load_gap("unit_gap")
# big_table
big_table = load_big_table("big_talbe_nogap.txt_10000_pcoc")
#big_table = {}
# load cyc
cyc_rec = load_cyc("unit_cyc")

# load test unit
#unit_rec = load_unit_with_prob("unit_obid_charge_prob_10000", "unit_trans_type")
unit_rec = load_unit_with_prob("unit_obid_charge_prob_test_1000", "unit_trans_type")
#unit_rec = load_unit_with_prob("unit_obid_charge_prob_9000", "unit_trans_type")

# select unit for test
unit_list = unit_rec.keys()
#unit_list = ['7251155741', '7023976081', '6953295941'] 

# action_dis: predict dis; action_list: the actual actoin; pid_lis: the actual pid list
action_dis = {}
action_list_arr = {}
pid_list_arr = {}

# initialization
w_arr = {}         # bid ratio 
conv_arr = {}      # unit's total conv
charge_arr = {}    # unit's total charge
obid_arr = {}      # unit's obid
 
charge_T_arr = {}
conv_T_arr = {}
action_T_arr = {}

for hour in range(0, 24):
    charge_T_arr[hour] = {}
    conv_T_arr[hour] = {}
    action_T_arr[hour] = {}
    
for unitid in unit_list:
    action_dis[unitid] = []
    pid_list_arr[unitid] = []
    action_list_arr[unitid] = []

    if unitid not in gap_arr:
        gap_arr[unitid] = 1.3
    w_arr[unitid] = gap_arr[unitid]

    obid_arr[unitid] = obid_arr_all[unitid]
    conv_arr[unitid] = 0.0
    charge_arr[unitid] = 0.0

    for hour in range(0, 24):
        charge_T_arr[hour][unitid] = 0.0
        conv_T_arr[hour][unitid] = 0.0
        action_T_arr[hour][unitid] = 1.0

# base tcharge with only gap_param
#base_tcharge = calc_base_tcharge(unit_list, w_arr, obid_arr, gap_arr, big_table)

for T in range(0, 24):
    time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print("start_T samples ep %d %d %s" % (0, T, time))
        
    # get curr state
    state = get_curr_state_x(unit_list, STATE_SIZE, conv_arr, charge_arr, obid_arr, \
            cyc_rec, T, charge_T_arr, conv_T_arr, action_T_arr)

    #results = infer_exe.run(
    #    inference_program,
    #    feed={'a_state':state,},
    #    fetch_list=fetch_targets)

    print "size"
    print len(unit_list)
    
    action_value = []
    for index in range(len(unit_list)):
        unitid = unit_list[index]

        feed_dict = {s:[state[index]]}
        a1 = graph.get_tensor_by_name("Actor/eval/a/Tanh:0")
        a2 = graph.get_tensor_by_name("Actor/eval/add:0")
        [[p1]], [[p2]] = sess.run([a1, a2], feed_dict=feed_dict)
        value = p2
        action_value.append(value)

    #sys.exit()

    print "batch unit"
    #print unit_list
    #print state
    #print action
    print action_value

    # fetch conversion-credible unit (conv >= 5)
    
    for index in range(len(unit_list)):
        unitid = unit_list[index]

        pid_value_item = 1.0
        if USE_PREDICT == 1:
            print ("test1 unit:%s charge:%f conv:%d obid:%d" % (unitid, \
                    float(charge_arr[unitid]), int(conv_arr[unitid]), int(obid_arr[unitid])))
            if int(obid_arr[unitid]) > 0 and float(charge_arr[unitid]) >= (5 * int(obid_arr[unitid])):
                #pid_value_item = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
                pass
            else:
                # if the conv is not credible, set the action = 1.0
                action_value[index] = 1.0
                #pid_value_item = 1.0
        
        if USE_PREDICT == 2:
            if int(obid_arr[unitid]) > 0 and float(charge_arr[unitid]) >= (5 * int(obid_arr[unitid])):
                action_value[index] = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
            else:
                action_value[index] = 1.0
            
        action_list_arr[unitid].append(action_value[index])

    # update w_arr
    w_arr = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value, gap_arr)

    # execute T step
    hour = ("%02d" % T)
        
    check_num = 0
    total_num = 0
    for index in range(len(unit_list)):
        total_num += 1

        unitid = unit_list[index]
        unit_w = w_arr[unitid]
        key = '\t'.join(map(str, [unitid, hour, unit_w]))

        action_T_arr[T][unitid] = action_value[index]
        if key in big_table:
            check_num += 1
            fetch_list = big_table[key]
            charge_arr[unitid] += fetch_list[0]
            conv_arr[unitid] += fetch_list[1]
                    
            charge_T_arr[T][unitid] += fetch_list[0]
            conv_T_arr[T][unitid] += fetch_list[1]
        
        if T > 0:
            charge_T_arr[T][unitid] += charge_T_arr[T - 1][unitid]
            conv_T_arr[T][unitid] += conv_T_arr[T - 1][unitid]
        
    print ("total_num:%d check_num:%d" % (total_num, check_num))


# check results
action_dis_file = "./check_detail/action_dis.txt." + str(USE_PREDICT)
a_f = open(action_dis_file, "w")
for index in range(len(unit_list)):
    unitid = unit_list[index]

    action_dis_tmp = action_dis[unitid]
    base_info = []
    for hour in range(0, 24):
        charge_tmp = charge_T_arr[hour][unitid]
        conv_tmp = conv_T_arr[hour][unitid]
        obid_tmp = obid_arr[unitid]
        action_tmp = action_list_arr[unitid][hour]
        #pid_tmp = pid_list_arr[unitid][hour]
        one_info = ';'.join(map(str, [charge_tmp, conv_tmp, obid_tmp, action_tmp]))
        base_info.append(one_info)

    action_str = '#'.join(map(str, action_dis_tmp))
    base_str = '#'.join(map(str, base_info))

    a_f.write(base_str + "\t" + action_str + "\t" + str(unitid) + "\t" + \
            str(charge_arr[unitid]) + "\t" + str(conv_arr[unitid]) + "\n")

a_f.close()
     

