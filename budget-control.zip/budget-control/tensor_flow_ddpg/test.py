""" test file """

import numpy as np
for i in range(10000):
    val = np.clip(np.random.normal(1.0, 1.0), 0.5, 2.5)
    val2 = int(abs(val * 10 - 10)) * 1.0 / 10
    print val2
