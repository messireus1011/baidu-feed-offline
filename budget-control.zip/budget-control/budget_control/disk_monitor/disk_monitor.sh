# check if disk full
#receiver="wanlunjun@baidu.com,mashengjie01@baidu.com,batubatu@baidu.com,zhaixiang01@baidu.com,leiyahui@baidu.com,wanghuaidong@baidu.com,zhangsimeng@baidu.com,hanbo07@baidu.com,jiangyuzhu@baidu.com,chensitong03@baidu.com"
receiver="yangye03@baidu.com"
if [ $(df /home -h | awk '{print $5}' | awk -F '%' '{if($1<=100) print $1}') -ge 99 ]; then
    echo 'warnning, disk almost full'
    echo -e "yy-feed02: \n\n"$(df /home -h | awk 'NR==1{print $0}')"\n"$(df /home -h | awk 'NR==2{print $0}')| mutt -s "DISK FULL WARNING" $receiver
fi
