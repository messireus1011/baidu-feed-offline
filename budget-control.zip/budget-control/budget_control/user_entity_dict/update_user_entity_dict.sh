#!/bin/bash
LANG=UTF-8
DATE=`date +%Y%m%d%H%M`
TODAY=`date +%Y%m%d`

HADOOP_TURING=/home/users/yangye03/tools/hadoop_client/hadoop_turing/hadoop/bin/hadoop

data_dir=data/$TODAY
mkdir -p $data_dir
mkdir -p output

#clear histor
DELETE_DATE=$(date -d "today -3 days" +%Y%m%d)
if [ -d "./data/$DELETE_DATE" ]; then
	rm -rf ./data/$DELETE_DATE
fi

#ftp_path='ftp://10.50.14.74/home/work/var/dfdata/output/vcube/data'
ftp_path=" --http-user=getdata --http-passwd=getdata http://auth-api.baidu-int.com/output/vcube/data"
src_file='vrelation.txt'
wget ${ftp_path}/${src_file}.md5 -O ${src_file}.md5
md5sum -c ${src_file}.md5
if [ $? -ne 0 ]; then
	echo "job_$DATE is running"
	echo ${src_file} update
	wget ${ftp_path}/${src_file} -O ${src_file}
	md5sum ${src_file} > ${src_file}.md5
	cp ${src_file} $data_dir/${src_file}.$DATE
	cat ${src_file} | awk -F '\t' '{print $2"\t"$3}' | sort | uniq > u_e_dict.tmp
	if [ `cat u_e_dict.tmp | wc -l` -le 100 ]; then
		echo "u_e_dict is not ready"
		exit
	fi

	mv u_e_dict.tmp u_e_dict
	md5sum u_e_dict > u_e_dict.md5
	mv u_e_dict output/u_e_dict
	mv u_e_dict.md5 output/u_e_dict.md5

	${HADOOP_TURING} fs -rm userpath.feed_budget/user_entity_dict.txt
	${HADOOP_TURING} fs -put output/u_e_dict userpath.feed_budget/user_entity_dict.txt
else
	rm ${src_file}.md5
fi



