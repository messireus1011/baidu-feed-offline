import sys

if __name__ == '__main__':
    date = sys.argv[1]
    userid_entity = {}
    """
    for line in open('u_e_dict', 'r') :
        [userid, entity] = line.strip().split('\t')
        userid_entity[userid] = entity
    
    userid_company = {}
    for line in open('u_c_dict', 'r') :
        [userid, company] = line.strip().split('\t')
        userid_company[userid] = company
    """
    entity_company = {}
    for line in open('vrelation.txt', 'r'):
        items = line.strip().split('\t')
        userid = items[1]
        entity = items[2]
        company = items[3]
        userid_entity[userid] = entity
        entity_company[entity] = company

    entity_blk = []
    for line in open('entity_info.txt', 'r'):
        entity = line.strip().split('\t')[0]
        entity_blk.append(entity)

    for line in open('./data/user_chargeinfo_' + date, 'r'):
        #[userid, charge, o_charge, clk, o_clk, acp, o_acp, real_acp, o_ratio, clk_delay, charge_delay, o_clk_delay, o_charge_delay] = line.strip().split('\t')
        items = line.strip().split("\t")
        userid = items[0]
        entity = '-'
        company = '-'
        if userid in userid_entity:
            entity = userid_entity[userid]
        """
        if userid in userid_company :
            company = userid_company[userid]
        """
        if entity in entity_company:
            company = entity_company[entity]
        if entity not in entity_blk:
            continue
        _str = '-'
        try:
            _line = ','.join([date, entity, company] + items)
            _str =  _line.decode('UTF-8').encode('GBK')
        except:
            _line = ','.join([date, entity, '-'] + items)
            _str =  _line.decode('UTF-8').encode('GBK')
        print _str
        
