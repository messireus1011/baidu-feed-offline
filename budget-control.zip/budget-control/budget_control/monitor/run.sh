#!/bin/bash
LANG=UTF-8
set -x
start_time=$(date +%Y-%m-%d-%H:%M:%S)
echo start_time:$start_time

PYTHON_BIN="/home/work/.jumbo/bin/python"

HOME_DIR=$(cd `dirname $0`; pwd)
source done_file
DATE=`date -d "+1 days ${last_date}" "+%Y%m%d"`
#DATE=$1

echo "***** STEP1: CHECK IF JOB IS RUNNING *****"
#=====if job is running, skip this execution=====
if [ `cat job_run_state.txt | grep -E "job_$DATE is running|job_$DATE is done" | wc -l` -eq 1 ]
then
    cat job_run_state.txt
    echo "job_$DATE is runing or done, ignore this execution!"
    exit
fi

echo "***** STEP2: CHECK IF INPUTFILE IS READY *****"
cd ${HOME_DIR}


# fetch entity_info.txt
file_path="nmg01-ido-sche02.nmg01.baidu.com:/home/work/feed_over_charge_control-feedbudget-user_env/entity_info.txt"
wget ${file_path} -O entity_info.txt.tmp
if [[ `cat entity_info.txt.tmp | wc -l` -le 10 ]]; then
	echo "fetch entity_info.txt failed, exit"
	exit 1
fi
mv entity_info.txt.tmp entity_info.txt

# fetch user-entity map
entity_file=" --http-user=getdata --http-passwd=getdata http://auth-api.baidu-int.com/output/vcube/data/vrelation.txt"
wget ${entity_file}.md5 -O vrelation.txt.md5
md5sum -c vrelation.txt.md5
if [ $? -ne 0 ]; then
	wget ${entity_file} -O vrelation.txt
	cat vrelation.txt | awk -F '\t' '{print $2"\t"$3}' | sort | uniq > u_e_dict.tmp
	if [[ `cat u_e_dict.tmp | wc -l` -le 10 ]]; then
		echo "u_e_dict is not ready"
		exit 1
	fi
fi
mv u_e_dict.tmp u_e_dict

user_charge_file=ftp://yq01-im-machine-0524-2.epc.baidu.com/home/mashengjie01/mashengjie/statistic/charge_info/data/user_chargeinfo_${DATE}
wget ${user_charge_file} -O ./data/user_chargeinfo_${DATE}
if [[ $? -ne 0 ]]
then
	echo "user_charge_file $DATE is not ready"
	echo "job_${DATE} is waiting for user_charge_file" > job_run_state.txt
	rm ./data/user_chargeinfo_${DATE}
	exit
fi


# update user_info
#${HADOOP_KHAN} fs -cat 

echo "***** STEP3: DATA IS READY, START RUNNING, GOOD LUCK *****"
echo "job_$DATE is running" > job_run_state.txt

${PYTHON_BIN} _stat.py $DATE | sort -k2n,2 -k3n,3 > ./data/entity_userid_charge_${DATE}.csv
#if [[ $? -ne 0 || `cat ./data/entity_userid_charge_${DATE}.csv | wc -l` -eq 0 ]]
if [[ $? -ne 0 ]]
then
    cd ${HOME_DIR}
    echo "job_${DATE} is failed" > job_run_state.txt
    echo job_$DATE failed, job started at $start_time | mutt -s "ENTITY BLKLIST MONITOR ($DATE) FAILED" wanlunjun@baidu.com
    echo job_$DATE fialed
	rm ./data/entity_userid_charge_${DATE}.csv
    exit
fi

#cat ./data/entity_userid_charge_${DATE}.csv ./data/entity_userid_charge.csv | sort -k1nr | uniq > ./data/entity_userid_charge.csv.tmp
#mv ./data/entity_userid_charge.csv.tmp ./data/entity_userid_charge.csv

cat ./data/entity_userid_charge_${DATE}.csv ./data/entity_userid_charge.csv | grep -v acp | sort -k1nr | uniq > ./data/entity_userid_charge.csv.tmp
cat headline.txt ./data/entity_userid_charge.csv.tmp > ./data/entity_userid_charge.csv
mv ./data/entity_userid_charge.csv.tmp

cd ${HOME_DIR}
end_time=$(date +%Y-%m-%d-%H:%M:%S)
echo end_time:$end_time

echo "***** STEP4: SEND INFORM MAIL ******"
~/.jumbo/bin/python send_monitor_mail.py $DATE

#rm u_e_dict

cd ${HOME_DIR}
echo "job_${DATE} is done" > job_run_state.txt

echo "last_date=${DATE}" > done_file

echo "***** job_${DATE} successed, all done! *****"
