""" describe """
import sys

def load_cmatch_srcid():
    """ attribute """
    _dict = {}
    for line in open('cmatch_srcid.txt', 'r'):
        [cmatch, srcid] = line.strip().split('\t')
        _dict[cmatch] = srcid
    return _dict


def load_srcid_cmatch():
    """ attribute """
    _dict = {}
    for line in open('cmatch_srcid.txt', 'r'):
        [cmatch, srcid] = line.strip().split('\t')
        _dict[srcid] = cmatch
    return _dict


def load_srcid():
    """ attribute """
    _list = []
    for line in open('cmatch_srcid.txt', 'r'):
        [cmatch, srcid] = line.strip().split('\t')
        if srcid not in _list:
            _list.append(srcid)
    return _list


def load_list(file_name):
    """ attribute """
    _list = []
    for line in open(file_name, 'r'):
        line = line.strip()
        if line not in _list:
            _list.append(line)
    return _list


def load_manual_ctrl():
    """ attribute """
    _manual_dict = {}
    for line in open("pm_manual_add_file"):
        try:
            [id_type, id_value, prob] = line.strip().split("\t")
        except:
            continue
        key = id_type + "\t" + id_value
        _manual_dict[key] = prob

    for line in open("rd_manual_add_file"):
        try:
            [id_type, id_value, prob] = line.strip().split("\t")
        except:
            continue
        key = id_type + "\t" + id_value
        _manual_dict[key] = prob

    return _manual_dict


def load_u_e():
    """ attribute """
    _dict = {}
    for line in open('u_e_dict', 'r'):
        [user, entity] = line.strip().split('\t')
        _dict[user] = entity
    return _dict


def add_dict(_dict, key, value):
    """ attribute """
    if key not in _dict:
        _dict[key] = [0, 0, 0, 0]
    _dict[key][0] += int(value[0])
    _dict[key][1] += float(value[1])
    _dict[key][2] += int(value[2])
    _dict[key][3] += float(value[3])
    return _dict


def load_charge(_file):
    """ attribute """
    cmatch_src = load_cmatch_srcid()
    user_entity = load_u_e()
    _dict = {}
    for line in open(_file, 'r'):
        try:
            [key, clk, charge, clk_ign, charge_ign] = line.strip().split('\t')
            [userid, planid, unitid, cmatch] = key.strip().split('_')
        except:
            continue
        value = [clk, charge, clk_ign, charge_ign]
        src_id = '-'
        entity = '-'
        if cmatch in cmatch_src:
            src_id = cmatch_src[cmatch]
        if userid in user_entity:
            entity = user_entity[userid]

        UNITID_DIM = '1'
        PLANID_DIM = '2'
        USERID_DIM = '3'
        ENTITYID_DIM = '4'

        key = '_'.join(['*', UNITID_DIM, unitid])
        add_dict(_dict, key, value)
        key = '_'.join(['*', PLANID_DIM, planid])
        add_dict(_dict, key, value)
        key = '_'.join(['*', USERID_DIM, userid])
        add_dict(_dict, key, value)
        key = '_'.join(['*', ENTITYID_DIM, entity])
        add_dict(_dict, key, value)

        key = '_'.join([src_id, UNITID_DIM, unitid])
        add_dict(_dict, key, value)
        key = '_'.join([src_id, PLANID_DIM, planid])
        add_dict(_dict, key, value)
        key = '_'.join([src_id, USERID_DIM, userid])
        add_dict(_dict, key, value)
        key = '_'.join([src_id, ENTITYID_DIM, entity])
        add_dict(_dict, key, value)

    return _dict


def do_budget_pacing(_dict):
    """ attribute """
    cmatchs = ['700', '669', '719', '710', '687', '607', '720', '547', '606']
    src_ids = ['1092', '1093', '1197', '1152', '1153', '1211', '1288', '1306', '1262', '1308', '1094',\
            '1244', '1293', '1177', '1178']
    ###static userid pacing rate
    ##_file = "static_userid_pacing"
    ##static_userid_list = load_list(_file)
    ##srcid_list = load_srcid()
    manual_dict = load_manual_ctrl()
    srcid_dict = load_srcid_cmatch()

    for key in _dict:
        [clk, charge, clk_ign, charge_ign] = _dict[key]
        [srcid, id_dim, id_value] = key.strip().split('_')
        charge = float(charge)
        charge_ign = float(charge_ign)

        if srcid != '*':
            continue
        if id_dim == '4':
            continue
        show_prob = 1.0

        if charge < 200 and (charge_ign < (charge * 0.5) or charge_ign < 50):
            continue

        if charge_ign > charge * 0.05:
            show_prob = pow(charge / (charge + charge_ign), 4)

        #if charge_ign > charge * 0.05:
        #    show_prob = 0.1 * pow(charge / (charge + charge_ign), 2)

        if show_prob < 0.0001:
            show_prob = 0.0001

        if show_prob < 1.0:
            key = id_dim + "\t" + id_value
            if key in manual_dict:
                #if float(show_prob) < float(manual_dict[key]):
                #    manual_dict[key] = show_prob
                continue
            for srcid in srcid_dict:
                print '\t'.join([srcid, id_dim, id_value, str(round(show_prob, 4))])

    for srcid in srcid_dict:
        for key in manual_dict:
            print '\t'.join([srcid, key, str(manual_dict[key])])


def do_low_budget_pacing(_dict):
    """ attribute """
    # srcid=0,id_dim=0,id=0,ratio=x
    # srcid=x,id_dim=0,id=0,ratio=y
    # srcid=0,id_dim=2,planid=x,ratio=x
    # srcid=0,id_dim=3,userid=x,ratio=x
    cmatch_src = load_cmatch_srcid()
    default_ratio = 0.05
    print '\t'.join(['0', '0', '0', str(default_ratio)])
    for cmatch in cmatch_src:
        srcid = cmatch_src[cmatch]
        print '\t'.join([srcid, '0', '0', str(default_ratio)])

    UNITID_DIM = '1'
    PLANID_DIM = '2'
    USERID_DIM = '3'
    ENTITYID_DIM = '4'

    new_dict = {}
    for key in _dict:
        [clk, charge, clk_ign, charge_ign] = _dict[key]
        [srcid, id_dim, id_value] = key.strip().split('_')

        if srcid == '*': continue

        if id_dim not in [PLANID_DIM]:
            continue
        key = id_dim + '_' + id_value
        if key not in new_dict:
            new_dict[key] = [0, 0, 0, 0]
        new_dict[key][0] += int(clk)
        new_dict[key][1] += float(charge)
        new_dict[key][2] += int(clk_ign)
        new_dict[key][3] += float(charge_ign)

    for key in new_dict:
        [clk, charge, clk_ign, charge_ign] = new_dict[key]
        [id_dim, id_value] = key.strip().split('_')
        charge = float(charge)
        charge_ign = float(charge_ign)
        clk = int(clk)
        clk_ign = int(clk)
        # low_budget_pacing white_list
        if charge < 200 and charge > 10 and charge_ign < 15:
            print '\t'.join(['0', id_dim, id_value, '1.0'])


if __name__ == '__main__':
    """ attribute """
    _file = sys.argv[1]
    _file_today = sys.argv[2]
    _dict = load_charge(_file)
    _dict_today = load_charge(_file_today)
    do_budget_pacing(_dict)
    do_low_budget_pacing(_dict_today)
