#!/bin/bash
set -x
start_time=$(date +%Y-%m-%d-%H:%M:%S)
echo start_time:$start_time

HOME_DIR=$(cd `dirname $0`; pwd)

#PYTHON_BIN=/home/work/.jumbo/bin/python
PYTHON_BIN=python27/bin/python2.7

function update_pm_file()
{
	ftp_path='ftp://zongkong.baidu.com/home/work/zongkong/userdata/26/over_charge_prob_control_manual'
	src_file='over_charge_prob_control_manual_zk.txt'
	wget ${ftp_path}/${src_file} -O ${src_file}
	cat ${src_file} | awk -F '\t' '{print $1"\t"$2"\t"$3}' > pm_manual_add_file.tmp
	if [[ `cat pm_manual_add_file.tmp | wc -l` -le 10 ]]; then
		echo "wget pm_manual_add_file failed"
		return 1
	fi

	mv pm_manual_add_file.tmp pm_manual_add_file

}

function update_dict()
{
	ftp_path=$1
	src_file=$2
	file_name=$3
	wget ${ftp_path}/${src_file}.md5 -O ${src_file}.md5
	cp ./dict/${file_name} ${src_file}
	md5sum -c ${src_file}.md5
	if [ $? -ne 0 ]; then
		echo ${file_name} update
		wget ${ftp_path}/${src_file} -O ${file_name}
		md5sum ${file_name} > ${file_name}.md5
		mv ${file_name} ./dict/
		mv ${file_name}.md5 ./dict/
		rm -f ${src_file} ${src_file}.md5
	else
		rm ${src_file} ${src_file}.md5
	fi
}

function get_ue_dict()
{
	#entity_file=ftp://10.50.14.74/home/work/var/dfdata/output/vcube/data/vrelation.txt
	entity_file=" --http-user=getdata --http-passwd=getdata http://auth-api.baidu-int.com/output/vcube/data/vrelation.txt"
	wget ${entity_file} -O vrelation.txt
	cat vrelation.txt | awk -F '\t' '{print $2"\t"$3}' | sort | uniq > u_e_dict.tmp
	if [[ `cat u_e_dict.tmp | wc -l` -le 10 ]]; then
		echo "u_e_dict is not ready"
		return 1
	fi

	mv u_e_dict.tmp u_e_dict
}

function clear_history()
{
	DATE=$(date -d "today -7 days" +%Y%m%d)
	if [ -d "./data/$DATE" ]; then
		rm -rf ./data/$DATE
		rm ./dict/realtime_consume_$DATE*
	fi
}

function budget_pacing()
{
	DATE1=$(date -d "today" +%Y%m%d)
	DATE2=$(date -d "today -1 days" +%Y%m%d)
	DATE3=$(date -d "today -2 days" +%Y%m%d)
	echo $DATE1 $DATE2 $DATE3

	get_ue_dict
	if [ $? -ne 0 ]; then
		echo "get u_e_dict fail"
		return 2
	fi

	update_pm_file

	if [ ! -d "./data/$DATE1" ]; then
		mkdir -p ./data/$DATE1
	fi

	#ftp_path='ftp://cp01-rdqa-fcr021.cp01.baidu.com/home/work/wanlunjun/online_deploy/feed_budget_control/budget_allocation/output/'
	#ftp_path='ftp://nmg01-ido-sche02.nmg01.baidu.com:/home/work/budget_allocation-feedbudget-user_env/output/'
	ftp_path='xafj-sys-rpm460.xafj.baidu.com:/home/work/budget_allocation-xafj_feedbudget-user_env/output/'
	file_name1=realtime_consume_${DATE1}.txt
	update_dict ${ftp_path} ${file_name1} ${file_name1}
	file_name2=realtime_consume_${DATE2}.txt
	update_dict ${ftp_path} ${file_name2} ${file_name2}
	file_name3=realtime_consume_${DATE3}.txt
	update_dict ${ftp_path} ${file_name3} ${file_name3}

	cat ./dict/${file_name1} ./dict/${file_name2} > adv_charge.txt
	if [[ `cat adv_charge.txt | wc -l` -le 100 ]]; then
		echo "get adv_charge failed"
		return 2
	fi

	cat ./dict/${file_name1} ./dict/${file_name2} ./dict/${file_name3} > adv_charge_up.txt
	if [[ `cat adv_charge_up.txt | wc -l` -le 100 ]]; then
		echo "get adv_charge_up failed"
		return 2
	fi
	
	cat ./dict/${file_name1} > adv_charge_today.txt
	if [[ `cat adv_charge_today.txt | wc -l` -le 100 ]]; then
		echo "get adv_charge failed"
		return 2
	fi

	datatime=`date +%Y%m%d%H%M`

	${PYTHON_BIN} budget_pacing.py adv_charge_up.txt adv_charge_today.txt | sort | uniq > over_charge_show_prob_dict.txt.tmp
	#cp ./dict/over_charge_show_prob_dict.txt over_charge_show_prob_dict.txt.bk
	mv over_charge_show_prob_dict.txt.tmp over_charge_show_prob_dict.txt
	md5sum over_charge_show_prob_dict.txt > over_charge_show_prob_dict.txt.md5
	cp over_charge_show_prob_dict.txt ./data/$DATE1/over_charge_show_prob_dict.txt.$datatime
	mv over_charge_show_prob_dict.txt ./dict/
	mv over_charge_show_prob_dict.txt.md5 ./dict/

	#${PYTHON_BIN} budget_pacing_1.py adv_charge_up.txt adv_charge_today.txt | sort | uniq > over_charge_show_prob_dict.txt_1
	#md5sum over_charge_show_prob_dict.txt_1 > over_charge_show_prob_dict.txt_1.md5
	#mv over_charge_show_prob_dict.txt_1 ./dict/
	#mv over_charge_show_prob_dict.txt_1.md5 ./dict/

	#${PYTHON_BIN} budget_pacing_2.py adv_charge_up.txt adv_charge_today.txt | sort | uniq > over_charge_show_prob_dict.txt_2
	#md5sum over_charge_show_prob_dict.txt_2 > over_charge_show_prob_dict.txt_2.md5
	#mv over_charge_show_prob_dict.txt_2 ./dict/
	#mv over_charge_show_prob_dict.txt_2.md5 ./dict/

	#${PYTHON_BIN} budget_pacing_3.py adv_charge_up.txt adv_charge_today.txt | sort | uniq > over_charge_show_prob_dict.txt_3
	#md5sum over_charge_show_prob_dict.txt_3 > over_charge_show_prob_dict.txt_3.md5
	#mv over_charge_show_prob_dict.txt_3 ./dict/
	#mv over_charge_show_prob_dict.txt_3.md5 ./dict/
}

function run_once()
{
	if [[ `cat job_state.txt | grep -E "run" | wc -l` -eq 1 ]]; then
		echo job is running, break
		return
	else
		echo start running job
		echo run > job_state.txt
	fi

	budget_pacing
	if [ $? -ne 0 ]; then
		echo "do budget_pacing failed"
		echo 'fail' > job_state.txt
	else
		echo "do budget_pacing suc"
		echo 'done' > job_state.txt
	fi

	clear_history
}

run_once
