#!/bin/bash

set -x

PYTHON_BIN=python27/bin/python2.7
HADOOP_TURING=/home/users/yangye03/tools/hadoop_client/hadoop_turing/hadoop/bin/hadoop

function update_whitelist_file()
{
	#ftp_path='ftp://zongkong.baidu.com/home/work/zongkong/userdata/18/feed_overcharge_entity_whitelist'
	#src_file='feed_overcharge_entity_whitelist_zk.txt'
	ftp_path='http://zongkong.baidu.com/home/work/zongkong/userdata/93/feed_overcharge_entity_whitelist_2021/'
	src_file='feed_overcharge_entity_whitelist_2021_zk.txt'
	wget ${ftp_path}/${src_file} -O ${src_file}
	cat ${src_file} | awk -F '\t' '{print $1"\t"$2"\t"}' > whitelist.txt.tmp
	if [[ `cat whitelist.txt.tmp | wc -l` -le 1 ]]; then
		echo "fetch whitelist failed"
		return 1
	fi

	mv whitelist.txt.tmp whitelist.txt
}

function update_blacklist_file()
{
	ftp_path='ftp://zongkong.baidu.com/home/work/zongkong/userdata/63/feed_overcharge_entity_blacklist/'
	src_file='feed_overcharge_entity_blacklist_zk.txt'
	wget ${ftp_path}/${src_file} -O ${src_file}
	cat ${src_file} | awk -F '\t' '{print $1}' > blacklist.txt.tmp
	if [[ `cat blacklist.txt.tmp | wc -l` -le 1 ]]; then
		echo "fetch blacklist failed"
		return 1
	fi

	mv blacklist.txt.tmp blacklist.txt
}

function get_ue_dict()
{
	entity_file=" --http-user=getdata --http-passwd=getdata http://auth-api.baidu-int.com/output/vcube/data/vrelation.txt"
	wget ${entity_file}.md5 -O vrelation.txt.md5
	md5sum -c vrelation.txt.md5
	if [ $? -eq 0 ]; then
		echo "u_e_dict source not update, continue"
		return 0
	fi

	wget ${entity_file} -O vrelation.txt
	cat vrelation.txt | awk -F '\t' '{print $2"\t"$3}' | sort | uniq > u_e_dict.tmp
	if [[ `cat u_e_dict.tmp | wc -l` -le 10 ]]; then
		echo "u_e_dict is not ready"
		return 1
	fi

	mv u_e_dict.tmp u_e_dict
}

function get_entity_blacklist()
{
	DATE=$1
	TIME=$2

	data_dir=data/$DATE
	save_dir=data/save_data
	mkdir -p $data_dir
	mkdir -p $save_dir

	file_name=consume_${DATE}${TIME}.txt
	#file_path=cp01-rdqa-fcr021.cp01.baidu.com:/home/work/wanlunjun/online_deploy/feed_budget_control/budget_allocation/data/$DATE/$file_name
	#file_path=ftp://nmg01-ido-sche02.nmg01.baidu.com:/home/work/budget_allocation-feedbudget-user_env/data/$DATE/$file_name
	#file_path=xafj-sys-rpm460.xafj.baidu.com:/home/work/budget_allocation-xafj_feedbudget-user_env/data/$DATE/$file_name
	file_path=ftp://feed02:feed02@yy-feed02.bcc-bdbl.baidu.com/home/users/yangye03/dict_online/feed_budget/ido/budget_allocation/data/$DATE/$file_name
	
	wget $file_path -O $data_dir/$file_name 

	if [ $? -ne 0 ]; then
		echo "$file_name is not ready, exit"
		return 2
	fi

	# check output file
	#if [ `cat $data_dir/$file_name | wc -l` -le 100 ]; then
	#	echo get consume $DATE $TIME failed!
	#	rm $data_dir/$file_name
	#	return 3
	#fi

	# fetch user-entity map
	get_ue_dict
	if [ $? -ne 0 ]; then
		echo "get u_e_dict failed"
		return 2
	fi

	update_whitelist_file
	update_blacklist_file

	realtime_file=$data_dir/realtime_consume_${DATE}${TIME}
	cat $data_dir/consume_${DATE}*.txt | ${PYTHON_BIN} run_fun.py merge_today_consume > $realtime_file
	if [ `cat $realtime_file | wc -l` -le 10 ]; then
		echo get realtime consume $DATE $TIME failed!
		rm $realtime_file
		return 3
	fi

	cat $realtime_file | ${PYTHON_BIN} entity_trial.py $DATE
	if [[ $? -ne 0 || `cat entity_info.txt.new | wc -l` -le 10 || `cat entity_blacklist.txt.new | wc -l` -le 10 ]]; then
		echo "run entity_trial.py $DATE fail"
		rm entity_info.txt.new
		rm entity_blacklist.txt.new
		return 2
	fi

	cat entity_info.txt.new | sort -k2nr > entity_info.txt.tmp
	cp entity_info.txt.tmp $save_dir/entity_info.txt.${DATE}${TIME} 
	mv entity_info.txt.tmp entity_info.txt
	cp entity_info.txt output/
	rm entity_info.txt.new
	

	cp entity_blacklist.txt.new $save_dir/entity_blacklist.txt.${DATE}${TIME}
	mv entity_blacklist.txt.new entity_blacklist.txt
	md5sum entity_blacklist.txt > entity_blacklist.txt.md5
	mv entity_blacklist.txt output/
	mv entity_blacklist.txt.md5 output/

	${HADOOP_TURING} fs -rm userpath.feed_budget/entity_blacklist.txt
	${HADOOP_TURING} fs -put output/entity_blacklist.txt userpath.feed_budget/

}

function clear_history()
{
	# clear history file
	DATE=$(date -d "today -7 days" +%Y%m%d)
	if [ -d "./data/$DATE" ]; then
		rm -rf ./data/$DATE
	fi

	DATE2=$(date -d "today -100 days" +%Y%m%d)
	rm ./data/save_data/*${DATE2}*
	echo "finish clear history"
}

function run_once()
{
	source ./done_file
	time_point=$(date +%s -d "$last_time")
	time_step=$((15*60)) #15min
	time1=$(date +%Y-%m-%d\ %H:%M:%S -d "1970-01-01 UTC $(($time_point+$time_step)) seconds");
	DATE1=$(date -d "$time1" +%Y%m%d) #20160306
	TIME1=$(date -d "$time1" +%H%M) #2145

	if [[ `cat job_state.txt | grep -E "run" | wc -l` -eq 1 ]]; then
		echo job is running, break
		return
	else
		echo start running job $DATE1 $TIME1
		echo run > job_state.txt
	fi
	get_entity_blacklist $DATE1 $TIME1
	if [ $? -ne 0 ]; then
		echo "get charge real $DATE1 $TIME1 fail"
		echo 'fail' > job_state.txt
	else
		echo "get charge real $DATE1 $TIME1 suc"
		echo 'done' > job_state.txt
		echo "last_time=\"${time1}\"" > done_file
		#run_date=`date -d "+1 days ${run_date}" "+%Y%m%d"`
		clear_history
	fi
}

run_once
