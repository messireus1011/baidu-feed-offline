import sys
import time

def merge_today_consume():
    dicts = {}
    for line in sys.stdin:
        items = line.strip().split('\t')
        try:
            [key, clk, charge, clk_ign, charge_ign] = items

            # filter bes
            [uid, planid, unitid, cmatch] = key.strip().split('_')
            if cmatch in ['670', '671', '672', '673', '700', '713', '716', '782', \
                    '795', '796', '797', '798', '799', '891', '896', '973', '1354', '710']:
                continue

            if key not in dicts:
                dicts[key] = [0, 0, 0, 0]
            dicts[key][0] += int(clk)
            dicts[key][1] += float(charge)
            dicts[key][2] += int(clk_ign)
            dicts[key][3] += float(charge_ign)
        except:
            continue
    
    for key in dicts:
        try:
            [clk, charge, clk_ign, charge_ign] = dicts[key]
            print '\t'.join([key, str(clk), str(charge), str(clk_ign), str(charge_ign)])
        except:
            continue

if __name__ == '__main__':
    exec sys.argv[1] + '()'
