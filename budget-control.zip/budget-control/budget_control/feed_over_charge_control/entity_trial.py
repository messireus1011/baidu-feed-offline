""" entity_trail """
import sys
import datetime

def get_evidence():
    """ get_evidence"""
    uid_entity = {}
    for line in open('u_e_dict', 'r'):
        [uid, entity] = line.strip().split('\t')
        uid_entity[uid] = entity

    print len(uid_entity)

    entity_charge = {}
    for line in sys.stdin:
        items = line.strip().split('\t')
        try:
            [key, clk, charge, clk_ign, charge_ign] = items
            [uid, planid, unitid, cmatch] = key.strip().split('_')
            if uid in uid_entity:
                entity = uid_entity[uid]
                if entity not in entity_charge:
                    entity_charge[entity] = [0, 0]
                entity_charge[entity][0] += float(charge)
                entity_charge[entity][1] += float(charge_ign)
        except:
            continue

    print len(entity_charge)

    return entity_charge

def calc_n_days(date, n):
    """ calc_n_days """
    base_date = datetime.datetime.strptime(str(date), '%Y%m%d')
    delta = datetime.timedelta(days=n)
    n_days = base_date + delta
    return n_days.strftime('%Y%m%d')

def EntityTrial(date):
    """ entity trial """
    entity_charge = get_evidence()
    entity_dict = {}

    for line in open('entity_info.txt', 'r'):
        try:
            [entity, InPrison, OutPrison, ChargeInfo, times, LastTime] = line.strip().split('\t')
            entity_dict[entity] = [int(InPrison), int(OutPrison), ChargeInfo, int(times), int(LastTime)]
        except:
            continue

    for entity in entity_charge:
        try:
            [charge, ocharge] = entity_charge[entity]
        except:
            continue
        if charge == 0:
            continue
        rule1 = ocharge > 200000 and ocharge > 0.5 * charge
        rule2 = ocharge > 100000 and ocharge > 0.5 * charge
        rule3 = ocharge > 50000 and ocharge > 1 * charge
        rule4 = ocharge > 30000 and ocharge > 2 * charge
        rule5 = ocharge > 10000 and ocharge > 5 * charge
        days = 0
        if rule1:
            days = 365
        elif rule2:
            days = 180
        elif rule3:
            days = 90
        elif rule4:
            days = 15
        elif rule5:
            days = 7
        else:
            continue

        InPrison = int(date)
        OutPrison = int(calc_n_days(InPrison, days))
        ChargeInfo = str(round(ocharge, 2)) + '_' + str(round(charge, 2))
        if entity in entity_dict:
            try:
                [old_in, old_out, old_info, times, last_time] = entity_dict[entity]
                if int(InPrison) == int(last_time):
                    # today has alread updated this entity
                    if int(times) > 1:
                        # this entity is alread in the file before today
                        days = 2 * days
                    OutPrison = int(calc_n_days(InPrison, days))
                    entity_dict[entity][0] = [old_in, InPrison][OutPrison >= old_out]
                    entity_dict[entity][1] = [old_out, OutPrison][OutPrison >= old_out]
                    entity_dict[entity][2] = [old_info, ChargeInfo][OutPrison >= old_out]
                    entity_dict[entity][3] = str(times)
                    entity_dict[entity][4] = str(InPrison)
                else:
                    days = 2 * days
                    OutPrison = int(calc_n_days(InPrison, days))
                    entity_dict[entity][0] = [old_in, InPrison][OutPrison > old_out]
                    entity_dict[entity][1] = [old_out, OutPrison][OutPrison > old_out]
                    entity_dict[entity][2] = [old_info, ChargeInfo][OutPrison > old_out]
                    entity_dict[entity][3] = str(times + 1)
                    entity_dict[entity][4] = str(InPrison)
            except:
                continue
        else:
            entity_dict[entity] = [InPrison, OutPrison, ChargeInfo, '1', str(InPrison)]
        print entity, entity_dict[entity], entity_charge[entity], ocharge / charge

    return entity_dict

def TrialExecution(entity_dict, date):
    """ trial execution """
    today = int(date)
    print "ppp: :" + str(today) + " " + str(len(entity_dict))
    fp = open('entity_info.txt.new', 'w')
    for entity in entity_dict:
        try:
            [InPrison, OutPrison, ChargeInfo, times, LastTime] = entity_dict[entity]
            if int(OutPrison) >= today:
                print entity, InPrison, OutPrison
                fp.write('\t'.join([str(entity), str(InPrison), str(OutPrison), \
                        ChargeInfo, str(times), str(LastTime)]) + '\n')
        except:
            continue

def UpdateBlacklist(entity_dict, date):
    """ update blacklist """
    white_dict = {}
    for line in open('whitelist.txt', 'r'):
        try:
            items = line.strip().split('\t')
            entity = items[0]
            ing_date = items[1]
        except:
            continue
        if entity not in white_dict:
            white_dict[entity] = 0
        if int(ing_date) > white_dict[entity]:
            white_dict[entity] = int(ing_date)
        #white_dict['428540090'] = 20190731
        #white_dict['428361270'] = 20190731

    fp = open('entity_blacklist.txt.new', 'w')
    today = int(date)
    for entity in entity_dict:
        try:
            [InPrison, OutPrison, ChargeInfo, times, LastTime] = entity_dict[entity]
        except:
            continue
        if entity in white_dict:
            if int(InPrison) <= int(white_dict[entity]):
                continue
        if int(OutPrison) >= today:
            fp.write(str(entity) + '\n')

    for line in open('blacklist.txt', 'r'):
        try:
            black_items = line.strip().split('\t')
            black_entity = black_items[0]
            if black_entity != "":
                fp.write(black_entity + '\n')
        except:
            continue
    #fp.write('428942087' + '\n')
    #fp.write('428922507' + '\n')

if __name__ == '__main__':
    date = sys.argv[1]
    trail_result = EntityTrial(date)
    TrialExecution(trail_result, date)
    UpdateBlacklist(trail_result, date)
