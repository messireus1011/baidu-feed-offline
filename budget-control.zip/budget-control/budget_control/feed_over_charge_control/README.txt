
when you plan to update code on ido, please
1. check file  done_file & job_state
2. update file entity_info.txt
