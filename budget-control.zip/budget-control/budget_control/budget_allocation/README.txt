1. check the time in file <done_file> 
   when you plan to update the code on ido
