#!/bin/bash

source ./run.conf
set -x

function get_consume()
{
	DATE=$1
	TIME=$2
	
	hdfs_path=${HDFS_BAIHUA}/app/dt/minos/5685/textlog/SHIFEN/dr_toad_native_charge/70023845/${DATE}/${TIME}/
	if [ `${HADOOP_TIANQI} dfs -ls $hdfs_path/*/*log.md5 | grep log.md5 | wc -l` -ne 1 ]; then
		echo chagre log $DATE $TIME is not ready, exit.
		return 2
	fi
	
	hdfs_path=${HDFS_BAIHUA}/app/dt/minos/5685/textlog/SHIFEN/dr_toad_native_ign/70023844/${DATE}/${TIME}/
	if [ `${HADOOP_TIANQI} dfs -ls $hdfs_path/*/*log.md5 | grep log.md5 | wc -l` -ne 1 ]; then
		echo ign log $DATE $TIME is not ready, exit.
		return 2
	fi

	if [ ! -d "./data/$DATE" ]; then
		mkdir ./data/$DATE
	fi

	if [ ! -d "./bak/$DATE" ]; then
		mkdir ./bak/$DATE
	fi
	
	charge_log=${HDFS_BAIHUA}/app/dt/minos/5685/textlog/SHIFEN/dr_toad_native_charge/70023845/${DATE}/${TIME}/*/*.log
	ign_log=${HDFS_BAIHUA}/app/dt/minos/5685/textlog/SHIFEN/dr_toad_native_ign/70023844/${DATE}/${TIME}/*/*.log

	${HADOOP_TIANQI} dfs -cat ${charge_log} ${ign_log} | ${PYTHON_BIN} get_consume.py map $DATE | sort > consume_${DATE}${TIME}.txt
	# check output file
	if [ `cat consume_${DATE}${TIME}.txt | wc -l` -le 10 ]; then
		echo get consume $DATE $TIME failed!
		rm consume_${DATE}${TIME}.txt
		
		#try again
		sleep 5m
		${HADOOP_TIANQI} dfs -cat ${charge_log} ${ign_log} | ${PYTHON_BIN} get_consume.py map $DATE | sort > consume_${DATE}${TIME}.txt
		if [ `cat consume_${DATE}${TIME}.txt | wc -l` -le -1 ]; then
			echo get consume $DATE $TIME failed agin!
			rm consume_${DATE}${TIME}.txt
			return 3
		fi
	fi
	mv consume_${DATE}${TIME}.txt ./data/$DATE/
	cat ./data/$DATE/consume_${DATE}*.txt | ${PYTHON_BIN} get_consume.py reduce > realtime_consume_${DATE}.txt
	if [ `cat realtime_consume_${DATE}.txt | wc -l` -le 10 ]; then
		echo get realtime consume $DATE failed!
		rm realtime_consume_${DARE}.txt
		return 3
	fi
	md5sum realtime_consume_${DATE}.txt > realtime_consume_${DATE}.txt.md5
	#cp realtime_consume_${DATE}.txt src_plan_consume_dict.txt
	#md5sum src_plan_consume_dict.txt > src_plan_consume_dict.txt.md5
	#cp src_plan_consume_dict.txt realtime_consume_${DATE}${TIME}.txt
	#md5sum realtime_consume_${DATE}${TIME}.txt > realtime_consume_${DATE}${TIME}.txt.md5
	#mv realtime_consume_${DATE}${TIME}.txt ./bak/${DATE}/
	#mv realtime_consume_${DATE}${TIME}.txt.md5 ./bak/${DATE}/
	mv realtime_consume_${DATE}.txt ./output/
	mv realtime_consume_${DATE}.txt.md5 ./output/
	#mv src_plan_consume_dict.txt ./output/
	#mv src_plan_consume_dict.txt.md5 ./output/
}

function clear_history()
{
	# clear history file
	DATE=$(date -d "today -10 days" +%Y%m%d)
	if [ -d "./data/$DATE" ]; then
		rm -rf ./data/$DATE
	fi
	#if [ -d "./bak/$DATE" ]; then
	#	rm -rf ./bak/$DATE
	#fi

	DATE2=$(date -d "today -100 days" +%Y%m%d)
	rm ./output/realtime_consume_${DATE2}.txt*

	echo "finish clear history"
}

function run_once()
{
	source ./done_file
	time_point=$(date +%s -d "$last_time")
	time_step=$((15*60)) #15min
	time1=$(date +%Y-%m-%d\ %H:%M:%S -d "1970-01-01 UTC $(($time_point+$time_step)) seconds");
	time2=$(date +%Y-%m-%d\ %H:%M:%S -d "1970-01-01 UTC $(($time_point+$time_step+$time_step)) seconds");
	DATE1=$(date -d "$time1" +%Y%m%d) #20160306
	TIME1=$(date -d "$time1" +%H%M) #2145
	DATE2=$(date -d "$time2" +%Y%m%d) #20160306
	TIME2=$(date -d "$time2" +%H%M) #2200

	if [[ `cat job_state.txt | grep -E "run" | wc -l` -eq 1 ]]; then
		echo job is running, break
		return
	else
		echo start running job $DATE1 $TIME1
		echo run > job_state.txt
	fi
	get_consume $DATE1 $TIME1
	if [ $? -ne 0 ]; then
		echo "get charge real $DATE1 $TIME1 fail"
		echo 'fail' > job_state.txt
	else
		echo "get charge real $DATE1 $TIME1 suc"
		echo 'done' > job_state.txt
		echo "last_time=\"${time1}\"" > done_file
		run_date=`date -d "+1 days ${run_date}" "+%Y%m%d"`
		clear_history
	fi
}

run_once
