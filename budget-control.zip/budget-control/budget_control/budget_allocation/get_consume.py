""" get consume data """
import sys
import time

def map():
    """ pre process """
    date = sys.argv[2]
    dicts = {}
    for line in sys.stdin:
        line = line[:-1]
        flds = line.split('\t')
        usrid = flds[7]
        planid = flds[8]
        unitid = flds[9]
        cmatch = flds[18]
        price = flds[15]
        cur_time = flds[28]
        ign = flds[41]
        if ign == 'IGN_BELIEVE':
            continue
        elif ign == '-':
            ign = 'succ'
        else:
            ign = 'fail'
        if cmatch == '0' and unitid == '0' and ign == 'fail':
            continue
        time_tmp = time.strptime(cur_time, "%Y-%m-%d %H:%M:%S")
        #time_int = time.strftime("%Y%m%d%H%M%S", time_tmp)
        time_tmp = str(time.strftime("%Y%m%d", time_tmp))
        if time_tmp != date:
            continue
         
        key = '_'.join([usrid, planid, unitid, cmatch])
        if key not in dicts:
            dicts[key] = [0, 0, 0, 0]
        if ign == 'succ':
            dicts[key][0] += 1
            dicts[key][1] += float(price)
        if ign == 'fail':
            dicts[key][2] += 1
            dicts[key][3] += float(price)
    for key in dicts:
        [clk, charge, clk_ign, charge_ign] = dicts[key]
        print '\t'.join([key, str(clk), str(charge), str(clk_ign), str(charge_ign)])

def reduce():
    """ reduce fun """
    dicts = {}
    for line in sys.stdin:
        items = line.strip().split('\t')
        [key, clk, charge, clk_ign, charge_ign] = items
        [usrid, planid, unitid, cmatch] = key.strip().split('_')
        if key not in dicts:
            dicts[key] = [0, 0, 0, 0]
        dicts[key][0] += int(clk)
        dicts[key][1] += float(charge)
        dicts[key][2] += int(clk_ign)
        dicts[key][3] += float(charge_ign)
    
    for key in dicts:
        [clk, charge, clk_ign, charge_ign] = dicts[key]
        print '\t'.join([key, str(clk), str(charge), str(clk_ign), str(charge_ign)])

if __name__ == '__main__':
    exec sys.argv[1] + '()'
