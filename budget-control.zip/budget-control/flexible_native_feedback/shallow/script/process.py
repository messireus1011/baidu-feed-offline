# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2023/02/13
Function：基于学习模型的反馈计算
Input：   不同层级聚合后的ocpx数据
          key：dayhour, dim, dimid, cmatch, trans_type, deep_trans_type
Output：  反馈的计算结果
          key：dim, dimid, cmatch, trans_type, deep_trans_type, feedback_coe
"""

import sys
import numpy as np
import os
import tensorflow as tf

def load_base_file(base_file, cmatch_check, day_check, hour_check):
    """ load base file """

    print("Loading base file...", file=sys.stderr)
    # initialization
    # 当天累积数据
    base_data_arr = {}
    # 分小时累积数据
    accum_data_arr = {}

    for line in base_file.strip().split("\n"):
        items = line.strip().split("\t")
        dayhour, dim, dimid, cmatch, trans_type, deep_trans_type, \
            record, conv, obid, tcharge, charge, coe = items
        record, conv, obid, tcharge, charge, coe = map(float, [record, conv, obid, tcharge, charge, coe])

        daytime = dayhour[:8]
        hour = int(dayhour[8:])
        
        if cmatch not in cmatch_check: continue
        if daytime != day_check: continue
        if hour > hour_check: continue

        key = '\t'.join([dim, dimid, cmatch, trans_type, deep_trans_type])

        if key not in base_data_arr:
            base_data_arr[key] = {}
            base_data_arr[key]["record"] = 0.0
            base_data_arr[key]["conv"] = 0.0
            base_data_arr[key]["obid"] = 0.0
            base_data_arr[key]["tchg"] = 0.0
            base_data_arr[key]["chg"] = 0.0

        base_data_arr[key]["record"] += record
        base_data_arr[key]["conv"] += conv
        base_data_arr[key]["obid"] += obid
        base_data_arr[key]["tchg"] += tcharge
        base_data_arr[key]["chg"] += charge

        if key not in accum_data_arr:
            accum_data_arr[key] = {}
            # 初始化所有的时间
            for T in range(int(hour_check) + 1):
                accum_data_arr[key][T] = {}
                accum_data_arr[key][T]["chg"] = 0.0
                accum_data_arr[key][T]["tchg"] = 0.0
                accum_data_arr[key][T]["coe"] = 1.0
        accum_data_arr[key][hour]["chg"] = charge
        accum_data_arr[key][hour]["tchg"] = tcharge
        if record > 0:
            accum_data_arr[key][hour]["coe"] = coe / record
    
    # 计算小时级累积数据,反馈系数为本小时的系数，非累积
    for key in accum_data_arr:
        for T in range(int(hour_check) + 1):
            if T <= 0: continue
            accum_data_arr[key][T]["chg"] = accum_data_arr[key][T]["chg"] + accum_data_arr[key][T-1]["chg"]
            accum_data_arr[key][T]["tchg"] = accum_data_arr[key][T]["tchg"] + accum_data_arr[key][T-1]["tchg"]
 
    return base_data_arr, accum_data_arr

# 载入剩余流量，user/plan/unitid, cyc_list
def load_cyc(file):
    """ load cyc """
    
    print("Loading cyc res...", file=sys.stderr)
    result = {}
    for line in open(file):
        dimid, cyc_res = line.strip().split("\t")
        cyc_item = cyc_res.split("#")
            
        cyc_list = list(map(float, cyc_item))
        result[dimid] = cyc_list

    return result

# 剩余流量
def get_left_flow_ratio(cyc_rec, dimid, T):
    """ get left flow ratio """
    default_list = [1.0, 1.0, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.8, 0.8, 0.7, 0.7, 0.6, 0.6, 0.5, \
        0.5, 0.5, 0.4, 0.3, 0.3, 0.2, 0.2, 0.1, 0.0]

    T = int(T)
    if dimid in cyc_rec:
        res = cyc_rec[dimid]
        left_ratio = round(res[T], 2)
    else:
        left_ratio = round(default_list[T], 2)

    return left_ratio

# 归一化转化
def get_conv_norm(conv, size):
    """ get_conv_norm """
    conv_norm = round(float(conv) / float(size), 1)
    conv_norm = max(conv_norm, 0.0)
    conv_norm = min(conv_norm, 1.0)

    return conv_norm

# 计算溢出率
def get_excess_ratio(tcpa, charge, tcharge):
    """ get_excess_ratio """
    ratio = 0.0
    tcharge, charge, tcpa = map(float, [tcharge, charge, tcpa])

    if charge >= 5 * tcpa:
        if tcharge <= 0:
            ratio = round(charge / tcpa - 1, 2)
        else:
            ratio = round(charge / tcharge - 1, 2)

    ratio = round(ratio, 2)
    ratio = max(ratio, -0.5)
    ratio = min(ratio, 1.0)
    
    return ratio

# 期望转化
def get_consume_fea(accum_data_arr, key, T, tcpa, size):
    """ get_consume_fea """

    result = 0.0
    # 归一化
    if T < 1:
        result = round(float(accum_data_arr[key][T]["chg"]) / tcpa / size, 2)
    else:
        charge_curr_hour = float(accum_data_arr[key][T]["chg"]) - float(accum_data_arr[key][T-1]["chg"])
        result = round(charge_curr_hour * 1.0 / tcpa / size, 2)
    
    result = min(result, 1.0)
    result = max(result, 0)

    return result

def get_curr_hour(T):
    """ get_curr_hour """
    ratio = round(float(T) / 23, 2)

    return ratio


def get_curr_state_x(predict_data_arr, accum_data_arr, state_size, cyc_rec, T):
    """ get curr state """

    print("get curr state x...", file=sys.stderr)
    state_size_real = state_size
    state = np.empty(shape=(0, state_size_real))
    count = 0
    for key in predict_data_arr:
        dim, dimid, cmatch, trans_type, deep_trans_type = key.strip().split('\t')

        record = predict_data_arr[key]["record"]
        conv = predict_data_arr[key]["conv"]
        obid = predict_data_arr[key]["obid"]
        charge = predict_data_arr[key]["chg"]
        tcharge = predict_data_arr[key]["tchg"]

        # fea1: 当前转化
        fea1_cv = get_conv_norm(conv, 20)

        tcpa = obid / record
        if conv >= 1 and tcharge > 0:
            tcpa = tcharge / conv

        # fea2: 整体溢出率
        fea2_fb = get_excess_ratio(tcpa, charge, tcharge)

        # fea3: 剩余流量
        fea3_left_flow = get_left_flow_ratio(cyc_rec, dimid, T)

        # fea4: 当前小时
        fea4_curr_hour = get_curr_hour(T)
        
        ### 下面为分小时特征，时间窗口为6
        # fea5: action_list
        # if no consume, default 1.0
        fea5_action_1 = 1.0 if T - 1 < 0 else accum_data_arr[key][T - 1].get("coe", 1.0)
        fea5_action_2 = 1.0 if T - 2 < 0 else accum_data_arr[key][T - 2].get("coe", 1.0)
        fea5_action_3 = 1.0 if T - 3 < 0 else accum_data_arr[key][T - 3].get("coe", 1.0)
        fea5_action_4 = 1.0 if T - 4 < 0 else accum_data_arr[key][T - 4].get("coe", 1.0)
        fea5_action_5 = 1.0 if T - 5 < 0 else accum_data_arr[key][T - 5].get("coe", 1.0)
        fea5_action_6 = 1.0 if T - 6 < 0 else accum_data_arr[key][T - 6].get("coe", 1.0)

        # fea6: 分小时累积溢出率，结合 fea5，目的是为了看分小时调解后的溢出率变化情况
        fea6_fb_1 = 0.0 if  T - 1 < 0 \
            else get_excess_ratio(tcpa, accum_data_arr[key][T - 1]["chg"], accum_data_arr[key][T - 1]["tchg"])
        fea6_fb_2 = 0.0 if  T - 2 < 0 \
            else get_excess_ratio(tcpa, accum_data_arr[key][T - 2]["chg"], accum_data_arr[key][T - 2]["tchg"])
        fea6_fb_3 = 0.0 if  T - 3 < 0 \
            else get_excess_ratio(tcpa, accum_data_arr[key][T - 3]["chg"], accum_data_arr[key][T - 3]["tchg"])
        fea6_fb_4 = 0.0 if  T - 4 < 0 \
            else get_excess_ratio(tcpa, accum_data_arr[key][T - 4]["chg"], accum_data_arr[key][T - 4]["tchg"])
        fea6_fb_5 = 0.0 if  T - 5 < 0 \
            else get_excess_ratio(tcpa, accum_data_arr[key][T - 5]["chg"], accum_data_arr[key][T - 5]["tchg"])
        fea6_fb_6 = 0.0 if  T - 6 < 0 \
            else get_excess_ratio(tcpa, accum_data_arr[key][T - 6]["chg"], accum_data_arr[key][T - 6]["tchg"])

        # fea7: 分小时消费速度
        fea7_consume_1 = 0.0 if T - 1 < 0 else get_consume_fea(accum_data_arr, key, T - 1, tcpa, 5)
        fea7_consume_2 = 0.0 if T - 2 < 0 else get_consume_fea(accum_data_arr, key, T - 2, tcpa, 5)
        fea7_consume_3 = 0.0 if T - 3 < 0 else get_consume_fea(accum_data_arr, key, T - 3, tcpa, 5)
        fea7_consume_4 = 0.0 if T - 4 < 0 else get_consume_fea(accum_data_arr, key, T - 4, tcpa, 5)
        fea7_consume_5 = 0.0 if T - 5 < 0 else get_consume_fea(accum_data_arr, key, T - 5, tcpa, 5)
        fea7_consume_6 = 0.0 if T - 6 < 0 else get_consume_fea(accum_data_arr, key, T - 6, tcpa, 5)


        state = np.append(state, [[fea1_cv, fea2_fb, fea3_left_flow, fea4_curr_hour, \
            fea5_action_1, fea5_action_2, fea5_action_3, fea5_action_4, fea5_action_5, fea5_action_6, \
            fea6_fb_1, fea6_fb_2, fea6_fb_3, fea6_fb_4, fea6_fb_5, fea6_fb_6, \
            fea7_consume_1, fea7_consume_2, fea7_consume_3, fea7_consume_4, fea7_consume_5, fea7_consume_6]], axis=0)
        
        ### debug
        #if dimid == "41927798" and cmatch == "545":
        #    print(key, fea1_cv, fea2_fb, fea3_left_flow, fea4_curr_hour, \
        #        fea5_action_1, fea5_action_2, fea5_action_3, fea5_action_4, fea5_action_5, fea5_action_6, \
        #        fea6_fb_1, fea6_fb_2, fea6_fb_3, fea6_fb_4, fea6_fb_5, fea6_fb_6, \
        #        fea7_consume_1, fea7_consume_2, fea7_consume_3, fea7_consume_4, fea7_consume_5, fea7_consume_6, file=sys.stderr)

        count += 1
    print(count, file=sys.stderr)
    print("get curr state x success...", file=sys.stderr)
    
    state = state.astype('float32')
    
    print ("state value", file=sys.stderr)
    print (state, file=sys.stderr)
    return state

def get_dimid_list(base_data_arr, check_num):
    """ get_unit_list """
    dimid_list = []
    predict_data_arr = {}
    for key in base_data_arr:
        value = base_data_arr[key]
        record = base_data_arr[key]["record"]
        conv = base_data_arr[key]["conv"]
        obid = base_data_arr[key]["obid"]
        charge = base_data_arr[key]["chg"]
        tcharge = base_data_arr[key]["tchg"]

        # 门槛
        if record < 1:
            continue
        tcpa = obid / record
        if conv >= 1 and tcharge > 0:
            tcpa = tcharge / conv
        if tcpa > 0 and charge > (check_num * tcpa):
            dimid_list.append(key)
            predict_data_arr[key] = value

    return dimid_list, predict_data_arr


if __name__ == '__main__':
    base_file = sys.stdin.read()
    cyc_file = sys.argv[1]
    day_check = sys.argv[2]
    hour_check = int(sys.argv[3])
    cmatch_check = ["545", "669", "719"]
    # 分小时聚合的基础数据
    base_data_arr, accum_data_arr = load_base_file(base_file, cmatch_check, day_check, hour_check)
    # 剩余流量情况（根据投放情况产出）
    cyc_rec = load_cyc(cyc_file)

    ### debug
    #for key in accum_data_arr:
    #    dim, dimid, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
    #    if dimid == "41927798" and cmatch == "545":
    #        print(key, accum_data_arr[key], file=sys.stderr)

    # 参数设置
    state_size = 22
    check_num = 5
    # 门槛过滤
    dimid_list, predict_data_arr = get_dimid_list(base_data_arr, check_num)
    print(len(dimid_list), file=sys.stderr)
    # 特征获取
    state = get_curr_state_x(predict_data_arr, accum_data_arr, state_size, cyc_rec, hour_check)

    # 模型加载
    # print >> sys.stderr, "Loading model..."
    print("Loading model...", file=sys.stderr)
    meta_path = "/home/disk2/chenjunhao02/flexible_native_feedback/learning_model/my-model.meta"
    model_path= "/home/disk2/chenjunhao02/flexible_native_feedback/learning_model/"

    graph = tf.Graph()
    saver = tf.train.import_meta_graph(meta_path, graph=graph)
    sess = tf.Session(graph = graph)
    ckpt = tf.train.latest_checkpoint(model_path)
    saver.restore(sess, ckpt)

    s = graph.get_operation_by_name('s').outputs[0]
    
    # print >> sys.stderr, "Starting predict..."
    print("Starting predict...", file=sys.stderr)
    # 预测
    for index in range(len(dimid_list)):
        key = dimid_list[index]
        dim, agg_dim, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        feed_dict = {s:[state[index]]}
        a1 = graph.get_tensor_by_name("Actor/eval/a/Tanh:0")
        a2 = graph.get_tensor_by_name("Actor/eval/add:0")
        [[p1]], [[p2]] = sess.run([a1, a2], feed_dict=feed_dict)
        action_value = p2

        # 输出结果
        coe_tmp = max(min(action_value, 2), 0.5)
        feedback_coe = round(coe_tmp, 4)
        line = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
        print(line)
