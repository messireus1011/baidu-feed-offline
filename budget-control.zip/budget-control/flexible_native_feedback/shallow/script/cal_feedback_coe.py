# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/07/06
Function：反馈计算
Input：   合并后的ocpx数据
          key：datehour, unitid, planid, userid, cmatch, is_ocpc_deep, trans_type, deep_trans_type
Output：  修正后的ocpx数据
          key：unitid, cmatch, coe
"""

import configparser
from datetime import datetime, timedelta
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path
from scipy.stats import binom

def load_shallow_dict(shallow_data):
    """
    功能：载入浅层单元数据，为刹车策略服务
    参数：浅层单元数据
    """

    print("Loading shallow brake dict...", file=sys.stderr)

    with open(shallow_data, 'r') as f:
        for line in f:
            items = line.strip().split('\t')
            date_hour, unit, plan, user, cmatch, pricing_type, bid_source, is_ocpc_deep, trans_type, deep_trans_type, \
                    eshow, clk, conv, obid, tcharge, charge, coe, entity = items
            eshow, clk, conv, obid, tcharge, charge, coe = map(float, [eshow, clk, conv, obid, tcharge, charge, coe])

            key = '\t'.join([unit_dim, unit, cmatch, trans_type, deep_trans_type])

            # 记录今天的数据
            today = datetime.now().strftime('%Y%m%d')
            date = date_hour[0:8]
            if date != today:
                continue
            if key not in shallow_dict:
                shallow_dict[key] = [0.0] * 5

            record = eshow + clk
            shallow_dict[key][0] += record
            shallow_dict[key][1] += conv
            shallow_dict[key][2] += obid
            shallow_dict[key][3] += tcharge
            shallow_dict[key][4] += charge

def load_week_dict(week_data):
    """
    功能：载入历史7天数据，为转化稀疏账户做兜底
    参数：浅层单元数据
    """

    print("Loading week data dict...", file=sys.stderr)

    today = datetime.now().strftime('%Y%m%d')
    cur_hour = datetime.now().strftime('%Y%m%d%H')
    one_hour_ago = (datetime.now() + timedelta(hours=-1)).strftime('%Y%m%d%H')
    print(today, one_hour_ago, file=sys.stderr) 

    with open(week_data, 'r') as f:
        for line in f:
            items = line.strip().split('\t')
            date, hour, unit, plan, user, cmatch, pricing_type, bid_source, is_ocpc_deep, trans_type, deep_trans_type, \
                    eshow, clk, conv, obid, tcharge, charge, bat = items
            eshow, clk, conv, obid, tcharge, charge, bat = map(float, [eshow, clk, conv, obid, tcharge, charge, bat])
            if cmatch in bak_cmatch and pricing_type == '0':
                charge = bat
            key = '\t'.join([user_dim, user, cmatch, trans_type, deep_trans_type])

            date_hour = date + hour.zfill(2)
            if date_hour == one_hour_ago or date_hour == cur_hour:
                continue
            if key not in week_dict:
                week_dict[key] = [0.0] * 5

            record = eshow + clk
            week_dict[key][0] += record
            week_dict[key][1] += conv
            week_dict[key][2] += obid
            week_dict[key][3] += tcharge
            week_dict[key][4] += charge

def load_unit_dict(data):
    """
    功能：将分小时的反馈数据聚合成单元维度
    参数：反馈分小时数据
    """

    print("Loading data dict...", file=sys.stderr)

    for line in data.strip().split("\n"):
        items = line.strip().split('\t')
        date_hour, dim, agg_dim, cmatch, trans_type, deep_trans_type, \
                record, conv, obid, tcharge, charge, coe = items

        record, conv, obid, tcharge, charge, coe = map(float, [record, conv, obid, tcharge, charge, coe])
        key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        
        # 分不同时间窗口，浅层默认使用当天窗口
        today = datetime.now().strftime('%Y%m%d')
        date = date_hour[0:8]
        one_hour_ago = (datetime.now() + timedelta(hours=-1)).strftime('%Y%m%d%H')
        #if date != today or date_hour == one_hour_ago:
        if date != today:
            continue
        if key not in data_dict:
            data_dict[key] = [0.0] * 5

        data_dict[key][0] += record
        data_dict[key][1] += conv
        data_dict[key][2] += obid
        data_dict[key][3] += tcharge
        data_dict[key][4] += charge

def brake_strategy(param_dict):
    """
    功能：刹车策略
    """

    print ("Braking...", file=sys.stderr)

    for key in param_dict:
        dim, agg_dim, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        record, conv, obid, tcharge, charge = param_dict[key]
        
        if dim != unit_dim:
            continue
 
        feedback_coe_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if feedback_coe_key in feedback_coe_dict:
            continue

        error, coe, tcpa = 0, 0, 0

        if charge <= 0.0:
            continue
        if record <= 0.0:
            continue
        
        tcpa = obid / record
        if conv >= 1 and tcharge > 0:
            tcpa = tcharge / conv 

        # 刹车门槛：仅生效 charge >= 5*obid 的
        if charge < 5 * tcpa:
            continue
        if conv >= 5:
            continue

        brake_coe = 0.7

        # 空跑单元的刹车策略
        # 转化为0的
        if (conv - 0.0) < eps:
            if charge >= 1.8 * tcpa:
                coe = brake_coe
                bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
                if bank_key not in bank_account_dict:
                    bank_account_dict[bank_key] = [HARD_BRAKE, record, conv, tcpa, charge, tcharge, error, coe]
            
            if coe == 0:
                continue
            feedback_coe = round(coe, 4)
            # 写入反馈词典
            feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
            if feedback_coe_key not in feedback_coe_dict:
                feedback_coe_dict[feedback_coe_key] = feedback_coe_value
                print(feedback_coe_value)

        # cv > 0
        else:
            error = tcharge / charge
            if error <= 0.6:
                coe = brake_coe
                bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
                if bank_key not in bank_account_dict:
                    bank_account_dict[bank_key] = [SOFT_BRAKE, record, conv, tcpa, charge, tcharge, error, coe]

            # 异常，没赋值
            if error == 0 or coe == 0:
                continue

            feedback_coe = round(coe, 4)
            # 写入反馈词典
            feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
            if feedback_coe_key not in feedback_coe_dict:
                feedback_coe_dict[feedback_coe_key] = feedback_coe_value
                print(feedback_coe_value)


    print ("Braked...", file=sys.stderr)


def fiducial_feedback_coe(param_dict):
    """
    功能：置信反馈计算
    """

    print ("Calculating fiducial feedback coe...", file=sys.stderr)

    for key in param_dict:
        dim, agg_dim, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        record, conv, obid, tcharge, charge = param_dict[key]

        feedback_coe_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if feedback_coe_key in feedback_coe_dict:
            continue

        error, coe, tcpa = 0, 0, 0
 
        # 排除异常
        if charge <= 0.0 or conv <= 0.0 or record <= 0.0:
            continue

        tcpa = obid / record
        if conv >= 1 and tcharge > 0:
            tcpa = tcharge / conv

        # 只用今天窗口算的，得保证转化和点击都到门槛
        if record < fiducial:
            continue
        if conv < 5 and charge < 5 * tcpa:
            continue
        
        error = charge / tcharge
        # 正溢出打压
        if error >= 1.0:
            coe = 1.0 - kp_down * (error-1.0)
        # 负溢出扶持
        else:
            coe = 1.0 + kp_up * (1.0-error)

        bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if bank_key not in bank_account_dict:
            bank_account_dict[bank_key] = [FIDUCIAL, record, conv, tcpa, charge, tcharge, error, coe]

        # 异常，没赋值
        if error == 0 or coe == 0 or tcpa == 0:
            continue

        # 误差在一定范围内，不调整
        if error >= 0.9 and error <= 1.1:
            coe = 1.0
        
        if trans_type == "42":
            coe_tmp = max(min(coe, 1.3), 0.5)
        else:
            if charge >= 20 * tcpa or conv >= 20:
                coe_tmp = max(min(coe, 1.3), 0.7)
            elif 10 * tcpa <= charge < 20 * tcpa or 10 <= conv < 20:
                coe_tmp = max(min(coe, 1.2), 0.8)
            else:
                coe_tmp = max(min(coe, 1.1), 0.9)
        feedback_coe = round(coe_tmp, 4)

        # 写入反馈词典
        feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
        if feedback_coe_key not in feedback_coe_dict:
            feedback_coe_dict[feedback_coe_key] = feedback_coe_value
            print(feedback_coe_value)
        

    print ("Calculated fiducial feedback coe...", file=sys.stderr)

def unfiducial_feedback_coe(param_dict):
    """
    功能：不置信反馈计算
    """

    print ("Calculating unfiducial feedback coe...", file=sys.stderr)
    for key in param_dict:
        dim, agg_dim, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        record, conv, obid, tcharge, charge = param_dict[key]

        feedback_coe_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        
        # 1,2,3为90% 4,5,8为70%
        min_pro = min_pro_global
        #if unit[-1] in ['1','2','3']:
        #    min_pro = 0.9

        if feedback_coe_key in feedback_coe_dict:
            continue

        if charge <= 0.0:
            continue

        error, coe = 1.0, 1.0

        tcpa = obid / record
        if conv >= 1 and tcharge > 0:
            tcpa = tcharge / conv

        if record < fiducial:
            continue
            
        # track逻辑,不置信的情况下其实没法判断正负溢出
        if charge > 1.1 * tcharge:            
            # 正溢出，取概率大于0.7的最大溢出率
            for level in right_levels:
                level = float(level)
                ecvr = charge / (level * tcpa * record)
                p  = 1 - binom.cdf(conv, record, ecvr)
                if p >= min_pro:
                    error = max(error, level)
            
            if error > 1.0:
                coe = 1.0 - kp_down * (error-1.0)

            bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
            if coe < 1.0 and bank_key not in bank_account_dict:
                bank_account_dict[bank_key] = [UNFIDUCIAL, record, conv, tcpa, charge, tcharge, error, coe]
            
        elif charge < 0.9 * tcharge:
            # 负溢出，取概率大于0.7的最小溢出率
            for level in left_levels:
                level = float(level)
                ecvr = charge / (level * tcpa * record)
                p  = binom.cdf(conv, record, ecvr)
                if p >= min_pro:
                    error = min(error, level)

            if error < 1.0:
                coe = 1.0 + kp_up * (1.0-error)

            bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
            if coe > 1.0 and bank_key not in bank_account_dict:
                bank_account_dict[bank_key] = [UNFIDUCIAL, record, conv, tcpa, charge, tcharge, error, coe]
        
        if error == 1.0 or coe == 1.0:
            continue

        coe_tmp = max(min(coe, 1.1), 0.9)
        feedback_coe = round(coe_tmp, 4)

        # 写入反馈词典
        feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
        if feedback_coe_key not in feedback_coe_dict:
            feedback_coe_dict[feedback_coe_key] = feedback_coe_value
            print(feedback_coe_value)

    print ("Calculated unfiducial feedback coe...", file=sys.stderr)

def output_data_dict(dict_data, file_name):
    """
    功能：输出词典
    参数：词典存储路径
    """

    with open(file_name, 'w') as f:
        for key, value in dict_data.items():
            value = '\t'.join(map(str, value))
            f.write(key + '\t' + value + '\n')
    print("save data into dict", file=sys.stderr)

# 读取配置文件
config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)
entity_dim = config["DIM"].get("ENTITY_DIM")
user_dim = config["DIM"].get("USER_DIM")
plan_dim = config["DIM"].get("PLAN_DIM")
unit_dim = config["DIM"].get("UNIT_DIM")
fiducial = int(config["FEEDBACK"].get("FIDUCIAL_THRESHOLD"))
max_coe = float(config["FEEDBACK"].get("MAX_COE"))
min_coe = float(config["FEEDBACK"].get("MIN_COE"))
kp_down = float(config["FEEDBACK"].get("PID_KP_DOWN"))
kp_up = float(config["FEEDBACK"].get("PID_KP_UP"))
right_levels = config["FEEDBACK"].get("RIGHT_LEVELS").split(',')
left_levels = config["FEEDBACK"].get("LEFT_LEVELS").split(',')
min_pro_global = float(config["FEEDBACK"].get("MIN_PRO"))
bak_cmatch = config["BANK_ACCOUNT"].get("BAK_CMATCH").split(',')
base_data = sys.stdin.read()
shallow_data = sys.argv[1]
week_data = sys.argv[2]
data_for_bak = sys.argv[3]
eps=1e-6
# 策略新增
TODAY_WINDOW="TODAY_WINDOW"
SLIP_WINDOW="SLIP_WINDOW"
HARD_BRAKE="HARD_BRAKE"
SOFT_BRAKE="SOFT_BRAKE"
FIDUCIAL="FIDUCIAL"
UNFIDUCIAL="UNFIDUCIAL"

# 全局变量
shallow_dict = {} # 存储单元数据供刹车策略使用
data_dict = {} # 存储当天的反馈数据
week_dict = {} # 存储七天的反馈数据
bank_account_dict = {} # 存储结果提供给bank_account使用
feedback_coe_dict = {} # 反馈词典

if __name__ == '__main__':
    load_shallow_dict(shallow_data)
    load_week_dict(week_data) 
    load_unit_dict(base_data)
    brake_strategy(shallow_dict)
    fiducial_feedback_coe(data_dict)
    # 授信先走周级别，再走不置信，因为真是太不置信了，会出现反馈突变的badcase
    fiducial_feedback_coe(week_dict)
    unfiducial_feedback_coe(data_dict)
    output_data_dict(bank_account_dict, data_for_bak)
