#!/bin/sh

source ~/.bashrc
source ./conf/run.conf

set -x

# 判断上一个反馈计算任务是否结束
run_state=`cat ./state/run_state.txt`
if [ "${run_state}" == "doing" ]; then
    exit 0
else
    echo "last task has done, start this task"
fi

echo "doing" > ./state/run_state.txt

if [ $# -eq 3 ]; then
    cur_day=$1
    cur_hour=$2
    cur_min=$3
elif [ $# -eq 0 ];then
    cur_time=`date "+%Y%m%d %H %M"`
    cur_day=`echo ${cur_time} | awk '{print $1}'`
    cur_hour=`echo ${cur_time} | awk '{print $2}'`
    cur_min=`echo ${cur_time} | awk '{print $3}'`
fi

week_before=`date -d "-7 day $cur_day" +'%Y%m%d'`
yes_day=`date -d "-1 day $cur_day" +'%Y%m%d'`
cur_dayhour=${cur_day}' '${cur_hour}
cur_dayhourmin=${cur_day}${cur_hour}${cur_min}
one_dayhour=`date -d "-1 hour" "+%Y%m%d%H"`
cur_datehour=${cur_day}${cur_hour}

echo "*****************this task start at ${cur_dayhourmin} *********************"
mysql="/home/work/.jumbo/bin/mysql -h 100.66.154.42 -P9030 -u admin -pfeedBd2023 -N -e" #新机器
#mysql="/home/work/.jumbo/bin/mysql -h 10.138.28.235 -P9030 -u admin -pBes_report -N -e"    #主物理机使用保定集群数据库
#mysql="/home/work/.jumbo/bin/mysql -h 100.64.7.211 -P9030 -u admin -pBes_report -N -e"    #备用：使用华南集群数据库

palo_data=${PALO_DIR}/palo_${cur_dayhourmin}
week_data=${WEEK_DIR}/week_${cur_dayhourmin}
ocpx_data=${OCPX_DIR}/ocpx_${cur_dayhourmin}
conv_adjust_data=${CONV_ADJUST_DIR}/conv_adjust_${cur_dayhourmin}
agg_diff_data=${AGG_DIFF_DIR}/agg_diff_${cur_dayhourmin}
user_dim_file=${USER_DIM_DIR}/user_dim_${cur_dayhourmin}
adjust_user=${ADJUST_USER}/adjust_user
#bayes_data=`tail -1 ${BAYES_DIR}/bayes_data`
feedback_dict=${FEEDBACK_DICT}/dict_${cur_dayhourmin}
cyc_res_data=${CYC_RES_FILE}
learning_feedback_dict=${FEEDBACK_DICT}/learning_${cur_dayhourmin}
dt_feedback_dict=${FEEDBACK_DICT}/dt_${cur_dayhourmin}

# 需要数据的时间范围
time_frame=`date -d "-25 hour ${cur_dayhour}" +"%Y%m%d%H"`
# 重试次数
try_num=0

while [[ ${try_num} -lt 3 ]]; do
    $mysql "set query_timeout=120; 
      select 
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source,
        max(is_ocpc_deep) as is_ocpc_deep, max(trans_type) as trans_type, max(deep_trans_type) as deep_trans_type,
        sum(page_views) as sum_eshow, sum(clicks) as sum_clk, sum(conversions) as sum_tnum, sum(ocpc_bid) as sum_obid, sum(conv_ocpc_bid) as sum_conv_obid, 
        sum(pay) + sum(cpmpay) / 1000.0 as charge, sum(if(pricing_type=0,price_before_bank_accont,price_before_bank_accont/1000)) as sum_bat, sum(reach_adjust_coe) as coe 
      from shoubai_online_data.shoubai_pay_cvt_v3
      where 
        date in (${cur_day}, ${yes_day})
        and cmatch in (545,669,719,1220,1214,1227,1501,1502,778,547,489,1761,829,646,588,534,1447,720,1429,1173,1738,1639)
        and ${time_frame} <= concat(date, lpad(cast(hour as char),2,0)) 
        and ocpclevel=2 and bidtype=3
        and trans_type!=45
      group by 
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source;
    " > ${palo_data}_tmp

    if [ $? -ne 0 ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "gen palo data failed at ${cur_dayhourmin}"
                rm -r ${palo_data}_tmp
                echo "Failed to get palo data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
                echo "done" > ./state/run_state.txt
                exit -1
        fi
    else
            echo "gen palo data success at ${cur_dayhourmin}"
            mv ${palo_data}_tmp ${palo_data}
            break
    fi
    try_num=`expr ${try_num} + 1`
done

while [[ ${try_num} -lt 3 ]]; do
    $mysql "set query_timeout=120;
      select
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source,
        max(is_ocpc_deep) as is_ocpc_deep, max(trans_type) as trans_type, max(deep_trans_type) as deep_trans_type,
        sum(page_views) as sum_eshow, sum(clicks) as sum_clk, sum(conversions) as sum_tnum, sum(ocpc_bid) as sum_obid, sum(conv_ocpc_bid) as sum_conv_obid,
        sum(pay) + sum(cpmpay) / 1000.0 as charge, sum(if(pricing_type=0,price_before_bank_accont,price_before_bank_accont/1000)) as sum_bat
      from shoubai_online_data.shoubai_pay_cvt_v3
      where
        date between $week_before and $cur_day
        and cmatch in (545,669,719)
        and ocpclevel = 2 and bidtype = 3 and is_ocpc_deep = 0
        and trans_type in (42)
      group by
        date, hour, unitid, planid, userid, cmatch, pricing_type, bid_source;
    " > ${week_data}_tmp

    if [ $? -ne 0 ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "gen week data failed at ${cur_dayhourmin}"
                rm -r ${week_data}_tmp
                echo "Failed to get week data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
                echo "done" > ./state/run_state.txt
                exit -1
        fi
    else
            echo "gen week data success at ${cur_dayhourmin}"
            mv ${week_data}_tmp ${week_data}
            break
    fi
    try_num=`expr ${try_num} + 1`
done

while [[ ${try_num} -lt 3 ]]; do
    $mysql "set query_timeout=120;
      select userid, cmatch, trans_type, deep_trans_type from
      (select
        userid, cmatch, trans_type, deep_trans_type, sum(page_views) + sum(clicks) as record
      from shoubai_online_data.shoubai_pay_cvt_v3
      where
        date in (${cur_day}, ${yes_day})
        and cmatch in (545,669,719)
        and trans_type in (42,49)
      group by
        userid, cmatch, trans_type, deep_trans_type) t1;
    " > ${adjust_user}_tmp

    if [ $? -ne 0 ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "gen adjust user failed at ${cur_dayhourmin}"
                rm -r ${adjust_user}_tmp
                echo "Failed to get adjust user at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
                echo "done" > ./state/run_state.txt
                exit -1
        fi
    else
            echo "gen adjust user success at ${cur_dayhourmin}"
            mv ${adjust_user}_tmp ${adjust_user}
            break
    fi
    try_num=`expr ${try_num} + 1`
done

## 合并ocpc和ocpm
#echo "start merging ocpx data at `date`"
#cat ${palo_data} | python3 script/merge_ocpx_data.py > ${ocpx_data}
#if [[ $? -ne 0 ]];then
#    echo "Failed to merge ocpx data"
#    echo "Failed to merge ocpx data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
#    echo "done" > ./state/run_state.txt
#    exit -1
#fi


# 转化延迟修正
cat ${palo_data} | python3 script/conv_delay_revise.py ${cur_day} ${cur_hour} ${CONV_DELAY_RATIO_DATA} > ${conv_adjust_data}_tmp
if [[ $? -ne 0 ]];then
    echo "Failed to revise conv data"
    echo "Failed to revise conv data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi


# 更新账户-实体映射
# 先确保没有并行在修改，否则等待2m
try_num=0
while [[ ${try_num} -lt 3 ]]; do
    vrelation_state=`cat ${VRELATION_DIR}/vrelation_state.txt`
    if [ "${vrelation_state}" == "doing" ]; then
        if [[ ${try_num} -eq 2 ]]; then
            echo "Failed to get vrelation data at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
            echo "done" >> ./state/run_state.txt
            exit -1
        fi
        sleep 2m
    else
        echo "get vrelation"
        break
    fi
    try_num=`expr ${try_num} + 1`
done

# 加入公司,没公司的则entityid=0
awk 'BEGIN{FS=OFS="\t"}ARGIND==1{company_name[$2]=$3}ARGIND==2{user_company=company_name[$4]; if(user_company){print $0,user_company}else{print $0,0}}' ${VRELATION_FILE} ${conv_adjust_data}_tmp > ${conv_adjust_data}
rm -rf ${conv_adjust_data}_tmp

# 分层级聚合数据
wget -O ${user_dim_file} http://zongkong.baidu.com/home/work/zongkong/userdata/93/feedback_user_dim_file/feedback_user_dim_file_zk.txt &&
cat ${conv_adjust_data} | python3 script/agg_diff_dim.py ${user_dim_file} > ${agg_diff_data}
if [[ $? -ne 0 ]];then
    echo "Failed to cal feedback coe at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

data_for_bak=${DATA_FOR_BAK_DIR}/data_for_bak_${cur_dayhourmin}
if [ ! -f ${data_for_bak} ]; then
    touch ${data_for_bak}
fi

# PID反馈计算
cat ${agg_diff_data} | python3 script/cal_feedback_coe.py ${conv_adjust_data} ${week_data} ${data_for_bak} > ${feedback_dict}
if [[ $? -ne 0 ]];then
    echo "Failed to cal feedback coe at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

echo ${feedback_dict} >> ${SHALLOW_FEEDBACK_DICT}
echo ${data_for_bak} >> ${SHALLOW_BANK_ACCOUNT_DICT}
echo "ocpx feedback dict success"
echo "done" > ./state/run_state.txt

# 基于学习的反馈
# 确保此时无更新
while [[ ${try_num} -lt 3 ]]; do
    cyc_res_state=`cat ${CYC_RES_DIR}/cyc_res_state.txt`
    if [ "${cyc_res_state}" == "doing" ]; then
        if [[ ${try_num} -eq 2 ]]; then
            #echo "Failed to get cyc res at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
            #echo "done" >> ./state/run_state.txt
            exit -1
        fi
        sleep 2m
    else
        echo "get cyc res"
        break
    fi
    try_num=`expr ${try_num} + 1`
done

cat ${agg_diff_data} | python3 script/process.py ${cyc_res_data} ${cur_day} ${cur_hour} > ${learning_feedback_dict}
if [[ $? -ne 0 ]];then
    echo "Failed to cal learning base feedback coe at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi
echo ${learning_feedback_dict} >> ${LEARNING_FEEDBACK_DICT}

# 取最新记录
shallow_feedback_dict=`tail -1 ${SHALLOW_FEEDBACK_DICT}`
deep_feedback_dict=`tail -1 ${DEEP_FEEDBACK_DICT}`
shallow_bak_dict=`tail -1 ${SHALLOW_BANK_ACCOUNT_DICT}`
deep_bak_dict=`tail -1 ${DEEP_BANK_ACCOUNT_DICT}`
learning_feedback_dict=`tail -1 ${LEARNING_FEEDBACK_DICT}`

$HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -test -e afs:/app/ecom/native-ad-price/chenjunhao02/feedback/dt_ocpx_feedback_dict/dt_ocpx_feedback_dict_${cur_datehour}
if [ $? -ne 1 ];then
    $HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -cat afs:/app/ecom/native-ad-price/chenjunhao02/feedback/dt_ocpx_feedback_dict/dt_ocpx_feedback_dict_${cur_datehour} > ${dt_feedback_dict}
    echo "get dt cur hour success at `date "+%Y%m%d %H %M"`"
else
    $HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -test -e afs:/app/ecom/native-ad-price/chenjunhao02/feedback/dt_ocpx_feedback_dict/dt_ocpx_feedback_dict_${one_dayhour}
    if [ $? -ne 1 ];then
        $HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -cat afs:/app/ecom/native-ad-price/chenjunhao02/feedback/dt_ocpx_feedback_dict/dt_ocpx_feedback_dict_${one_dayhour} > ${dt_feedback_dict}
        echo "get dt one hour ago success at `date "+%Y%m%d %H %M"`"
    else
        touch ${dt_feedback_dict}
        python script/sendAlarmMsg.py -h -r 'chenjunhao02' -c "!!!!! get dt failed !!!!!"
        echo "get dt failed at `date "+%Y%m%d %H %M"`"
    fi
fi

if [ "${cur_hour}" == "00" ]; then
    > ${dt_feedback_dict}
fi

# 合并反馈词典
mkdir ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}
cat ${shallow_feedback_dict} | python3 script/new_merge_dict.py ${deep_feedback_dict} ${learning_feedback_dict} ${dt_feedback_dict} > ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/ocpx_feedback_dict.txt
if [[ $? -ne 0 ]];then
    echo "Failed to merge feedback dict"
    echo "Failed to merge feedback dict at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

# 行业系数调整
#cat ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/ocpx_feedback_dict.txt | python3 script/adjust_coe.py ${adjust_user} > ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/adjust_ocpx_feedback_dict.txt
# 49-26协同总控下掉灰度系数
# wget -O /home/disk2/chenjunhao02/flexible_native_feedback/shallow/middle_data/paying_user_ecosystem_zk.txt http://zongkong.baidu.com/home/work/zongkong/userdata/65/paying_user_ecosystem/paying_user_ecosystem_zk.txt &&
cat ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/ocpx_feedback_dict.txt | python3 script/adjust_coe.py ${adjust_user} > ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/adjust_ocpx_feedback_dict.txt
if [[ $? -ne 0 ]];then
    echo "Failed to get final feedback dict"
    echo "Failed to get final feedback dict at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

# badcase直接生效
cat ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/adjust_ocpx_feedback_dict.txt | python3 script/merge_badcase_dict.py ${BADCASE_DIR}/dict > ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/final_ocpx_feedback_dict.txt
if [[ $? -ne 0 ]];then
    echo "Failed to get final feedback dict"
    echo "Failed to get final feedback dict at `date "+%Y%m%d %H %M"`" >> ./state/fail_state.txt
    echo "done" > ./state/run_state.txt
    exit -1
fi

# empty_tag=1 时，反馈不生效
empty_tag=0
if [[ $empty_tag -eq 0 ]]; then
    # 存放结果
    cp ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/final_ocpx_feedback_dict.txt ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt
    md5sum ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt > ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt.md5
else
    cat ${OCPX_FEEDBACK_DICT}/${cur_dayhourmin}/final_ocpx_feedback_dict.txt | awk '{FS=OFS="\t"}{print $1, $2, $3, $4, $5, 1.0}' > ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt
    md5sum ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt > ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt.md5
fi

# 登录门神
#cp ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt /home/work/chenjunhao02/dict_online/flexible_ocpx_feedback_dict/
#cp ${ONLINE_DICT}/flexible_ocpx_feedback_dict.txt.md5 /home/work/chenjunhao02/dict_online/flexible_ocpx_feedback_dict/

cat ${shallow_bak_dict} > ${BANK_ACCOUNT_DICT}/bank_account_dict_${cur_dayhourmin}
cat ${deep_bak_dict} >> ${BANK_ACCOUNT_DICT}/bank_account_dict_${cur_dayhourmin}
rm -rf ${shallow_bak_dict}
#rm -rf ${deep_bak_dict}
echo "done" > ./state/run_state.txt
echo "=======================SUCCESS====================="

### 实验
# 上传文件给杨业
$HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -rm afs:/app/ecom/native-ad-price/chenjunhao02/feedback/agg_diff_data/_SUCCESS
$HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -put ${agg_diff_data} afs:/app/ecom/native-ad-price/chenjunhao02/feedback/agg_diff_data/
$HADOOP_CLIENT fs -Dfs.default.name=$HADOOP_DEFAULT_NAME -Dhadoop.job.ugi=$HADOOP_UGI -put _SUCCESS afs:/app/ecom/native-ad-price/chenjunhao02/feedback/agg_diff_data

echo "=======================PUT_SUCCESS====================="
