# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/05/06
Function：行业系数调整
Input：   palo数据和反馈数据
Output:   最终的反馈词典
"""

import configparser
import datetime
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path

def merge_dict(feedback_data):
    """
    功能：合并词典
    """

    skip_user = {}
    for line in open("/home/disk2/chenjunhao02/flexible_native_feedback/shallow/middle_data/paying_user_ecosystem_zk.txt", 'r'):
        user = line.strip()
        skip_user[user] = 1

    data_dict = {}
    for line in open(adjust_user, 'r'):
        items = line.strip().split('\t')
        user, cmatch, trans_type, deep_trans_type = items

        if user in skip_user:
            continue

        coe = 1.0
        if trans_type == "42":
            if cmatch == "545":
                coe = 0.7
            elif cmatch == "719":
                coe = 0.7
        #elif trans_type == "49" and deep_trans_type == "26":
        #    if cmatch == "545":
        #        coe = 0.8
            #elif cmatch == "719":
            #    coe = 0.88
        # 没有调整跳过
        if coe == 1.0:
            continue
        key = '\t'.join([user_dim, user, cmatch, trans_type, deep_trans_type])
        data_dict[key] = coe
    print("load shallow feedback", file=sys.stderr)
    
    # badcase覆盖基线系数
    for line in feedback_data.strip().split("\n"):
        items = line.strip().split('\t')
        dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe = items
        feedback_coe = float(feedback_coe)
        key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        # 如果是49，需要所有都压
        if key in data_dict and trans_type == "49":
            adjust_coe = data_dict[key]
            coe = adjust_coe * feedback_coe
            coe = max(round(coe, 4), 0.5)
            data_dict[key] = coe
        # 如果是42，有反馈的还是用反馈
        else:
            data_dict[key] = feedback_coe

    print("load bad case", file=sys.stderr)
    return data_dict

def output_data_dict():
    """
    功能：输出词典
    参数：词典存储路径
    """
    # output_path = open(save_data_path, 'w')
    #work_user = {}
    #for line in open("/home/disk2/chenjunhao02/flexible_native_feedback/shallow/middle_data/hangye_uid", 'r'):
    #    items = line.strip().split('\t')
    #    user, unit = items
    #    work_user[user] = 1
    #    work_user[unit] = 1

    for key in data_dict:
        dim, agg_dim, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        
        ## 只生效圈定范围的uid
        #if agg_dim not in work_user:
        #    continue

        coe = data_dict[key]
        if trans_type == "42" and cmatch in ["545","719"]:
            coe *= 0.9
            coe = round(coe, 4)
        print("\t".join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, coe])))
    print("save final dict after merge", file=sys.stderr)

# 读取配置文件
config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)
user_dim = config["DIM"].get("USER_DIM")
# 将数据读入内存，方便进行多次读取
feedback_data = sys.stdin.read()
adjust_user = sys.argv[1]

if __name__ == '__main__':
    data_dict = merge_dict(feedback_data)
    output_data_dict()
