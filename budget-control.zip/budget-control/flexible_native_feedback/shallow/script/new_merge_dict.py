# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/05/06
Function：合并浅层反馈词典、深层反馈词典和飞线词典
Input：   浅层词典、深层词典和飞线词典
Output:   最终的反馈词典
"""

import configparser
import datetime
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path

def merge_dict(shallow_feedback):
    """
    功能：合并词典
    """
    data_dict = {}

    # 生效新反馈
    # 按照浅层，深层，基于学习的反馈逻辑生效
    for line in shallow_feedback.strip().split("\n"):
        items = line.strip().split('\t')
        dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe = items
        key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        data_dict[key] = feedback_coe
    print("load shallow feedback", file=sys.stderr)

    for line in open(deep_feedback, 'r'):
        items = line.strip().split('\t')
        dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe = items
        key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        data_dict[key] = feedback_coe
    print("load deep feedback", file=sys.stderr)
    
    for line in open(learning_feedback, 'r'):
        items = line.strip().split('\t')
        dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe = items
        key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        data_dict[key] = feedback_coe
    print("load learning feedback", file=sys.stderr)

    for line in open(dt_feedback, 'r'):
        items = line.strip().split('\t')
        dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe = items
        key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        data_dict[key] = feedback_coe
    print("load dt feedback", file=sys.stderr)

    return data_dict


def output_data_dict():
    """
    功能：输出词典
    参数：词典存储路径
    """
    for key, value in data_dict.items():
        # 异常兜底
        if float(value) > 3.0 or float(value) < 0.5:
            print("feedback coe error",  key, value, file=sys.stderr)
        else:
            print(key + '\t' + value)
    print("save final dict after merge", file=sys.stderr)

# 读取配置文件
config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)

# 将数据读入内存，方便进行多次读取
shallow_feedback = sys.stdin.read()
deep_feedback = sys.argv[1]
learning_feedback = sys.argv[2]
dt_feedback = sys.argv[3]
if __name__ == '__main__':
    data_dict = merge_dict(shallow_feedback)
    output_data_dict()
