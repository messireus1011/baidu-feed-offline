# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/05/18
Function：为指定单元指定cmatch生成反馈系数
Input：   badcase单元
Output:   badcase单元的反馈词典
"""

import configparser
import datetime
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path


# 将数据读入内存，方便进行多次读取
badcase_user_file = sys.stdin.read()
user_to_unit = sys.argv[1]

config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)
user_dim = config["DIM"].get("USER_DIM")
plan_dim = config["DIM"].get("PLAN_DIM")
unit_dim = config["DIM"].get("UNIT_DIM")

data_dict = {}

for line in open(user_to_unit, 'r'):
    user, unit, trans_type, deep_trans_type = line.strip().split('\t')
    data_dict[user] = [trans_type, deep_trans_type]
    data_dict[unit] = [trans_type, deep_trans_type]

for line in badcase_user_file.strip().split("\n"):
    dim, uid, cmatch, coe = line.strip().split("\t")
    if uid not in data_dict:
        continue
    trans_type, deep_trans_type = data_dict[uid][0], data_dict[uid][1]
    coe = str(round(float(coe), 4))
    # 单元直接加入
    if dim == "1":
        print("\t".join([unit_dim, uid, cmatch, trans_type, deep_trans_type, coe]))
    elif dim == "2":
        print("\t".join([user_dim, uid, cmatch, trans_type, deep_trans_type, coe]))
