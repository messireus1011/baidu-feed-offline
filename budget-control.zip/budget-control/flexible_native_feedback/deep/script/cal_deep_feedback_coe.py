# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/04/22
Function：深度反馈计算
Input：   从palo中取出的数
          key：date, hour, unitid, planid, userid, cmatch, pricing_type, deep_trans_type
Output：  修正后的ocpx数据
          key：unitid, cmatch, coe
"""

import configparser
from datetime import datetime, timedelta
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path

def load_shallow_dict(shallow_data):
    """
    功能：生成贝叶斯先验词典
    参数：贝叶斯先验数据
    """

    print("Loading bayes dict...", file=sys.stderr)

    with open(shallow_data, 'r') as f:
        for line in f:
            items = line.strip().split('\t')
            date, hour, unit, plan, user, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type, \
                    eshow, clk, conv, obid, tcharge, charge, bat = items
            eshow, clk, conv, obid, tcharge, charge, bat = map(float, [eshow, clk, conv, obid, tcharge, charge, bat])
            if cmatch in bak_cmatch and pricing_type == '0':
                charge = bat
            key = '\t'.join([unit_dim, unit, cmatch, trans_type, deep_trans_type])

            # 记录今天的数据
            today = datetime.now().strftime('%Y%m%d')
            cur_hour = datetime.now().strftime('%Y%m%d%H')
            one_hour_ago = (datetime.now() + timedelta(hours=-1)).strftime('%Y%m%d%H')
            date_hour = date + hour.zfill(2)
            if date != today or date_hour == one_hour_ago or date_hour == cur_hour:
                continue
            if key not in shallow_dict:
                shallow_dict[key] = [0.0] * 5
            shallow_dict[key][0] += (eshow + clk)
            shallow_dict[key][1] += conv
            shallow_dict[key][2] += obid
            shallow_dict[key][3] += tcharge
            shallow_dict[key][4] += charge


def load_unit_dict(data, date):
    """
    功能：按照不同转化类型，将分小时的反馈数据聚合成单元维度
    """

    print("Loading data dict...", file=sys.stderr)


    # 不同转化类型的时间窗口不一致
    date = datetime.strptime(date, '%Y%m%d%H')
    time_range = {
        '-1': ((date - timedelta(hours=104)).strftime('%Y%m%d%H'), (date - timedelta(hours=8)).strftime('%Y%m%d%H')),
        '10': ((date - timedelta(hours=104)).strftime('%Y%m%d%H'), (date - timedelta(hours=8)).strftime('%Y%m%d%H')),
        '26': ((date - timedelta(hours=120)).strftime('%Y%m%d%H'), (date - timedelta(hours=8)).strftime('%Y%m%d%H')),
        '27': ((date - timedelta(hours=104)).strftime('%Y%m%d%H'), (date - timedelta(hours=8)).strftime('%Y%m%d%H')),
        '28': ((date - timedelta(days=5)).strftime('%Y%m%d00'), (date - timedelta(days=2)).strftime('%Y%m%d23')),
        '45': ((date - timedelta(hours=104)).strftime('%Y%m%d%H'), (date - timedelta(hours=8)).strftime('%Y%m%d%H'))
    }

    print(time_range, file=sys.stderr)

    data_dict = {}
    for line in data.strip().split("\n"):
        items = line.strip().split('\t')
        dayhour, dim, agg_dim, cmatch, trans_type, deep_trans_type, \
                record, deep_conv, deep_obid, deep_tcharge, charge, coe = items
        
        record, deep_conv, deep_obid, deep_tcharge, charge, coe = map(float, [record, deep_conv, deep_obid, deep_tcharge, charge, coe])
        key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])

        if deep_trans_type not in time_range:
            continue

        # 除了26类型，其他用默认时间范围
        if deep_trans_type in time_range:
            begin, end = time_range[deep_trans_type]
        #else:
        #    begin, end = time_range['-1']
        if not begin <= dayhour <= end:
            continue

        if key not in data_dict:
            data_dict[key] = [0.0] * 5
        
        # 全部数据，用于计算转化率
        data_dict[key][0] += record
        data_dict[key][1] += deep_conv
        data_dict[key][2] += deep_obid
        data_dict[key][3] += deep_tcharge
        data_dict[key][4] += charge


    return data_dict

def brake_strategy():
    """
    功能：刹车策略
    """

    print ("Braking...", file=sys.stderr)

    for key in shallow_dict:
        dim, agg_dim, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        record, conv, obid, tcharge, charge = shallow_dict[key]

        # 仅单元维度生效刹车策略
        if dim != unit_dim:
            continue
        feedback_coe_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if feedback_coe_key in feedback_coe_dict:
            continue

        error, coe, flag = 0, 0, 0

        if charge <= 0.0:
            continue
        if record <= 0.0:
            continue

        tcpa = obid / record
        if conv >= 1 and tcharge > 0:
            tcpa = tcharge / conv

        # 刹车门槛：仅生效 charge >= 5*obid 的
        if charge < 5 * tcpa:
            continue
        if conv >= 5:
            continue

        # 空跑单元的刹车策略
        # 转化为0的
        if (conv - 0.0) < eps:
            if charge >= 1.8 * tcpa:
                coe = 0.7
                bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
                if bank_key not in bank_account_dict:
                    bank_account_dict[bank_key] = [HARD_BRAKE, record, conv, tcpa, charge, tcharge, error, coe]

            if coe == 0:
                continue
            feedback_coe = round(coe, 4)
            # 写入反馈词典
            feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
            if feedback_coe_key not in feedback_coe_dict:
                feedback_coe_dict[feedback_coe_key] = feedback_coe_value
                print(feedback_coe_value)

        # cv > 0
        else:
            error = tcharge / charge
            if error <= 0.6:
                coe = 0.7
                bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
                if bank_key not in bank_account_dict:
                    bank_account_dict[bank_key] = [SOFT_BRAKE, record, conv, tcpa, charge, tcharge, error, coe]

            # 异常，没赋值
            if error == 0 or coe == 0:
                continue

            feedback_coe = round(coe, 4)
            # 写入反馈词典
            feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
            if feedback_coe_key not in feedback_coe_dict:
                feedback_coe_dict[feedback_coe_key] = feedback_coe_value
                print(feedback_coe_value)

    print ("Braked...", file=sys.stderr)



def fiducial_feedback_coe():
    """
    功能：置信反馈
    """

    print ("Calculating feedback coe...", file=sys.stderr)

    for key in data_dict:
        dim, agg_dim, cmatch, trans_type, deep_trans_type = key.strip().split('\t')
        record, deep_conv, deep_obid, deep_tcharge, charge = data_dict[key]

        feedback_coe_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if feedback_coe_key in feedback_coe_dict:
            continue

        error, coe, tcpa = 0, 0, 0

        # 排除异常
        if charge <= 0.0 or deep_conv <= 0.0 or record <= 0.0:
            continue

        tcpa = deep_obid / record
        if deep_conv >= 1 and deep_tcharge > 0:
            tcpa = deep_tcharge / deep_conv
        
        # 置信门槛
        if record < fiducial:
            continue
        if deep_conv < 7 and charge < 7 * tcpa:
            continue

        error = charge / deep_tcharge
        # 正溢出打压
        if error >= 1.0:
            coe = 1.0 - kp_down * (error-1.0)
        # 负溢出扶持
        else:
            coe = 1.0 + kp_up * (1.0-error)

        bank_key = '\t'.join([dim, agg_dim, cmatch, trans_type, deep_trans_type])
        if bank_key not in bank_account_dict:
            bank_account_dict[bank_key] = [FIDUCIAL, record, deep_conv, tcpa, charge, deep_tcharge, error, coe]
        
        # 异常，没赋值
        if error == 0 or coe == 0:
            continue

        # 误差在一定范围内，不调整
        if error >= 0.9 and error <= 1.1:
            coe = 1.0
        
        if charge >= 20 * tcpa or deep_conv >= 20:
            coe_tmp = max(min(coe, 1.3), 0.7)
        elif 10 * tcpa <= charge < 20 * tcpa or 10 <= deep_conv < 20:
            coe_tmp = max(min(coe, 1.2), 0.8)
        else:
            coe_tmp = max(min(coe, 1.1), 0.9)
        feedback_coe = round(coe_tmp, 4) 

        # 写入反馈词典
        feedback_coe_value = '\t'.join(map(str, [dim, agg_dim, cmatch, trans_type, deep_trans_type, feedback_coe]))
        if feedback_coe_key not in feedback_coe_dict:
            feedback_coe_dict[feedback_coe_key] = feedback_coe_value
            print(feedback_coe_value)

    print ("Calculated feedback coe...", file=sys.stderr)

def output_data_dict(data_for_bak):
    """
    功能：输出词典
    参数：词典存储路径
    """

    with open(data_for_bak, 'w') as f:
        for key, value in bank_account_dict.items():
            value = '\t'.join(map(str, value))
            f.write(key + '\t' + value + '\n')
    print("save middle data in oder to offer bank account", file=sys.stderr)

# 读取配置文件
config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)
entity_dim = config["DIM"].get("ENTITY_DIM")
user_dim = config["DIM"].get("USER_DIM")
plan_dim = config["DIM"].get("PLAN_DIM")
unit_dim = config["DIM"].get("UNIT_DIM")
fiducial = int(config["FEEDBACK"].get("FIDUCIAL_THRESHOLD"))
max_coe = float(config["FEEDBACK"].get("MAX_COE"))
min_coe = float(config["FEEDBACK"].get("MIN_COE"))
kp = float(config["FEEDBACK"].get("PID_KP"))
kp_down = float(config["FEEDBACK"].get("PID_KP_DOWN"))
kp_up = float(config["FEEDBACK"].get("PID_KP_UP"))
bak_cmatch = config["BANK_ACCOUNT"].get("BAK_CMATCH").split(',')
data = sys.stdin.read()
date = sys.argv[1]
shallow_data = sys.argv[2]
data_for_bak = sys.argv[3]
eps=1e-6

# 策略新增
HARD_BRAKE="HARD_BRAKE"
SOFT_BRAKE="SOFT_BRAKE"
FIDUCIAL="FIDUCIAL"

# 全局变量
shallow_dict = {}
bank_account_dict={}
feedback_coe_dict = {}

if __name__ == '__main__':
    load_shallow_dict(shallow_data)
    data_dict = load_unit_dict(data, date)
    brake_strategy()
    fiducial_feedback_coe()
    output_data_dict(data_for_bak)
