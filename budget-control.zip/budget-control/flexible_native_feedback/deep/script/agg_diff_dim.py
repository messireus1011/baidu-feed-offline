# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/07/06
Function：反馈计算
Input：   转化延迟修正后的数据
          key：datehour, unitid, planid, userid, cmatch, pricing_type, bid_source, is_ocpc_deep, trans_type, deep_trans_type
Output：  按不同dim聚合后的数据
          key：date_hour, dim, agg_dim, cmatch, trans_type, deep_trans_type
"""

import configparser
import datetime
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path

def load_user_dim_dict(user_dim_file):
    """
    功能：账户层级生效反馈的账户名单
    参数：账户词典
    """

    print("load user dim dict", file=sys.stderr)

    with open(user_dim_file, 'r') as f:
        for line in f:
            user = line.strip()
            user_dim_dict[user] = 1


def agg_diff_dim(data):
    """
    功能：将分小时的反馈数据聚合成不同维度
    参数：反馈分小时数据
    """

    print("Loading data dict...", file=sys.stderr)

    for line in data.strip().split("\n"):
        items = line.strip().split('\t')
        date_hour, unit, plan, user, cmatch, pricing_type, bid_source, is_ocpc_deep, trans_type, deep_trans_type, \
                eshow, clk, conv, obid, tcharge, charge, coe, entity = items
        eshow, clk, conv, obid, tcharge, charge, coe = map(float, [eshow, clk, conv, obid, tcharge, charge, coe])

        # 默认单元维度
        dim = unit_dim
        ## 计划维度
        ## 如果一个计划下既有计划层级出价，又有单元层级出价，则根据 bid_source分别聚合
        #if bid_source == "2":
        #    dim = plan_dim
        ## 账户维度
        #if user in user_dim_dict:
        #    dim = user_dim

        # 全切账户
        if deep_trans_type in ["10","26"] and cmatch in ["545","669","719"]:
            dim = user_dim
                
        # 分不同层级与不同时间窗口聚合数据
        if dim == unit_dim:
            key = '\t'.join([date_hour, dim, unit, cmatch, trans_type, deep_trans_type])
        elif dim == plan_dim:
            key = '\t'.join([date_hour, dim, plan, cmatch, trans_type, deep_trans_type])
        elif dim == user_dim:
            key = '\t'.join([date_hour, dim, user, cmatch, trans_type, deep_trans_type])
        else:
            continue

        if key not in data_dict:
            data_dict[key] = [0.0] * 6
        data_dict[key][0] += (eshow + clk)
        data_dict[key][1] += conv
        data_dict[key][2] += obid
        data_dict[key][3] += tcharge
        data_dict[key][4] += charge
        data_dict[key][5] += coe

def output_data_dict(dict_data):
    """
    功能：输出词典
    参数：词典存储路径
    """

    for key, value in dict_data.items():
        value = '\t'.join(map(str, value))
        print(key + '\t' + value)

    print("save data into dict", file=sys.stderr)

config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)
entity_dim = config["DIM"].get("ENTITY_DIM")
user_dim = config["DIM"].get("USER_DIM")
plan_dim = config["DIM"].get("PLAN_DIM")
unit_dim = config["DIM"].get("UNIT_DIM")
data = sys.stdin.read()
user_dim_file = sys.argv[1]
user_dim_dict = {} # 账户维度生效反馈
data_dict = {} # 分维度聚合后的数据
if __name__ == '__main__':
    load_user_dim_dict(user_dim_file)
    agg_diff_dim(data)
    output_data_dict(data_dict)
