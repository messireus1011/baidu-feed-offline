#!/bin/sh
TURING_HADOOP=/home/users/yangye03/tools/hadoop_client/hadoop_turing/hadoop/bin/hadoop
PYTHON=/usr/bin/python

daytime=`date +%Y%m%d`
echo $daytime

days=14
yesterday=`date -d "1 day ago $daytime" +%Y%m%d`
curr=1
day_str=`date -d "$curr day ago $yesterday" +%Y%m%d`
while [[ $curr -ne $days ]];do
	((curr++))
	day_tmp=`date -d "$curr day ago $yesterday" +%Y%m%d`
	day_str=$day_str,$day_tmp
done
echo $day_str

$TURING_HADOOP fs -text userpath.autobid_personalized_conv/{$day_str}/part* > merge_conv_ori
$TURING_HADOOP fs -text userpath.autobid_personalized_eshow/{$day_str}/part* > merge_eshow_ori

awk 'BEGIN{FS="\x01";OFS="\t"}{if(NF<5) next; print $1,$2,$3,$4,$5,$6,$7,$8,$9}' merge_conv_ori > merge_conv
awk 'BEGIN{FS="\x01";OFS="\t"}{if(NF<5) next; print $1,$2,$3,$4,$5,$6,$7}' merge_eshow_ori > merge_eshow

#get the autobid unit
wget yy-feed01.bcc-szwg.baidu.com:/home/users/yangye03/routine_job/autobid_showx/autobid_unit_latest -O autobid_unit_latest

# merge conv: userid,unitid,match_type,mining_type,cmatch,trans_type,income_sum,convs_sum,tcharge_sum
cat merge_conv | awk 'BEGIN{FS=OFS="\t"}{key=$1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6;charge[key]+=$7;conv[key]+=$8;tcharge[key]+=$9;}END{for(i in charge) print i, charge[i], conv[i], tcharge[i]}' | sort -t$'\t' -k2gr > conv_info

# merge eshow: userid,unitid,match_type,mining_type,cmatch,trans_type,eshow_sum
cat merge_eshow | awk 'BEGIN{FS=OFS="\t"}{key=$1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6;eshow[key]+=$7;}END{for(i in eshow) print i, eshow[i]}' > eshow_info

# merge conv & eshow
# userid,unitid,match_type,mining_type,cmatch,trans_type(6),income_sum(7),convs_sum(8),tcharge_sum(9),eshow_sum(10)
awk 'BEGIN{FS=OFS="\t"}ARGIND==1{key=$1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6;eshow[key]=$7;}ARGIND==2{key2=$1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6; print $1,$2,$3,$4,$5,$6,$7,$8,$9,eshow[key2]}' eshow_info conv_info > info_merge

# generate unit res
# unitid,match_type,mining_type,cmatch,charge,tcharge,eshow,charge_sum_uid,eshow_sum_uid
awk 'BEGIN{FS=OFS="\t"}ARGIND==1{obid[$1]=$3/100}ARGIND==2{if(!($2 in obid)) next; if($7<(obid[$2]*10)) next; if($7<350) next; if($10<5000) next; sum_charge[$2]+=$7; sum_eshow[$2]+=$10;key=$2"\t"$3"\t"$4"\t"$5; charge[key]+=$7; tcharge[key]+=$9;eshow[key]+=$10}END{for(i in charge) {split(i,res,"\t");uid=res[1];if(sum_charge[uid]<3000) continue; print i, charge[i],tcharge[i]/100, eshow[i], sum_charge[uid],sum_eshow[uid]}}' autobid_unit_latest info_merge | sort -t$'\t' -k8 -k1 -k5 -gr > unit_res

# genereate user res
# userid,trans_type,match_type,mining_type,cmatch,charge(6),tcharge(7),eshow(8)
cat info_merge | awk 'BEGIN{FS=OFS="\t"}{key=$1"\t"$6"\t"$3"\t"$4"\t"$5;charge[key]+=$7;tcharge[key]+=$9;eshow[key]+=$10;}END{for(i in charge) print i, charge[i], tcharge[i],eshow[i]}' | sort -t$'\t' -k1 -k6 -gr > user_info_merge

# userid,trans_type,match_type,mining_type,cmatch,charge,tcharge,eshow,charge_sum,eshow_sum
cat user_info_merge | awk 'BEGIN{FS=OFS="\t"}{if($6<1000) next; if($8<10000) next; key1=$1"\t"$2;key2=$1"\t"$2"\t"$3"\t"$4"\t"$5;sum_charge[key1]+=$6;sum_eshow[key1]+=$8;charge[key2]+=$6;tcharge[key2]+=$7;eshow[key2]+=$8;}END{for(i in charge){split(i,res,"\t"); tmp_key=res[1]"\t"res[2]; if(sum_charge[tmp_key]<3000) continue; print i, charge[i], tcharge[i]/100, eshow[i], sum_charge[tmp_key], sum_eshow[tmp_key]}}' | sort -t$'\t' -k9 -k1 -k2 -gr > user_res

# compute control ratio
$PYTHON unit.py > unit_res_up
$PYTHON user.py > user_res_up

awk 'BEGIN{FS=OFS="\t"}ARGIND==1{rec[$1]=1}ARGIND==2{if($1 in rec) print $1,$2,$3,$4,$5}' autobid_unit_latest unit_res_up |sort -t$'\t' -k1 -k2 -k3 > final_unit_part

awk 'BEGIN{FS=OFS="\t"}ARGIND==1{rec[$1]=1}ARGIND==2{if(!($1 in rec)) print $0}' final_unit_part autobid_unit_latest > unit_wait

awk 'BEGIN{FS=OFS="\t"}{rec[$2]=$1"\t"$6}END{for(i in rec) print i, rec[i]}' info_merge > unit_user_transtype

$PYTHON wait.py > final_user_part

# generate the final dict
cat final_unit_part final_user_part > final_res
awk 'BEGIN{FS=OFS="\t"}ARGIND==1{srcid[$1]=$2}ARGIND==2{if($4 in srcid) print $1,$2,$3,srcid[$4],$5}' cmatch_srcid.txt final_res > autobid_personalized_dict.txt

mkdir -p data/$daytime
mv final_unit_part data/$daytime/
mv final_user_part data/$daytime/
cp autobid_personalized_dict.txt final_user_part data/$daytime/
cp autobid_unit_latest data/$daytime/

delete_day=`date -d "30 day ago" +%Y%m%d`
rm -rf data/$delete_day

$TURING_HADOOP fs -rm userpath.autobid_personalized_dict/autobid_personalized_dict.txt
$TURING_HADOOP fs -put autobid_personalized_dict.txt userpath.autobid_personalized_dict/

rm merge_conv_ori
rm merge_eshow_ori
rm merge_conv
rm merge_eshow
rm conv_info
rm eshow_info
rm info_merge
rm unit_res
rm user_info_merge
rm user_res
rm unit_res_up
rm user_res_up
rm unit_user_transtype
rm unit_wait
