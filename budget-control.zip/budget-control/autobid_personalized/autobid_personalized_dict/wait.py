#!/usr/bin/python
# -*- coding: UTF-8 -*-

""" unit user merge """

user_rec = {}
for line in open("user_res_up"):
    user_id, trans_type, match_type, mining_type, cmatch, final_adjust_ratio, eshow_ratio = line.strip().split("\t")

    key = '\t'.join(map(str, [user_id, trans_type]))

    value = '\t'.join(map(str, [match_type, mining_type, cmatch, final_adjust_ratio]))
    if key not in user_rec:
        user_rec[key] = []

    user_rec[key].append(value)

map_rec = {}
for line in open("unit_user_transtype"):
    unit_id, user_id, trans_type = line.strip().split("\t")
    key = unit_id
    value = '\t'.join(map(str, [user_id, trans_type]))

    map_rec[key] = value


for line in open("unit_wait"):
    unit_id = line.strip().split("\t")[0]
    if unit_id not in map_rec:
        continue
    
    user_key = map_rec[unit_id]
    if user_key not in user_rec:
        continue

    for i in range(len(user_rec[user_key])):
        print '\t'.join(map(str, [unit_id, user_rec[user_key][i]]))
