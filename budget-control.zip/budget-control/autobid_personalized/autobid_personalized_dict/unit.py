#!/usr/bin/env python
# coding=utf-8

""" unit level stat """

adjust_raito_arr = {}
eshow_ratio_arr = {}
product_sum_arr = {}
for line in open("unit_res"):
    unit_id, match_type, mining_type, cmatch, charge, tcharge, eshow, charge_sum, eshow_sum =\
            line.strip().split("\t")
    key = '\t'.join(map(str, [unit_id, match_type, mining_type, cmatch]))

    if float(charge) < 0.001: continue
    if float(tcharge) < 0.001: tcharge = 1
    if float(eshow_sum) < 0.001: continue
    if float(eshow) < 0.001: continue

    adjust_ratio = float(tcharge) / float(charge);
    if adjust_ratio < 0.5: adjust_ratio = 0.5
    if adjust_ratio > 1.5: adjust_ratio = 1.5

    eshow_ratio = float(eshow) / float(eshow_sum)
    product = adjust_ratio * eshow_ratio

    adjust_raito_arr[key] = adjust_ratio
    eshow_ratio_arr[key] = round(eshow_ratio, 2)
    product_sum_arr[unit_id] = product_sum_arr.get(unit_id, 0) + product

for key in adjust_raito_arr:
    unit_id, match_type, mining_type, cmatch = key.split("\t")

    if unit_id not in product_sum_arr: continue
    if product_sum_arr.get(unit_id, 0) <= 0: continue

    final_adjust_ratio = adjust_raito_arr[key] / product_sum_arr.get(unit_id, 0)
    final_adjust_ratio = round(final_adjust_ratio, 2)
    print '\t'.join(map(str, [unit_id, match_type, mining_type, cmatch, final_adjust_ratio, eshow_ratio_arr[key]]))
