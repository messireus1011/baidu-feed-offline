#!/usr/bin/env python
# coding=utf-8

""" user level stat """

adjust_raito_arr = {}
eshow_ratio_arr = {}
product_sum_arr = {}
for line in open("user_res"):
    user_id, trans_type, match_type, mining_type, cmatch, charge, tcharge, eshow, charge_sum, eshow_sum =\
            line.strip().split("\t")
    key = '\t'.join(map(str, [user_id, trans_type, match_type, mining_type, cmatch]))

    if float(charge) < 0.001: continue
    if float(tcharge) < 0.001: tcharge = 1
    if float(eshow_sum) < 0.001: continue
    if float(eshow) < 0.001: continue

    adjust_ratio = float(tcharge) / float(charge);
    if adjust_ratio < 0.5: adjust_ratio = 0.5
    if adjust_ratio > 1.5: adjust_ratio = 1.5

    eshow_ratio = float(eshow) / float(eshow_sum)
    product = adjust_ratio * eshow_ratio

    adjust_raito_arr[key] = adjust_ratio
    eshow_ratio_arr[key] = round(eshow_ratio, 2)

    product_key = '\t'.join(map(str, [user_id, trans_type]))
    product_sum_arr[product_key] = product_sum_arr.get(product_key, 0) + product

for key in adjust_raito_arr:
    user_id, trans_type, match_type, mining_type, cmatch = key.split("\t")

    product_key = '\t'.join(map(str, [user_id, trans_type]))
    if product_key not in product_sum_arr: continue
    if product_sum_arr.get(product_key, 0) <= 0: continue

    final_adjust_ratio = adjust_raito_arr[key] / product_sum_arr.get(product_key, 0)
    final_adjust_ratio = round(final_adjust_ratio, 2)
    print '\t'.join(map(str, [user_id, trans_type, match_type, mining_type, cmatch, \
            final_adjust_ratio, eshow_ratio_arr[key]]))
