# -*- coding: utf-8 -*-
# !/usr/bin/env python3
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Authors:  chenjunhao02@baidu.com
Date:     2022/04/22
Function：合并统一单元内ocpc和ocpm的数据
Input：   从palo数据库中得到的原始数据
          key：date, hour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type
Output：  聚合后的单元数据
          key：date, hour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type
"""

import configparser
import datetime
import time
import logging
import logging.config
import math
import os
import sys
from pathlib import Path

def load_data_dict(palo_data):
    """
    功能：生成数据词典
    参数：palo_data palo数据库导出的文件
    """
    print("Loading palo data into dict...",file=sys.stderr)
    data_dict = {}
    for line in palo_data.strip().split("\n"):
        items = line.strip().split('\t')
        date, hour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type, \
                eshow, clk, conv, obid, conv_obid, charge, bat, coe, roiq, ubmq, ctrq, ctcvrq = items
        key = '\t'.join([date, hour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type])
        data_dict[key] = [eshow, clk, conv, obid, conv_obid, charge, bat]
    
    print("palo data dict size[{}]".format(len(data_dict)), file=sys.stderr)
    return data_dict

def output_data_dict():
    """
    功能：输出词典
    参数：词典存储路径
    """
    # output_path = open(save_data_path, 'w')
    for key, value in data_dict.items():
        value = '\t'.join(map(str, value))
        print(key + '\t' + value)
    print("save ocpx data after merge", file=sys.stderr)


def combine_ocpx_data(palo_data):
    """
    功能：合并同一单元内既有ocpc又有ocpm的数据
    参数：palo_data palo数据库导出的文件，data_dict 根据合并数据生成的数据词典
    """

    print ("Combining ocpx data...", file=sys.stderr)

    for line in palo_data.strip().split("\n"):
        items = line.strip().split('\t')
        date, hour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type, \
                eshow, clk, conv, obid, conv_obid, charge, bat, coe, roiq, ubmq, ctrq, ctcvrq = items
    
        eshow, clk, conv = map(int, [eshow, clk, conv])
        # 这里obid已经是转化级别obid的求和了
        obid, conv_obid, charge, bat = map(float, [obid, conv_obid, charge, bat])
        # 跳过ocpm单元
        if (pricing_type == '1'):
            continue

        # 对于ocpc单元把类型改成ocpm，若有数据存在则需合并
        ocpc_key = "\t".join([date, hour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type])
        pricing_type = '1'
        ocpm_key = "\t".join([date, hour, unitid, planid, userid, cmatch, pricing_type, is_ocpc_deep, trans_type, deep_trans_type])

        if ocpm_key in data_dict:

            # 读取该单元ocpm的数据
            ocpm_eshow, ocpm_clk, ocpm_conv, ocpm_obid, ocpm_conv_obid, ocpm_charge, ocpm_bat = data_dict[ocpm_key]
            ocpm_eshow, ocpm_clk, ocpm_conv = map(int, [ocpm_eshow, ocpm_clk, ocpm_conv])
            ocpm_obid, ocpm_conv_obid, ocpm_charge, ocpm_bat = map(float, [ocpm_obid, ocpm_conv_obid, ocpm_charge, ocpm_bat])
            
            total_eshow, total_clk, total_conv, total_obid, total_conv_obid, total_charge, total_bat \
                    = eshow, clk, conv, obid, conv_obid, charge, bat

           # 移除原有的key
            del data_dict[ocpm_key]
            del data_dict[ocpc_key]

            # 合并到转化数多的，不加前缀的是ocpc数据，加了的是ocpm数据
            # c合并到m
            if ocpm_conv >= conv:
                pricing_type = "1"
                new_key = ocpm_key
                # 按比例折算ocpc的数据，这里obid是累加值
                eshow = (conv * ocpm_eshow / ocpm_conv) if ocpm_conv > 0 else 0
                obid = (obid/clk * eshow) if clk > 0 else 0
                total_eshow = int(ocpm_eshow + eshow)
                total_obid = ocpm_obid + obid
            # m合并到c
            else:
                pricing_type = "0"
                new_key = ocpc_key
                # 按比例折算ocpm的数据
                ocpm_clk = (clk / conv * ocpm_conv) if conv > 0 else 0
                ocpm_obid = (ocpm_obid/ocpm_eshow * ocpm_clk) if ocpm_eshow > 0 else 0
                total_clk = int(ocpm_clk + clk)
                total_obid = ocpm_obid + obid

            # 直接累加conv,charge,bat,conv_obid
            total_conv = int(ocpm_conv + conv)
            total_charge = ocpm_charge + charge
            total_bat = ocpm_bat + bat
            total_conv_obid = ocpm_conv_obid + conv_obid

            # add new key
            data_dict[new_key] = map(str, [total_eshow, total_clk, total_conv, total_obid, total_conv_obid, total_charge, total_bat])

    print("Combinined ocpx data, data_dict size[{}]".format(len(data_dict)), file=sys.stderr)

# 读取配置文件
config = configparser.ConfigParser()
conf_path = Path("./conf/conf.ini")
config.read(conf_path)
cal_level = config["DEFAULT"].get("CAL_LEVEL").split(',')

# 将数据读入内存，方便进行多次读取
palo_data = sys.stdin.read() 
# save_data_path = sys.argv[1]

if __name__ == '__main__':
    data_dict = load_data_dict(palo_data)
    combine_ocpx_data(palo_data)
    output_data_dict()
