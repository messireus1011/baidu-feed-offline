#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: main.py
Author: sundaren(sundaren@baidu.com)
Date: 2023/04/07 18:22:24
"""

import numpy as np
import time
from env import Env
import copy
import json
import sys
from models.dt_model import *

np.set_printoptions(precision=3)
eps = 1e-6

def eva_func(observations, ob_dim, actions, env):
    """
    eva_func
    s[0] 0 0被忽略了
    s有24维，a只有23维
    输出的是 s[t+1] a[t]，即t时刻反馈的作用效果
    """
    total_charge = total_tcharge = single_charge = double_charge = 0.0
    num = 0
    for item, action in zip(observations, actions):
        a = np.zeros(ob_dim)

        print('===' * 30)
        print(env.keys[num])
        for t in range(25):
            a += item[t]
            cv = a[7]
            t_charge = a[8]
            t_tcharge = a[9]
            
            excess = t_charge / (t_tcharge + eps) - 1
            if t < 24:
                print(t, cv, excess, action[t])
            else:
                print(t, cv, excess, "end")


        cv = a[7]
        charge = a[8]
        tcharge = a[9]
        
        cur_diff = charge / (tcharge + eps) - 1
        total_charge += charge
        total_tcharge += tcharge
        if cur_diff > -0.2 and cur_diff < 0.2:
            double_charge += charge
        else:
            print("error", env.keys[num])
        if cur_diff < 0.2:
            single_charge += charge
        num += 1
    excess = total_charge / (total_tcharge + eps) - 1
    print("chg:%.2f tchg:%.2f excess:%.2f sb:%.2f db:%.2f" 
            %(total_charge, total_tcharge, excess, single_charge / total_charge, double_charge / total_charge))


if __name__ == "__main__":
    file_name = sys.argv[1]
    model_name = str(sys.argv[2])
    #output_idx = str(sys.argv[2])

    config = configparser.ConfigParser()
    config.read('confs/dt_model.conf')
    default_config = config['DEFAULT']
    state_dim = int(default_config['state_dim'])
    act_dim = int(default_config['act_dim'])
    
    # 测试样本数量
    sample_len = 500000
    ob_dim = 10
    # 表示 tcharge - charge = 0
    return_to_go = 0
    env = Env(file_name, sample_len, ob_dim = ob_dim, sep = '\x01')   

    # env的输出格式是定的：show, clk, cv, charge, tcharge, accu_show, accu_clk, accu_cv, accu_charge, accu_tcharge
    keys = list(env.keys)
    ins_len = min(sample_len, len(keys))
    print("len", sample_len, len(keys), ins_len)

    observations = []
    actions = []
    dt_model = DTModel(state_dim, act_dim, 'cpu')
    dt_model.load_model(model_name)

    for idx in range(ins_len):
        #if keys[idx] != 8045155897:
        #    continue
        # 输入ins的标号idx和model，输出该ins分小时的state和action
        ins_ob, action_list = env.run_ins(idx, dt_model, return_to_go)

        observations.append(ins_ob)
        actions.append(action_list)
    # 原始输入样本和行为    
    observations = np.array(observations)
    actions = np.array(actions)

    # 统一下存储的格式
    # observations = [[ob_0], [ob_1], .... [ob_23]]
    # actions = [[a_0], [a_1], ..., [a_23]]
    # a_i 产生了 ob_i+1
    eva_func(observations, ob_dim, actions, env)


 
