#!/usr/bin/env python3
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: main.py
Author: sundaren(sundaren@baidu.com)
Date: 2023/04/07 18:22:24
"""

import numpy as np
import torch
import wandb
import argparse
import pickle
import random
import sys
import configparser
from models.dt_model import *

from decision_transformer.models.decision_transformer import DecisionTransformer
from decision_transformer.training.seq_trainer import SequenceTrainer
import pandas as pd

eps = 1e-6


def discount_cumsum(x, gamma):
    """
    x: [1, 3, 4, 5, 6], gamma = 1
    discount_cumsum: [19, 18, 15, 11, 6]
    """
    discount_cumsum = np.zeros_like(x)
    discount_cumsum[-1] = x[-1]
    for t in reversed(range(x.shape[0] - 1)):
        discount_cumsum[t] = x[t] + gamma * discount_cumsum[t + 1]
    return discount_cumsum


def load_ins(ob_dim, model):
    """
    根据轨迹文件生成训练所需的trajectories
    trajectories = [ traj_i, ... ]
    traj = {observations: [], actions: [], rewards: []}
    注意 actions_i 产生 observations_i+1 和rewards_i+1
    """
    ob_file = 'datas/observations_1'
    action_file = 'datas/actions_1'

    training_observations = np.load(ob_file, allow_pickle=True)
    training_actions = np.load(action_file, allow_pickle=True)

    # 随机shuffle
    #permutation = np.random.permutation(training_observations.shape[0])
    #training_observations = training_observations[permutation]
    #training_actions = training_actions[permutation]

    #print(training_actions)
    trajectories = []

    for unit_ob, unit_action in zip(training_observations, training_actions):
        states = []
        actions = []
        rewards = []
        
        # get_state(self, obversitions, ob_dim, timesteps)
        # 根据timesteps，利用起obversitions算出当下的state
        ori_state = model.get_state(unit_action, unit_ob, ob_dim, 0)
        # 初始状态
        states.append(ori_state)
        actions.append(unit_action[0][0])
        # todo，改reward，构成更有效的训练
        rewards.append(0)

        for t in range(1, 24):
            # 一定要用model.get_state，不然会乱
            # get_state用range(0, t)的数据，
            state_t = model.get_state(unit_action, unit_ob, ob_dim, t)
            action_t = unit_action[t][0]
            reward_t = model.get_reward(unit_ob, ob_dim, t)
            states.append(state_t)
            actions.append(action_t)
            rewards.append(reward_t)
        
        states = np.array(states)
        actions = np.array(actions)
        rewards =  np.array(rewards)
        '''
        print('--' * 50)
        print('reward', rewards)
        print('sum_r', np.sum(rewards))
        print('action', actions)
        print('states', states)
        '''
        traj = {'observations': states, 'actions': actions, 'rewards': rewards}
        trajectories.append(traj)

    return 0, 1, trajectories


def train_model(conf, model_name):
    """
    train_model
    """
    scale = 1
    default_config = config['DEFAULT']
    device = default_config['device']
    mode = default_config['mode']
    state_dim = int(default_config['state_dim'])
    max_ep_len = int(default_config['max_ep_len'])
    act_dim = int(default_config['act_dim'])
    
    dt_model = DTModel(state_dim, act_dim, device)

    # todo，改配置
    ob_dim = 10
    batch_size = int(default_config['batch_size'])
    max_len = int(default_config['K'])

    # 加载轨迹数据
    state_mean, state_std, trajectories = load_ins(ob_dim, dt_model)
    num_trajectories = len(trajectories)

    def get_batch(batch_size=batch_size, max_len=max_len):
        """
        get_batch
        """
        batch_inds = np.random.choice(np.arange(num_trajectories), size=batch_size, replace=True)
        s, a, r, rtg, timesteps, mask = [], [], [], [], [], []

        for i in range(batch_size):
            idx = int(batch_inds[i])
            traj = trajectories[idx]
            # 采样的起始index
            si = random.randint(0, traj['rewards'].shape[0] - 1)
            
            # 按max_len取预期样本长度
            s.append(traj['observations'][si: si + max_len].reshape(1, -1, state_dim))
            a.append(traj['actions'][si: si + max_len].reshape(1, -1, act_dim))
            r.append(traj['rewards'][si: si + max_len].reshape(1, -1, 1))

            # 实际长度
            tlen = s[-1].shape[1]

            # 时间戳和s, a, r是对应的
            timesteps.append(np.arange(si, si + tlen).reshape(1, -1))
            timesteps[-1][timesteps[-1] >= max_ep_len] = max_ep_len - 1  

            # reward to go，从si到最后的reward，todo，这里不确定对不对
            si_rtg = discount_cumsum(traj['rewards'][si: ], gamma = 1.0)
            cut_rtg = si_rtg[: tlen + 1]
            rtg.append(cut_rtg.reshape(1, -1, 1))
            if rtg[-1].shape[1] <= tlen:
                rtg[-1] = np.concatenate([rtg[-1], np.zeros((1, 1, 1))], axis=1)

            # padding，都补全到max_len，默认值：state->0， action->1，reward：0
            s[-1] = np.concatenate([np.zeros((1, max_len - tlen, state_dim)), s[-1]], axis=1)
            s[-1] = (s[-1] - state_mean) / state_std

            a[-1] = np.concatenate([np.ones((1, max_len - tlen, act_dim)) * -10., a[-1]], axis=1)
            r[-1] = np.concatenate([np.zeros((1, max_len - tlen, 1)), r[-1]], axis=1)

            # scaled rtg
            rtg[-1] = np.concatenate([np.zeros((1, max_len - tlen, 1)), rtg[-1]], axis=1) / scale
            timesteps[-1] = np.concatenate([np.zeros((1, max_len - tlen)), timesteps[-1]], axis=1)
            mask.append(np.concatenate([np.zeros((1, max_len - tlen)), np.ones((1, tlen))], axis=1))

        s = torch.from_numpy(np.concatenate(s, axis=0)).to(dtype=torch.float32, device=device)
        a = torch.from_numpy(np.concatenate(a, axis=0)).to(dtype=torch.float32, device=device)
        r = torch.from_numpy(np.concatenate(r, axis=0)).to(dtype=torch.float32, device=device)
        rtg = torch.from_numpy(np.concatenate(rtg, axis=0)).to(dtype=torch.float32, device=device)
        timesteps = torch.from_numpy(np.concatenate(timesteps, axis=0)).to(dtype=torch.long, device=device)
        mask = torch.from_numpy(np.concatenate(mask, axis=0)).to(device=device)
        return [s, a, r, rtg, timesteps, mask]
   
    model = DecisionTransformer(
        state_dim = state_dim,
        act_dim = act_dim,
        max_length = max_len,
        max_ep_len = max_ep_len,
        hidden_size = int(default_config['embed_dim']),
        n_layer = int(default_config['n_layer']),
        n_head = int(default_config['n_head']),
        n_inner = 4 * int(default_config['embed_dim']),
        activation_function = default_config['activation_function'],
        n_position = int(default_config['n_positions']),
        resid_pdrop = float(default_config['dropout']),
        attn_pdrop = float(default_config['dropout']),
    )
    
    model = model.to(device=device)
    warmup_steps = int(default_config['warmup_steps'])
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr = float(default_config['learning_rate']),
        weight_decay = float(default_config['weight_decay']),
    )
    
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer,
        lambda steps: min((steps + 1) / warmup_steps, 1)
    )
    
    # main function SequenceTrainer
    trainer = SequenceTrainer(
        model = model,
        optimizer = optimizer,
        batch_size = batch_size,
        get_batch = get_batch,
        scheduler = scheduler,
        loss_fn = lambda s_hat, a_hat, r_hat, s, a, r: torch.mean((a_hat - a)**2),
        #eval_fns=[eval_episodes(tar) for tar in env_targets],
    )

    for iter in range(int(default_config['max_iters'])):
        outputs = trainer.train_iteration(num_steps = int(default_config['num_steps_per_iter']), \
        iter_num = iter + 1, print_logs = True)

        iter_mean, iter_max, iter_test_mean, iter_test_max = \
            outputs[-4], outputs[-3], outputs[-2], outputs[-1]
        
        print('-' * 20, iter, iter_mean, iter_max, iter_test_mean, iter_test_max)

    dt_model = 'dt_model_' + str(model_name)
    torch.save(model.state_dict(), dt_model)


if __name__ == '__main__':
    model_name = sys.argv[1]
    config = configparser.ConfigParser()
    config.read('confs/dt_model.conf')
    train_model(config, model_name)
