#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: dqn.py
Author: sundaren(sundaren@baidu.com)
Date: 2023/04/07 18:22:24
"""


import numpy as np
import time
import sys
import copy
import random
import json
import numpy as np
import torch
import wandb
import argparse
import pickle
import random
import sys
import configparser
from decision_transformer.models.decision_transformer import DecisionTransformer

DATA_DIM = 10
eps = 1e-6


class DTModel:
    """
    DTModel
    """
    def __init__(self, state_dim, action_dim, device):
        """
        __init__
        """
        self.state_dim = state_dim
        self.act_dim = action_dim
        self.device = device
    
    def load_model(self, model_name):
        """
        load_model
        """
        config = configparser.ConfigParser()
        config.read('/home/work/dianshang/dt_native_feedback/shallow/conf/dt_model.ini')
        default_config = config['DEFAULT']

        model = DecisionTransformer(
                state_dim = int(default_config['state_dim']),
                act_dim = int(default_config['act_dim']),
                max_length = int(default_config['K']),
                max_ep_len = int(default_config['max_ep_len']),
                hidden_size = int(default_config['embed_dim']),
                n_layer = int(default_config['n_layer']),
                n_head = int(default_config['n_head']),
                n_inner = 4 * int(default_config['embed_dim']),
                activation_function = default_config['activation_function'],
                n_positions = int(default_config['n_positions']),
                resid_pdrop = float(default_config['dropout']), 
                attn_pdrop = float(default_config['dropout'])
                )
        model = model.to(device = self.device)
        model.load_state_dict(torch.load(model_name))
        model.eval()
        self.model = model


    # 剩余流量
    def get_left_flow_ratio(self, T):
        """ get left flow ratio """
        # 25个维度
        default_list = [1.0, 1.0, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.8, 0.8, 0.7, 0.7, 0.6, 0.6, 0.5, \
                0.5, 0.5, 0.4, 0.3, 0.3, 0.2, 0.2, 0.1, 0.0, 0.0]

        T = int(T)
        left_ratio = round(default_list[T], 2)
        return left_ratio

    # 归一化转化
    def get_conv_norm(self, conv, size):
        """ get_conv_norm """
        conv_norm = round(float(conv) / float(size), 1)
        conv_norm = max(conv_norm, 0.0)
        conv_norm = min(conv_norm, 1.0)
        return conv_norm

    # 计算溢出率
    def get_excess_ratio(self, tcpa, charge, tcharge):
        """ get_excess_ratio """
        if charge < eps:
            return 0.0
        max_ratio = 2.0
        tcharge, charge, tcpa = map(float, [tcharge, charge, tcpa])
        if tcpa < eps or tcharge < eps:
            return max_ratio
        diff = charge / (tcharge + eps) - 1
        ratio = round(diff, 2)
        ratio = min(ratio, max_ratio)
        return ratio

    # 消费速度
    def get_consume_fea(self, accum_data_arr, T, tcpa, size):
        """ get_consume_fea """

        result = 0.0
        if tcpa < eps:
            return result
        # 归一化
        if T <= 1:
            result = round(float(accum_data_arr[T]["chg"]) / tcpa / size, 2)
        else:
            charge_curr_hour = float(accum_data_arr[T]["chg"]) - float(accum_data_arr[T - 1]["chg"])
            result = round(charge_curr_hour * 1.0 / tcpa / size, 2)

        result = min(result, 5.0)
        result = max(result, 0)

        return result

    def get_curr_hour(self, T):
        """ get_curr_hour """
        ratio = round(float(T) / 23, 2)
        return ratio

    def get_statedd(self, actions, obversitions, ob_dim, timesteps):
        """
        利用起range(0, timesteps + 1)的数据，计算 timesteps 的累积状态s
        obversitions的index和小时区间为一一对应
        timestep t要用到 obversitions t 的数据
        """
        accu_ob = np.zeros(ob_dim)
        obid, show, clk, cv, charge, tcharge = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        
        for t in range(1, timesteps + 1):
            item = obversitions[t]
            accu_ob += item
            if t == timesteps:
                obid, hack1, hack2, hack3, hack4, \
                        show, clk, cv, charge, tcharge = obversitions[t]
                cur_cv = obversitions[t][7]
        
        cur_cv_norm = round(float(cv) / 20, 1)
        cur_cv_norm = max(cur_cv_norm, 0.0)
        cur_cv_norm = min(cur_cv_norm, 1.0)
        
        accu_cv = accu_ob[7]
        accu_charge = accu_ob[8]
        accu_tcharge = accu_ob[9]
        diff = accu_charge / (accu_tcharge + eps)
        diff = min(diff, 5)
        conv_norm = round(float(accu_cv) / 20, 1)
        conv_norm = max(conv_norm, 0.0)
        conv_norm = min(conv_norm, 1.0)
        state = [diff, conv_norm]
        return np.array(state)

    def get_state(self, actions, obversitions, ob_dim, timesteps):
        """
        利用起range(0, timesteps + 1)的数据，计算 timesteps 的累积状态s
        obversitions的index和小时区间为一一对应
        timestep t要用到 obversitions t 的数据
        """
        accu_ob = np.zeros(ob_dim)
        tcpa, obid, show, clk, conv, charge, tcharge = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        T = timesteps
        accum_data_arr = {}
        # print("actions", actions)
        # print("obversitions", obversitions)
        # actions 和 obversitions 为t时刻的行为和量，下标从0-23
        for t in range(1, T + 1):
            item = obversitions[t]
            # 训练
            coe = actions[t - 1][0]
            # 测试，不需要梯度信息
            # coe = actions[t - 1].detach().numpy()[0]
            if t not in accum_data_arr:
                accum_data_arr[t] = {}
            accum_data_arr[t]["conv"] = obversitions[t][7]
            accum_data_arr[t]["chg"] = obversitions[t][8]
            accum_data_arr[t]["tchg"] = obversitions[t][9]
            accum_data_arr[t]["coe"] = coe
            accum_data_arr[t]["obid"] = obversitions[t][0]
            if obversitions[t][0] > eps:
                tcpa = obversitions[t][0]

        for t in range(1, T + 1):
            if t <= 1: continue
            accum_data_arr[t]["conv"] = accum_data_arr[t]["conv"] + accum_data_arr[t - 1]["conv"]
            accum_data_arr[t]["chg"] = accum_data_arr[t]["chg"] + accum_data_arr[t - 1]["chg"]
            accum_data_arr[t]["tchg"] = accum_data_arr[t]["tchg"] + accum_data_arr[t - 1]["tchg"]

        if T in accum_data_arr:
            conv = accum_data_arr[T]["conv"]
            charge = accum_data_arr[T]["chg"]
            tcharge = accum_data_arr[T]["tchg"]

        if tcharge > eps and conv > eps:
            tcpa = tcharge / conv
        
        # fea1: 当前转化
        # 取 chg/obid 和 cv 的最大值
        hack_cv = conv
        if tcpa > eps and charge > eps:
            hack_cv = max(conv, charge / tcpa)
        fea1_cv = self.get_conv_norm(hack_cv, 10)
        #fea1_cv = self.get_conv_norm(conv, 10)

        # fea2: 整体溢出率
        # print("chg", tcpa, charge, tcharge)
        # 0时刻溢出率没问题希望1.0，但tcharge = 0是，应该溢出率是严重正溢出
        fea2_fb = 0.0 if T < 1 \
                else self.get_excess_ratio(tcpa, charge, tcharge)

        # fea3: 剩余流量
        fea3_left_flow = self.get_left_flow_ratio(T)

        # fea4: 当前小时
        #fea4_curr_hour = self.get_curr_hour(T)

        ### 下面为分小时特征，时间窗口为6
        # fea5: action_list
        # if no consume, default 1.0
        #fea5_action_1 = 1.0 if T < 1 else accum_data_arr[T].get("coe", 1.0)
        #fea5_action_2 = 1.0 if T - 1 < 1 else accum_data_arr[T - 1].get("coe", 1.0)
        #fea5_action_3 = 1.0 if T - 2 < 1 else accum_data_arr[T - 2].get("coe", 1.0)
        #fea5_action_4 = 1.0 if T - 3 < 1 else accum_data_arr[T - 3].get("coe", 1.0)
        #fea5_action_5 = 1.0 if T - 4 < 1 else accum_data_arr[T - 4].get("coe", 1.0)
        #fea5_action_6 = 1.0 if T - 5 < 1 else accum_data_arr[T - 5].get("coe", 1.0)

        # fea6: 分小时累积溢出率，结合 fea5，目的是为了看分小时调解后的溢出率变化情况
        #fea6_fb_1 = 0.0 if  T < 1 \
        #        else self.get_excess_ratio(tcpa, accum_data_arr[T]["chg"], accum_data_arr[T]["tchg"])
        #fea6_fb_2 = 0.0 if  T - 1 < 1 \
        #        else self.get_excess_ratio(tcpa, accum_data_arr[T - 1]["chg"], accum_data_arr[T - 1]["tchg"])
        #fea6_fb_3 = 0.0 if  T - 2 < 1 \
        #        else self.get_excess_ratio(tcpa, accum_data_arr[T - 2]["chg"], accum_data_arr[T - 2]["tchg"])
        #fea6_fb_4 = 0.0 if  T - 3 < 1 \
        #        else self.get_excess_ratio(tcpa, accum_data_arr[T - 3]["chg"], accum_data_arr[T - 3]["tchg"])
        #fea6_fb_5 = 0.0 if  T - 4 < 1 \
        #        else self.get_excess_ratio(tcpa, accum_data_arr[T - 4]["chg"], accum_data_arr[T - 4]["tchg"])
        #fea6_fb_6 = 0.0 if  T - 5 < 1 \
        #        else self.get_excess_ratio(tcpa, accum_data_arr[T - 5]["chg"], accum_data_arr[T - 5]["tchg"])

        # fea7: 分小时消费速度
        fea7_consume_1 = 0.0 if T < 1 else self.get_consume_fea(accum_data_arr, T, tcpa, 5)
        #fea7_consume_2 = 0.0 if T - 1 < 1 else self.get_consume_fea(accum_data_arr, T - 1, tcpa, 5)
        #fea7_consume_3 = 0.0 if T - 2 < 1 else self.get_consume_fea(accum_data_arr, T - 2, tcpa, 5)
        #fea7_consume_4 = 0.0 if T - 3 < 1 else self.get_consume_fea(accum_data_arr, T - 3, tcpa, 5)
        #fea7_consume_5 = 0.0 if T - 4 < 1 else self.get_consume_fea(accum_data_arr, T - 4, tcpa, 5)
        #fea7_consume_6 = 0.0 if T - 5 < 1 else self.get_consume_fea(accum_data_arr, T - 5, tcpa, 5)

        #state = [fea1_cv, fea2_fb, fea3_left_flow, fea4_curr_hour, \
        #        fea5_action_1, fea5_action_2, fea5_action_3, fea5_action_4, fea5_action_5, fea5_action_6, \
        #        fea6_fb_1, fea6_fb_2, fea6_fb_3, fea6_fb_4, fea6_fb_5, fea6_fb_6, \
        #        fea7_consume_1, fea7_consume_2, fea7_consume_3, fea7_consume_4, fea7_consume_5, fea7_consume_6]
        #state = [fea1_cv, fea2_fb, fea3_left_flow, \
        #        fea6_fb_1, fea6_fb_2, fea6_fb_3, fea6_fb_4, fea6_fb_5, fea6_fb_6, \
        #        fea7_consume_1, fea7_consume_2, fea7_consume_3, fea7_consume_4, fea7_consume_5, fea7_consume_6]
        # state = [fea1_cv, fea2_fb, fea3_left_flow]
        state = [fea1_cv, fea2_fb]
        #state = [fea1_cv, fea2_fb, fea3_left_flow, fea7_consume_1]

        # print(state)

        return np.array(state)


    def get_reward(self, obversitions, ob_dim, timesteps):
        """
        get_reward
        """
        def get_diff(charge, tcharge):
            """
            get_diff
            """

            if charge < eps:
                return 1
            diff = charge / (tcharge + eps)
            diff = min(diff, 5)
            return diff

        accu_ob = np.zeros(ob_dim)
        last_accu_cv = last_accu_charge = last_accu_tcharge = 0.0
        accu_cv = accu_charge = accu_tcharge = 0.0
        reward = 0.0
        items = obversitions[timesteps]
        obid, clk, cv, charge, tcharge, \
                accu_show, accu_clk, accu_cv, accu_charge, accu_tcharge = items
        
        #for t in range(1, timesteps+1):
        #    last_accu_cv = accu_ob[7]
        #    last_accu_charge = accu_ob[8]
        #    last_accu_tcharge = accu_ob[9]
        #    item = obversitions[t]
        #    accu_ob += item
        #    accu_cv = accu_ob[7]
        #    charge = accu_ob[8]
        #    tcharge = accu_ob[9]        
        #diff = get_diff(charge, tcharge)
        #last_diff = get_diff(last_accu_charge, last_accu_tcharge)

        #if last_diff > eps:
        #    reward = abs(last_diff - 1) - abs(diff - 1)
        
        reward = (accu_charge - accu_tcharge) / (obid + eps)

        # a delayed return
        reward = 0
        if timesteps == 24:
            reward = accu_charge / (accu_tcharge + eps) - 1
            reward = max(-0.5, min(reward, 1))
        return reward
    
    def get_action(self, states, actions, rewards, target_return, timesteps):
        """
        get_action
        """
        # todo
        state_mean = 0
        state_std = 1

        return self.model.get_action(\
                (states.to(dtype = torch.float32) - state_mean) / state_std,
                actions.to(dtype = torch.float32),
                rewards.to(dtype = torch.float32),
                target_return.to(dtype = torch.float32),
                timesteps.to(dtype = torch.long),
                )


