""" 
@author: yangye03@baidu.com
@date: 20230724
"""
import tarfile
import os
import json
import configparser
import requests
import sys
import shutil
import re
from tqdm import tqdm, trange
import numpy as np
import tensorflow as tf
from tensorflow.core.protobuf import rewriter_config_pb2
from tensorflow.python.client import device_lib
import time
from datetime import datetime
import csv
import argparse
from sys import exit
import codecs
import random

# if in Google Colaboratory
try:
    from google.colab import drive
except:
    pass

from gpt_2_simple import model

tf.compat.v1.disable_eager_execution()


def get_best_permutation(unsorted_list):
    """ 输入：随机序列 """
    """ 输出：最优序列 """
    def permute(nums):
        def backtrack(nums, path, result):
            if not nums:
                result.append(path)
                return

            for i in range(len(nums)):
                backtrack(nums[:i] + nums[i + 1:], path + [nums[i]], result)

        result = []
        backtrack(nums, [], result)
        return result

    candidate_list = permute(unsorted_list)

    max_value = 0;
    max_index = 0;
    for i in range(len(candidate_list)):
        tmp_value = 0
        for j in range(len(candidate_list[i])):
            tmp_value += candidate_list[i][j][j]
            if tmp_value > max_value:
                max_value = tmp_value
                max_index = i
    
    sorted_list = candidate_list[max_index]
    sorted_index_list = []
    for i in range(len(sorted_list)):
        item = sorted_list[i]
        index = unsorted_list.index(item)
        sorted_index_list.append(index)
    #print ("mark")
    #print (unsorted_list)
    #print (candidate_list[max_index])   
 
    return [sorted_list, sorted_index_list]
    

def get_batch_nums_sort(batch_size, sequence_size, feature_size, token_size):
    """ 生成batch ins """
    """     1. 生成随机序列"""
    """     2. 调用get_best_permutation获取对应最优序列"""
    valid = 3

    batch_feature = []
    batch_labels = []
    for index in range(batch_size):
        # ins
        one = []
        one.append([-1.0] * feature_size)
        
        # label
        label = []
        
        unsort_list = []
        sort_list = []
       
        for i in range(token_size):
            if i < valid:
                random_int1 = np.random.randint(1, 9)
                tmp = []
                tmp.append(random_int1)
                
                for j in range(feature_size - 1):
                    decay_ratio = random.uniform(0.5, 1.0)
                    tmp.append(random_int1 * decay_ratio)
                
                unsort_list.append(tmp)
            else:
                unsort_list.append([0] * feature_size)

        [sort_list, sort_index_list] = get_best_permutation(unsort_list)

        #padd_size = token_size - len(unsort_list)
        #if padd_size > 0:
        #    for k in range(len(unsort_list), token_size):
        #        unsort_list.append([0.0] * feature_size)
        #        sort_list.append([0.0] * feature_size)
        #        sort_index_list.append(k)
 
        for item in unsort_list:
            one.append(item)
        one.append([-1.0] * feature_size)
        
        for item in sort_list:
            one.append(item)
        one.append([-1.0] * feature_size)
    
        # 生成label one-hot
        #index = sorted(range(len(unsort_list)), key=lambda x: unsort_list[x])
        #label = np.eye(len(index))[index]
        #label = np.eye(len(sort_index_list))[sort_index_list]
        #lable_convert = np.array(label, dtype=np.float32)
        #batch_labels.append(lable_convert)
  
        #while len(one) < sequence_size:
        #    #one.insert(0, [0])
        #    one.append([0] * 10)
  
        #print ("one")
        #print (one)
        ins_one = np.array(one, dtype=np.float32)
        batch_feature.append(ins_one)

        #sort_index_list = np.array(sort_index_list, dtype=np.int32)
        #batch_labels.append(sort_index_list)
        label = np.eye(len(sort_index_list))[sort_index_list]
        lable_convert = np.array(label, dtype=np.float32)
        batch_labels.append(lable_convert)

        #print ("unsored list")
        #print (unsort_list)

    return [batch_feature, batch_labels]

def load_best_permutation():
    """ 加载已经生成好的最优序列 """
    res0 = np.load('data/matrx_0', allow_pickle=True)
    res1 = np.load('data/matrx_1', allow_pickle=True)
    res2 = np.load('data/matrx_2', allow_pickle=True)
    res3 = np.load('data/matrx_3', allow_pickle=True)
    res4 = np.load('data/matrx_4', allow_pickle=True)
    res5 = np.load('data/matrx_5', allow_pickle=True)
    res6 = np.load('data/matrx_6', allow_pickle=True)
    res7 = np.load('data/matrx_7', allow_pickle=True)
    res8 = np.load('data/matrx_8', allow_pickle=True)
    res9 = np.load('data/matrx_9', allow_pickle=True)

    result = res0 + res1 + res2 + res3 + res4 + res5 + res6 + res7 + res8 + res9

    return result

def get_batch_nums_sort2(result, batch_size, positive_ratio, sequence_size, token_size, feature_size):
    """ 根据load_best_permutation已经加载的最优序列，生成随机序列，构造batch ins """
    batch_feature = []
    batch_labels = []
    
    for i in range(batch_size):
        index = random.sample(range(len(result)), 1)[0]
        sort_list = result[index]

        unsort_list_index = random.sample(range(len(sort_list)), len(sort_list))
        unsort_list = [sort_list[i] for i in unsort_list_index]
    
        sort_index_list = sorted(range(len(unsort_list_index)), key=lambda x: unsort_list_index[x])
        
        # use the the best permutation
        rand1 = random.sample(range(len(result)), 1)[0]
        if rand1 < batch_size * positive_ratio:
            unsort_list = sort_list.copy()
            sort_index_list = list(range(len(unsort_list)))   
        
        # ins
        one = []
        one.append([-1.0] * feature_size)
        
        for item in unsort_list:
            one.append(item)
        one.append([-1.0] * feature_size)

        for item in sort_list:
            one.append(item)
        one.append([-1.0] * feature_size)

        ins_one = np.array(one, dtype=np.float32)
        batch_feature.append(ins_one)

        # label
        #sort_index_list = np.array(sort_index_list, dtype=np.int32)
        #batch_labels.append(sort_index_list)
        
        label = np.eye(len(sort_index_list))[sort_index_list]
        lable_convert = np.array(label, dtype=np.float32)
        batch_labels.append(lable_convert)

    #print ("batch")
    #print (batch_feature)
    #print (batch_labels)

    return [batch_feature, batch_labels]



    
def train(config):
    """
    miao
    """
    # 模型配置读取
    batch_size = int(config['DEFAULT']['batch_size'])         # batch的大小
    positive_ratio = float(config['DEFAULT']['positive_ratio'])         # batch的大小
    sequence_size = int(config['DEFAULT']['sequence_size'])   # 序列的长度
    token_size = int(config['DEFAULT']['token_size'])         # 待排序广告的数量
    feature_size = int(config['DEFAULT']['feature_size'])     # feature的大小
    itreation_size = int(config['DEFAULT']['itreation_size']) # 迭代次数
    n_vocab = int(config['DEFAULT']['n_vocab'])               # 没有使用
    n_ctx = int(config['DEFAULT']['sequence_size'])                   # 等于sequence_size
    n_embd = int(config['DEFAULT']['n_embd'])                 # 隐层embedding的大小
    n_head = int(config['DEFAULT']['n_head'])                 # transformer多头
    n_layer = int(config['DEFAULT']['n_layer'])               # transformer block层数
    pt_w_size = int(config['DEFAULT']['pt_w_size'])

    # 模型结构定义
    hparams = model.HParams(pt_w_size = pt_w_size, n_ctx=n_ctx, n_embd=n_embd, n_head=n_head, n_layer=n_layer)
    place_feas = tf.compat.v1.placeholder(tf.float32, [None, sequence_size, feature_size], "place_feas")
    #place_feas_mask = tf.compat.v1.placeholder(tf.float32, [None, sequence_size, 1], "place_feas_mask")
    place_labels = tf.compat.v1.placeholder(tf.float32, [None, token_size, token_size], "place_labels") 
    #place_labels = tf.compat.v1.placeholder(tf.int32, [None, token_size], "place_labels") 
    output = model.model(hparams, place_feas, token_size)
    
    #loss = tf.reduce_mean(
    #        input_tensor= tf.square(output['logits']['feas_preds'][:, -token_size-2:-2] - place_labels))
    #loss = tf.reduce_mean(input_tensor=tf.nn.sparse_softmax_cross_entropy_with_logits(
    #    labels=place_labels, logits=output['logits']['feas_preds'][:, -token_size-2:-2]))
    #loss = tf.reduce_mean(input_tensor=tf.nn.sparse_softmax_cross_entropy_with_logits(
    #    labels=place_labels, logits=output['logits']['probs']))
    loss = tf.reduce_mean(
            input_tensor= tf.square(output['logits']['probs'] - place_labels))

    train_op = tf.train.AdamOptimizer(learning_rate=0.01).minimize(loss)
    
    
    # 模型变量初始化
    vars = tf.global_variables()
    init = tf.variables_initializer(vars)
    sess = tf.Session()
    sess.run(init)


    # 模型训练：迭代次数为iteration_size
    #get_batch_nums_sort
    #ins_box = load_ins(input_file)
    perm_box = load_best_permutation()
    for index in range(itreation_size):
        batch_feature, batch_labels = \
            get_batch_nums_sort2(perm_box, batch_size, positive_ratio, sequence_size, token_size, feature_size)
        #batch_feature, batch_labels = get_batch_nums_sort(batch_size, sequence_size, feature_size, token_size)
        #batch_feature, batch_cpa, batch_cv, batch_cv_mask = \
        #    get_batch(ins_box, batch_size, sequence_size, feature_size)
    
        #print ("test ins")
        #print (batch_feature)
        #print (batch_labels)
    
        aloss, _, out, p_feas = sess.run([loss, train_op, output, place_feas],
                feed_dict={place_feas: batch_feature,
                place_labels: batch_labels})

        print ("output")
        print (out['logits']['probs'])
        print (batch_labels)
        
        print ("loss %f" % aloss)

        # 模型保存
        model_path = "./model_path/nums_sort.ckpt"
        if index % 1000 == 0:
            saver = tf.train.Saver()
            saver.save(sess, model_path, global_step=index)

if __name__ == "__main__":
    config = configparser.ConfigParser()
    config.read('conf/train.conf')
    train(config)

    #result = load_best_permutation()
    #ins = get_batch_nums_sort2(result, 1, 23, 10)
    #print (ins)

    #res = get_batch_nums_sort(1, 9, 3, 3)
    #print (res)


    
