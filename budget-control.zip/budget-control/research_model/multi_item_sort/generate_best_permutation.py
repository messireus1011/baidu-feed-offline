""" 
@author: yangye03@baidu.com
@date: 20230724
@desc: 构造最优序列, 用于后序ins（随机序列）和label生成
"""
import tarfile
import os
import json
import configparser
import requests
import sys
import shutil
import re
from tqdm import tqdm, trange
import numpy as np
import tensorflow as tf
from tensorflow.core.protobuf import rewriter_config_pb2
from tensorflow.python.client import device_lib
import time
from datetime import datetime
import csv
import argparse
from sys import exit
import codecs
import random
from datetime import datetime
from itertools import permutations


# if in Google Colaboratory
try:
    from google.colab import drive
except:
    pass

from gpt_2_simple import model

tf.compat.v1.disable_eager_execution()


def max_diagonal_sum(matrix): 
    """输入: 10 * 10矩阵"""
    """输出：最优序列，主对角线和最大的序列""" 
    n = len(matrix)  
    max_sum = float('-inf')  
    best_permutation = []  
  
    # Generate all permutations of the rows  
    for perm in permutations(range(n)):  
        # Calculate the sum of the diagonal elements for this permutation  
        diagonal_sum = 0  
        for i in range(n):  
            diagonal_sum += matrix[perm[i]][i]  
  
        # Update the maximum sum and best permutation if necessary  
        if diagonal_sum > max_sum:  
            max_sum = diagonal_sum  
            best_permutation = perm  
  
    # Rearrange the matrix according to the best permutation  
    rearranged_matrix = [matrix[i] for i in best_permutation]  
    return rearranged_matrix, best_permutation


def get_batch_nums_sort(batch_size, idx):
    """ 批量获取最优序列 """
    batch_matrix = []
    for index in range(batch_size):
        unsort_list = []
        sort_list = []
        
        nums = 10
        for i in range(nums):
            random_int1 = np.random.randint(1, 9)
            decay_ratio1 = random.uniform(0.5, 1.0)
            decay_ratio2 = random.uniform(0.5, 1.0)
            decay_ratio3 = random.uniform(0.5, 1.0)
            decay_ratio4 = random.uniform(0.5, 1.0)
            decay_ratio5 = random.uniform(0.5, 1.0)
            decay_ratio6 = random.uniform(0.5, 1.0)
            decay_ratio7 = random.uniform(0.5, 1.0)
            decay_ratio8 = random.uniform(0.5, 1.0)
            decay_ratio9 = random.uniform(0.5, 1.0)
            unsort_list.append([random_int1 * 1.0, 
                    random_int1 * decay_ratio1,
                    random_int1 * decay_ratio2,
                    random_int1 * decay_ratio3,
                    random_int1 * decay_ratio4,
                    random_int1 * decay_ratio5,
                    random_int1 * decay_ratio6,
                    random_int1 * decay_ratio7,
                    random_int1 * decay_ratio8,
                    random_int1 * decay_ratio9])

        print ("permutate start")
        current_time = datetime.now()
        print (current_time)


        sort_list, sort_index_list = max_diagonal_sum(unsort_list)
        sort_index_list = np.array(sort_index_list)
        batch_matrix.append(sort_list)
        
        #print ("res")
        #print (unsort_list)
        #print (sort_list)
        #print (sort_index_list)

        print ("permutate end")
        current_time = datetime.now()
        print (current_time)

    batch_matrix = np.array(batch_matrix)
    batch_matrix.dump('data/matrx_' + str(idx))


if __name__ == "__main__":
    sys = sys.argv[1:]
    if len(sys) < 2:
        exit("wrong sys nums")
  
    batch_size = int(sys[0])
    idx = sys[1]
    
   
    print ("start time:")
    current_time = datetime.now()
    print (current_time)
    get_batch_nums_sort(batch_size, idx)
    print ("end time:")
    current_time = datetime.now()
