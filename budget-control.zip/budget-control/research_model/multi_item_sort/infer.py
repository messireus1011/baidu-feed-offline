"""
@author: yangye03@baidu.com
@date: 20230724
"""

import tarfile
import os
import json
import configparser
import requests
import sys
import shutil
import re
from tqdm import tqdm, trange
import numpy as np
import tensorflow as tf
from tensorflow.core.protobuf import rewriter_config_pb2
from tensorflow.python.client import device_lib
import time
from datetime import datetime
import csv
import argparse
from sys import exit
import codecs
import random

def load_model(meta_path, model_path, meta_file):
    """ 加载模型 """
    graph = tf.Graph()
    saver = tf.train.import_meta_graph(meta_path, graph=graph)
    
    sess = tf.Session(graph = graph)
    #ckpt = tf.train.latest_checkpoint(model_path)
    ckpt = os.path.join(model_path, meta_file)

    saver.restore(sess, ckpt)

    return [sess, graph]

def get_best_permutation(unsorted_list):
    def permute(nums):
        def backtrack(nums, path, result):
            if not nums:
                result.append(path)
                return

            for i in range(len(nums)):
                backtrack(nums[:i] + nums[i+1:], path + [nums[i]], result)

        result = []
        backtrack(nums, [], result)
        return result

    candidate_list = permute(unsorted_list)
    
    max_value = 0;
    max_index = 0;
    for i in range(len(candidate_list)):
        tmp_value = 0
        for j in range(len(candidate_list[i])):
            tmp_value += candidate_list[i][j][j]
            if tmp_value > max_value:
                max_value = tmp_value
                max_index = i

    #print ("mark")
    #print (unsorted_list)
    #print (candidate_list[max_index])

    return candidate_list[max_index]
def load_best_permutation():
    res0 = np.load('data/matrx_0', allow_pickle=True)
    res1 = np.load('data/matrx_1', allow_pickle=True)
    res2 = np.load('data/matrx_2', allow_pickle=True)
    res3 = np.load('data/matrx_3', allow_pickle=True)
    res4 = np.load('data/matrx_4', allow_pickle=True)
    res5 = np.load('data/matrx_5', allow_pickle=True)
    res6 = np.load('data/matrx_6', allow_pickle=True)
    res7 = np.load('data/matrx_7', allow_pickle=True)
    res8 = np.load('data/matrx_8', allow_pickle=True)
    res9 = np.load('data/matrx_9', allow_pickle=True)

    result = res0 + res1 + res2 + res3 + res4 + res5 + res6 + res7 + res8 + res9

    return result

def get_one2(result, batch_size, sequence_size, feature_size):
    index = random.sample(range(len(result)), 1)[0]
    sort_list = result[index]

    unsort_list_index = random.sample(range(len(sort_list)), len(sort_list))
    unsort_list = [sort_list[i] for i in unsort_list_index]

    sort_index_list = sorted(range(len(unsort_list_index)), key=lambda x: unsort_list_index[x])

    sort_list = np.array(sort_list, dtype=np.float32)
    unsort_list = np.array(unsort_list, dtype=np.float32)

    return [sort_list, unsort_list]

def get_one(sequence_size, feature_size, token_size):
    # ins

    unsort_list = []
    sort_list = []

    for i in range(token_size):
        random_int1 = np.random.randint(1, 9)
        tmp = []
        tmp.append(random_int1)

        for j in range(feature_size - 1):
            decay_ratio = random.uniform(0.5, 1.0)
            tmp.append(random_int1 * decay_ratio)

        unsort_list.append(tmp)

    sort_list = get_best_permutation(unsort_list)
        
    return [sort_list, unsort_list]

def do_predict_nums(meta_path, model_path, meta_file, config):
    """
    执行预测操作 
    """
    # 加载模型 
    sess, graph = load_model(meta_path, model_path, meta_file)
    
    sequence_size = int(config['DEFAULT']['sequence_size'])
    feature_size = int(config['DEFAULT']['feature_size'])
    token_size = int(config['DEFAULT']['token_size'])

    # 打印所有tensor的name                  
    #for n in graph.as_graph_def().node:
    #    print (n.name)              

    # 打印所有operations
    #for op in graph.get_operations():
    #    print(op.name)

    #sys.exit(1)

    # get ins
    ins_box = load_best_permutation()
   
    cnt = 0
    valid = 0
    for i in range(100):
        sort_list, unsort_list = get_one2(ins_box, 1, sequence_size, feature_size)
        #sort_list, unsort_list = get_one(sequence_size, feature_size, token_size)
        
        predict_list = []
        predict_list.append([-1.0] * feature_size)
        for j in range(len(unsort_list)):
            predict_list.append(unsort_list[j])
        predict_list.append([0] * feature_size)

        #ori_predict_list = []
        #valid_predict_list = []
        ori_result_list = []
        valid_result_list = []
        
        # 请求预估结果
        for k in range(token_size):
            input_list = predict_list.copy()
            while len(input_list) < sequence_size:
                input_list.append([0] * feature_size)

            place_feas = graph.get_operation_by_name('place_feas').outputs[0]
            feed_dict = {place_feas: [input_list]} 
            
            #result2 = graph.get_tensor_by_name("model/feas_preds/h2:0")
            #[[val2]] = sess.run([result2], feed_dict=feed_dict)
            #index = len(predict_list)
            #predict = val2[index - 1]
            #ori_result_list.append(predict)
            
            result2 = graph.get_tensor_by_name("model/stack_probs:0")
            [[val2]] = sess.run([result2], feed_dict=feed_dict)
            predict = val2[k]
            ori_result_list.append(predict)

            max_index = np.argmax(predict)
            value = unsort_list[max_index]
            valid_result_list.append(value)
            
            predict_list.append(value)
            

        cnt += 1
        if np.array_equal(np.array(valid_result_list), np.array(sort_list)):
            valid += 1

        print (" ori list ")
        print (np.array(unsort_list))
        print (" output softmax")
        print (np.array(ori_result_list))
        print ("output value")
        print (np.array(valid_result_list))

        print ("target list")
        print (sort_list)
        print ("\n\n")
        
    print ("cnt: %d, valid: %d, ratio: %.5f" % (cnt, valid, valid * 1.0 / cnt))

if __name__ == '__main__':
    config = configparser.ConfigParser()
    config.read('conf/train.conf')
    meta_path = 'model_path/nums_sort.ckpt-1000.meta'
    model_path = 'model_path/'
    meta_file = 'nums_sort.ckpt-1000'
    do_predict_nums(meta_path, model_path, meta_file, config)




    
