""" 
@author: yangye03@baidu.com
@date: 20230724
"""
import tarfile
import os
import json
import configparser
import requests
import sys
import shutil
import re
from tqdm import tqdm, trange
import numpy as np
import tensorflow as tf
from tensorflow.core.protobuf import rewriter_config_pb2
from tensorflow.python.client import device_lib
import time
from datetime import datetime
import csv
import argparse
from sys import exit
import codecs
import random

# if in Google Colaboratory
try:
    from google.colab import drive
except:
    pass

from gpt_2_simple import model

tf.compat.v1.disable_eager_execution()


def load_ins(file):
    """
    input: userid, trans_type, deep_trans_type, program_video_sign, bucket, shows, acp_avg, ctr_avg, cvr_avg, cpa_avg, cv_acc
    output: [{
                "feature_list":[[acp, ctr, cvr], [...], ...], 
                "cpa_list":[[cpa], [..], ...], 
                "cv_list":[[cv], [...], ...]
              }, 
              {...}, 
              ...
            ] 
    """

    # 存储ins
    ins_box = []
    
    # 基于<features, cpa> 预估 cv
    feature_list = [] 
    cpa_list = []
    cv_list = []
    
    key_pre = ""
    for line in open(file):

        # bucket: 将userid * video_sign 的曝光按cpa排序 分成了bucket份, 并已按bucket累加
        userid, trans_type, deep_trans_type, video_sign, bucket, shows, acp, ctr, cvr, cpa, cv \
                = line.strip().split("\x01")
        shows, acp, ctr, cvr, cpa, cv = map(float, [shows, acp, ctr, cvr, cpa, cv])
       
        # 将userid * video_sign下的输入聚合到一起
        # 如果bucket=100, 则feature_list， cpa_list， cv_list 的长度都是100
        key = userid + "\t" + trans_type + "\t" + deep_trans_type + "\t" + video_sign;
        if key_pre != "" and key != key_pre:
            ins_one = {'feature_list': np.array(feature_list, dtype=np.float32), 
                       'cpa_list': np.array(cpa_list, dtype=np.float32),
                       'cv_list': np.array(cv_list, dtype=np.float32)
                       }
            ins_box.append(ins_one)
            feature_list = []
            cpa_list = []
            cv_list = []
        
        
        feature_list.append([trans_type, deep_trans_type, shows, acp, ctr, cvr])
        cpa_list.append([cpa])
        cv_list.append([cv])
        
        key_pre = key

    return ins_box

def get_batch(ins_box, batch_size, sequence_size, feature_size):
    """
    随机抽取batch_size个样本
    """
    #print ("batch_size:%d %d %d" % (batch_size, sequence_size, feature_size))
    ins_total_num = len(ins_box)
    batch_inds = np.random.choice(np.arange(ins_total_num), size=batch_size, replace=True)
    
    batch_feature = []
    batch_cpa = []
    batch_cv = []
    batch_cv_mask = []
   
    for i in range(batch_size):
        item = ins_box[batch_inds[i]]
        feature_list = item['feature_list']
        cpa_list = item['cpa_list']
        cv_list = item['cv_list']

        # 截断， 长度超过sequence_size进行截断
        feature_list = feature_list[0: sequence_size]
        cpa_list = cpa_list[0: sequence_size]
        cv_list = cv_list[0: sequence_size]

        # padding, 长度不足sequence_size的话，补齐到sequence_size, 
        # 默认值：feature-> [0, 0, 0], cpa->[0], cv->[0]
        # cv_list_mask: 记录补齐的路径，后面loss计算时mask掉
        feature_list = np.concatenate([feature_list, 
                                       np.zeros((sequence_size - len(feature_list), feature_size))
                                      ])
        cpa_list = np.concatenate([cpa_list, 
                                   np.zeros((sequence_size - len(cpa_list), 1))
                                  ])
        cv_list = np.concatenate([cv_list, 
                                  np.zeros((sequence_size - len(cv_list), 1))
                                 ])
        cv_list_mask = np.concatenate([np.ones((len(cv_list), 1)),
                                  np.zeros((sequence_size - len(cv_list), 1))])
        
        # 放入batch ins
        batch_feature.append(feature_list)
        batch_cpa.append(cpa_list)
        batch_cv.append(cv_list)
        batch_cv_mask.append(cv_list_mask)

    return [batch_feature, batch_cpa, batch_cv, batch_cv_mask]

def get_batch_nums_sort(batch_size, sequence_size, feature_size):
    """
    返回一个包含batch_size个元素的列表，每个元素是长度为sequence_size且值为feature_size的二维数组。
    其中，feature_size包含[0,0,0],[random_int1,random_int2,random_int3], [random_int4,random_int5,random_int6],...,[0,0,0].
    这些值被随机生成，并按照从小到大的顺序排序，然后在每一个序列中重复插入相同的值。
    
    Args:
        batch_size (int): 批量大小。
        sequence_size (int): 序列大小。
        feature_size (int): 每个元素中的特征数量。
    
    Returns:
        list: 返回一个包含batch_size个元素的列表，每个元素是长度为sequence_size且值为feature_size的二维数组。
    
    """
    batch_feature = []
    batch_labels = []
    for index in range(batch_size):
        # ins
        one = []
        one.append([0, 0, 0])
        
        # label
        label = []
        
        unsort_list = []
        sort_list = []
        
        nums = int (sequence_size / 3)
        for i in range(nums):
            random_int1 = np.random.randint(1, 9)
            random_int2 = np.random.randint(1, 9)
            random_int3 = np.random.randint(1, 9)
            unsort_list.append([random_int1, random_int2, random_int3])
        sort_list = sorted(unsort_list)
        
        for item in unsort_list:
            one.append(item)
        one.append([0, 0, 0])
        
        for item in sort_list:
            one.append(item)
    
        # 生成label one-hot
        index = sorted(range(len(unsort_list)), key=lambda x: unsort_list[x])
        label = np.eye(len(index))[index]
        lable_convert = np.array(label, dtype=np.float32)
        batch_labels.append(lable_convert)
  
        while len(one) < sequence_size:
            #one.insert(0, [0])
            one.append([0, 0, 0])
  
        #print ("one")
        #print (one)
        ins_one = np.array(one, dtype=np.float32)
        batch_feature.append(ins_one)

    return [batch_feature, batch_labels]


def train(config, input_file="./data/ins.default"):
    """
    miao
    """
    # 模型配置读取
    batch_size = int(config['DEFAULT']['batch_size'])         # batch的大小
    sequence_size = int(config['DEFAULT']['sequence_size'])   # 序列的长度
    token_size = int(config['DEFAULT']['token_size'])         # 待排序广告的数量
    feature_size = int(config['DEFAULT']['feature_size'])     # feature的大小
    itreation_size = int(config['DEFAULT']['itreation_size']) # 迭代次数
    n_vocab = int(config['DEFAULT']['n_vocab'])               # 没有使用
    n_ctx = int(config['DEFAULT']['sequence_size'])                   # 等于sequence_size
    n_embd = int(config['DEFAULT']['n_embd'])                 # 隐层embedding的大小
    n_head = int(config['DEFAULT']['n_head'])                 # transformer多头
    n_layer = int(config['DEFAULT']['n_layer'])               # transformer block层数

    # 模型结构定义
    hparams = model.HParams(n_vocab=n_vocab, n_ctx=n_ctx, n_embd=n_embd, n_head=n_head, n_layer=n_layer)
    #place_feas = tf.compat.v1.placeholder(tf.float32, [batch_size, sequence_size, feature_size], "place_feas")
    #place_cpa = tf.compat.v1.placeholder(tf.float32, [batch_size, sequence_size, 1], "place_cpa")
    #place_cv = tf.compat.v1.placeholder(tf.float32, [batch_size, sequence_size, 1], "place_cv")
    #place_cv_mask = tf.compat.v1.placeholder(tf.float32, [batch_size, sequence_size, 1], "place_cv_mask")
    place_feas = tf.compat.v1.placeholder(tf.float32, [None, sequence_size, feature_size], "place_feas")
    #place_cpa = tf.compat.v1.placeholder(tf.float32, [None, sequence_size, 1], "place_cpa")
    #place_cv = tf.compat.v1.placeholder(tf.float32, [None, sequence_size, 1], "place_cv")
    #place_feas_mask = tf.compat.v1.placeholder(tf.float32, [None, sequence_size, 1], "place_feas_mask")
    place_labels = tf.compat.v1.placeholder(tf.float32, [None, token_size, token_size], "place_labels") 
    #output = model.model(hparams, place_feas, place_cpa, place_cv)
    output = model.model(hparams, place_feas, token_size)
    
    #loss = tf.reduce_mean(
    #        input_tensor= tf.minimum(tf.square(
    #        tf.multiply(output['logits']['cv_preds'], place_cv_mask) - place_cv), 25))
    #loss = tf.reduce_mean(input_tensor=tf.nn.sparse_softmax_cross_entropy_with_logits(
    #    labels=place_feas[:, 1:], logits=output['logits']['feas_preds'][:, :-1]))
    loss = tf.reduce_mean(
            input_tensor= tf.square(output['logits']['feas_preds'][:, -token_size-2:-2] - place_labels))

    train_op = tf.train.AdamOptimizer(learning_rate=0.01).minimize(loss)
    
    
    # 模型变量初始化
    vars = tf.global_variables()
    init = tf.variables_initializer(vars)
    sess = tf.Session()
    sess.run(init)


    # 模型训练：迭代次数为iteration_size
    #get_batch_nums_sort
    #ins_box = load_ins(input_file)
    for index in range(itreation_size):
        batch_feature, batch_labels = get_batch_nums_sort(batch_size, sequence_size, feature_size)
        #batch_feature, batch_cpa, batch_cv, batch_cv_mask = \
        #    get_batch(ins_box, batch_size, sequence_size, feature_size)
        
        aloss, _, out, p_feas = sess.run([loss, train_op, output, place_feas],
                feed_dict={place_feas: batch_feature,
                place_labels: batch_labels})

        #print ("output")
        #print(out['logits']['feas_preds'])
        #print (batch_labels)
        
        #print (out['logits']['cv_preds'])
        #print (pcv)
        #print (pcv_mask)
        print ("loss %f" % aloss)

        # 模型保存
        model_path = "./model_path/nums_sort.ckpt"
        if index % 10000 == 0:
            saver = tf.train.Saver()
            saver.save(sess, model_path, global_step=index)

if __name__ == "__main__":
    config = configparser.ConfigParser()
    config.read('conf/train.conf')
    input_file = "./data/ins.0810full"
    train(config, input_file)
    #res = get_batch_nums_sort(5, 9, 3)
    #print(res)
