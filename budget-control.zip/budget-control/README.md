Budget Control
===
Feed信息流广告业务预算控制相关离线脚本代码

快速开始
---
如何构建、安装、运行

测试
---
如何执行自动化测试

如何贡献
---
贡献patch流程及质量要求

版本信息
---
本项目的各版本信息和变更历史可以在[这里][changelog]查看。

维护者
---
### owners
* yangye03(yangye03@baidu.com)

### committers
* yangye03(yangye03@baidu.com)

讨论
---
百度Hi交流群：群号


[changelog]: http://icode.baidu.com/repos/baidu/feed-offline/budget-control/blob/master:CHANGELOG.md
