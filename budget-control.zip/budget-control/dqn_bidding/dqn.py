#!/usr/bin/env python
# -*- coding: gbk -*-
########################################################################
#
# Copyright (c) 2022 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: dqn.py
Author: sundaren(sundaren@baidu.com)
Date: 2022/10/29 18:22:24
"""

import numpy as np
import tensorflow as tf
from scipy.stats import entropy
import tensorflow.compat.v1 as tf
import copy

np.random.seed(1)
tf.set_random_seed(1)
tf.disable_eager_execution()
tf.disable_v2_behavior()


class DeepQNetwork:
    def __init__(
            self,
            n_actions,
            n_features,
            learning_rate,
            e_greedy,
            memory_size,
            batch_size):
        """
        init
        """
        self.n_actions = n_actions
        self.n_features = n_features
        self.lr = learning_rate
        self.epsilon_max = e_greedy
        self.memory_size = memory_size
        self.batch_size = batch_size
        self.epsilon = self.epsilon_max

        # total learning step
        self.learn_step_counter = 0

        # initialize zero memory [s, a, r, s_]
        self.memory = np.zeros((self.memory_size, n_features * 2 + 2))
        tf.reset_default_graph()

        # consist of [target_net, evaluate_net]
        self._build_net()
        self.saver = tf.train.Saver(max_to_keep=4)

        self.sess = tf.Session()

        self.sess.run(tf.global_variables_initializer())
        self.cost_his = []

    def _build_net(self):
        """
        _build_net
        """

        self.s = tf.placeholder(tf.float32, [None, self.n_features], name='s')
        self.q_target = tf.placeholder(tf.float32, [None, self.n_actions], name='Q_target')

        self.n_middle = 60

        with tf.variable_scope('eval_net'):
            # c_names(collections_names) are the collections to store variables
            c_names, n_l1, w_initializer, b_initializer = \
                ['eval_net_params', tf.GraphKeys.GLOBAL_VARIABLES], self.n_middle, \
                tf.random_normal_initializer(0, 0.3), tf.constant_initializer(0.01)

            # state layer
            with tf.variable_scope('state'):
                w1 = tf.get_variable('w1', [self.n_features, n_l1], initializer=w_initializer, collections=c_names)
                b1 = tf.get_variable('b1', [1, n_l1], initializer=b_initializer, collections=c_names)
                l1 = tf.nn.relu(tf.matmul(self.s, w1) + b1)  # Rectified Linear Unit

            # action layer
            with tf.variable_scope('action'):
                w2 = tf.get_variable('w2', [n_l1, self.n_actions], initializer=w_initializer, collections=c_names)
                b2 = tf.get_variable('b2', [1, self.n_actions], initializer=b_initializer, collections=c_names)
                self.q_eval = tf.matmul(l1, w2) + b2

        with tf.variable_scope('loss'):
            self.loss = tf.reduce_mean(tf.squared_difference(self.q_target, self.q_eval))
        with tf.variable_scope('train'):
            self._train_op = tf.train.RMSPropOptimizer(self.lr).minimize(self.loss)

    def store_transition(self, s, a, r, s_):
        """
        store_transition
        """
        if not hasattr(self, 'memory_counter'):
            self.memory_counter = 0

        transition = np.hstack((s, [a, r], s_))
        index = self.memory_counter % self.memory_size
        self.memory[index, :] = transition
        self.memory_counter += 1

    def choose_action(self, observation, use_explore=True):
        """
        choose_action
        """

        observation = observation[np.newaxis, :]

        actions_value = self.sess.run(self.q_eval, feed_dict={self.s: observation})[0]
        best_action = np.argmax(actions_value)

        random_f = np.random.uniform()

        if not use_explore:
            return best_action

        second_idx = 0
        second_val = -100000
        for i in range(self.n_actions):
            if i == best_action:
                continue
            if actions_value[i] > second_val:
                second_val = actions_value[i]
                second_idx = i

        max_idx = max(second_idx, best_action)
        min_idx = min(second_idx, best_action)
        idx_diff = max_idx - min_idx

        min_idx = second_idx
        min_val = 100000000
        use_reg = False

        if idx_diff > 5:
            use_reg = True
            for i in range(min_idx, max_idx):
                if actions_value[i] < min_val:
                    min_val = actions_value[i]
                    min_idx = i

        if not use_reg:
            if random_f <= 1 / 2.0:
                return np.random.randint(0, self.n_actions)
            return best_action

        else:
            if random_f <= 1 / 3.0:
                return np.random.randint(0, self.n_actions)
            if random_f <= 2 / 3.0:
                # print(actions_value, min_idx)
                return min_idx
            return best_action

    def check_q_dis(self):
        """
        learn
        """
        sample_index = np.random.choice(self.memory_size, size=self.batch_size)

        batch_memory = self.memory[sample_index, :]

        q_eval = self.sess.run(self.q_eval, feed_dict={self.s: batch_memory[:, :self.n_features]})

        res = []

        for actions_value in q_eval:
            best_action = np.argmax(actions_value)
            second_idx = 0
            second_val = -100000
            for i in range(self.n_actions):
                if i == best_action:
                    continue
                if actions_value[i] > second_val:
                    second_val = actions_value[i]
                    second_idx = i

            max_idx = max(second_idx, best_action)
            min_idx = min(second_idx, best_action)
            idx_diff = max_idx - min_idx
            res.append(idx_diff)

        q = np.array(range(10)) * 10

        print(np.percentile(res, q))

        for i in range(100):
            print(res[i], )
        print('===========')

    def learn(self):
        """
        learn
        """
        if self.memory_counter > self.memory_size:
            sample_index = np.random.choice(self.memory_size, size=self.batch_size)
        else:
            sample_index = np.random.choice(self.memory_counter, size=self.batch_size)
        batch_memory = self.memory[sample_index, :]

        q_eval = self.sess.run(self.q_eval, feed_dict={self.s: batch_memory[:, :self.n_features]})

        q_target = q_eval.copy()

        batch_index = np.arange(self.batch_size, dtype=np.int32)
        eval_act_index = batch_memory[:, self.n_features].astype(int)  # select act
        reward = batch_memory[:, self.n_features + 1]  # select reward

        q_target[batch_index, eval_act_index] = reward

        # regularization ?
        q_target[batch_index, np.clip(eval_act_index - 1, a_min=0, a_max=self.n_actions - 1)] \
            = 0.7 * reward + 0.3 * np.max(q_eval, axis=1)

        q_target[batch_index, np.clip(eval_act_index + 1, a_min=0, a_max=self.n_actions - 1)] \
            = 0.7 * reward + 0.3 * np.max(q_eval, axis=1)

        _, self.cost = self.sess.run([self._train_op, self.loss],
                                     feed_dict={self.s: batch_memory[:, :self.n_features],
                                                self.q_target: q_target})

        self.cost_his.append(np.mean(np.max(q_eval, axis=1)))
        self.learn_step_counter += 1

    def plot_cost(self):
        """
        plot_cost
        """
        import matplotlib.pyplot as plt
        plt.plot(np.arange(len(self.cost_his)), self.cost_his)
        plt.ylabel('Cost')
        plt.xlabel('training steps')
        plt.savefig('/Users/sundaren/Desktop/train_reward.jpg')

    def save(self):
        """
        save
        """
        self.saver.save(self.sess, "/Users/sundaren/Desktop/model_conv/my-model", global_step=1000)

    def close(self):
        """
        close
        """
        self.sess.close()
        del self.sess
