#!/usr/bin/env python
# -*- coding: gbk -*-
########################################################################
#
# Copyright (c) 2022 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: dqn.py
Author: sundaren(sundaren@baidu.com)
Date: 2022/10/29 18:22:24
"""

import numpy as np
import time
import sys
import copy
import random

DATA_DIM = 10
eps = 1e-6


# show, click, cv, charge, tcharge, cbid, post_clk, post_cv, post_charge, post_tcharge


def limit_diff(diff):
    """
    limit_diff
    """
    diff = max(diff, -1)
    diff = min(diff, 1)
    return diff


class Simulator(object):
    """
    Simulator
    """

    def __init__(self, n_action, step):
        """
        __init__
        """
        self.action_space = np.array(range(1, n_action)) * step
        self.n_actions = len(self.action_space)
        self.n_features = 16
        self.ori_data = {}
        self.keys = []
        self.load_data()

    def load_data(self):
        """
        load_data
        """
        file_name = '/Users/sundaren/Downloads/sorted_data_100w'
        for line in open(file_name):
            try:
                data = line.strip().split('\t')
                key = data[0]
                hour = int(data[1])
                param = float(data[2])
                # show, click, cv, charge, tcharge, cbid, post_clk, post_cv, post_charge, post_tcharge
                vals = np.array(list(map(float, data[3].split(','))))
                if key == '0':
                    continue
            except:
                continue

            if key not in self.ori_data:
                self.ori_data[key] = {}

            if len(self.ori_data.keys()) > 5000000:
                break
            if hour not in self.ori_data[key]:
                self.ori_data[key][hour] = []
            self.ori_data[key][hour].append([param, vals])

        self.keys = self.ori_data.keys()
        self.n = len(self.keys)
        print('total number of user: ', self.n)
        self.train_n = int(self.n * 0.7)

    def get_res(self, param, ins_data, hour, action):
        """
        get_res:
            given param, return hour result
            action: used for state
        """
        res = [param, np.zeros(DATA_DIM), action]

        if hour in ins_data:
            for val in ins_data[hour]:
                p = val[0]
                r = val[1]
                if param > p:
                    res = [param, r, action]
        return res

    def get_observation(self, res, t, use_post=False, cv_thr=5):

        """
        generate state using 0~t-1
        0~4: show, click, cv, charge, tcharge,
        5~9: cbid, post_clk, post_cv, post_charge, post_tcharge
        """

        a = np.zeros(10)
        S = []

        for i in range(t):
            if i not in res:
                continue
            a += res[i][1]
            param = res[i][0]
            action = res[i][2]
            pre_cv = a[0]
            cv = a[0]
            charge = a[3]
            tcharge = a[4]

            if use_post:
                cv = a[7]
                charge = a[8]
                tcharge = a[9]

            diff = charge / (tcharge + eps) - 1
            diff = limit_diff(diff)

            S.append([cv > cv_thr, diff, param, i, action, tcharge, charge, cv, pre_cv])

        if len(S) < 6:
            return np.zeros(self.n_features), 0

        ob = []

        for i in range(-1, -6, -1):
            ob.append(S[i][0])
            ob.append(S[i][1])
            ob.append(self.action_space[S[i][4]] / 50)
        ob.append(float(t) / 24)
        return np.array(ob), cv

    def step(self, t, key, Rl=None):
        """
        generate session for one user
        t: trick, run 0~t with default param
        """

        ins_data = self.ori_data[key]
        ins_res = []

        res = {}
        # default action
        action = 9
        base_param = 1.3
        next_param = base_param * self.action_space[action]

        # trick...
        for u in range(0, t):
            res[u] = self.get_res(next_param, ins_data, u, action)

        for u in range(t, t + 3):
            observation, _ = self.get_observation(res, u)
            action = Rl.choose_action(observation)
            next_param = base_param * self.action_space[action]

            for i in range(u, 24):
                res[i] = self.get_res(next_param, ins_data, i, action)

            final_ob, cv = self.get_observation(res, 24)

            diff = final_ob[1]
            diff = limit_diff(diff)
            reward = 2 - np.exp(3 * abs(diff))

            observation_next, _ = self.get_observation(res, u + 1)
            tmp = [observation, action, reward, observation_next]
            ins_res.append(tmp)
        return ins_res

    def test_total(self, RL=None, use_post=True):
        """
        test_total
        """
        keys = list(self.keys)

        t = 10
        n = 0.0
        ok_n = 0.0
        ok_2_n = 0.0
        s_ok = 0.0
        n_t = 0.0

        # sample in test dats
        for key_idx in range(self.train_n, self.n):
            res = {}
            sample_key = keys[key_idx]
            ins_data = self.ori_data[sample_key]
            base_param = 1.1
            b_action = 9
            next_param = base_param * self.action_space[b_action]

            for u in range(0, t):
                res[u] = self.get_res(next_param, ins_data, u, b_action)

            for u in range(t, 24):
                observation, _ = self.get_observation(res, u, use_post=use_post)
                action = RL.choose_action(observation, use_explore=False)
                next_param = base_param * self.action_space[action]
                res[u] = self.get_res(next_param, ins_data, u, action)

            final_ob, cv = self.get_observation(res, 24, use_post=use_post)

            n_t += 1.0
            if cv >= 5:
                diff = final_ob[1]
                if diff > -0.2 and diff < 0.2:
                    ok_n += 1
                if diff < 0.2:
                    s_ok += 1
                if diff > -0.3 and diff < 0.3:
                    ok_2_n += 1
                n += 1
        return '_'.join(map(str, [n_t, n, ok_n, s_ok, ok_2_n, ok_2_n / n, ok_n / n, s_ok / n]))
