#!/usr/bin/env python
# -*- coding: gbk -*-
########################################################################
#
# Copyright (c) 2022 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
File: dqn.py
Author: sundaren(sundaren@baidu.com)
Date: 2022/10/29 18:22:24
"""

from cpa_demo import Simulator
from dqn import DeepQNetwork
import numpy as np

def train():
    """
    train
    """
    step = 0
    keys = list(env.keys)

    for episode in range(10000000):
        key_idx = np.random.randint(0, env.train_n)
        sample_key = keys[key_idx]

        # ins_res: [, [state, action, reward, state_next], [], [], ..]
        ins_res = env.step(10, sample_key, RL)

        for k in ins_res:
            observation, action, reward, observation_ = k
            RL.store_transition(observation, action, reward, observation_)

        if step % 50 == 0 and step > 0:
            RL.learn()
            RL.plot_cost()

        if step % 10000 == 0 and step > 0:
            # RL.check_q_dis()
            f = open('test_res.txt', 'a+')
            res_post = env.test_total(RL=RL, use_post=True)
            res_pre = env.test_total(RL=RL, use_post=False)
            print('res_post: ', res_post)
            print('res_pre: ', res_pre)
            f.write('res_post: ' + res_post + '\n')
            f.write('res_pre: ' + res_pre + '\n')
            f.close()
            RL.save()

        step += 1


if __name__ == "__main__":
    """
        main
    """
    env = Simulator(n_action=50, step=0.1)
    RL = DeepQNetwork(env.n_actions, env.n_features,
                      learning_rate=0.0005,
                      e_greedy=0.5,
                      memory_size=2000000,
                      batch_size=300000)
    train()
    RL.close()