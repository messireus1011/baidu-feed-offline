""" author yangye03 """

#!/usr/bin/env python
# coding=utf-8

import random
import numpy as np

def gsp(advstr, w_arr, gap_arr):
    """ gsp auction """
    minbid = 5.0 * 0.01  # reserve price
    win_num = 1   # asn
    hit_num = 0   # the num of ads that is in w_arr
    items = advstr.strip().split("#")
    advlist = []
    for one in items:
        userid, unitid, bid, ctrq, roiq = one.split(",")

        # mutliply bid with the corresponding w
        if unitid in w_arr:
            #bid = float(bid) * float(w_arr[unitid]) * float(gap_arr[unitid])
            bid = float(bid) * float(w_arr[unitid])
            hit_num += 1

        # cpm, userid, unitid, bid, ctrq, roiq, price, conv
        adv = [float(bid) * float(ctrq)/1000000,
                userid,
                unitid,
                float(bid),
                float(ctrq)/1000000,
                float(roiq)/1000000,
                minbid,
                0]
        advlist.append(adv)

    if hit_num <= 0: return [] # no ad in w_arr 

    # sort by cpm
    advlist.sort(key = lambda x: x[0], reverse = True)

    #print "advlist"
    #print advlist

    # get gsp price
    # only keep the unit that is in w_arr
    adv_num = len(advlist)
    keep_list = []
    for i in range(0, win_num):
        if i >= adv_num: continue

        unitid = advlist[i][2]
        if unitid not in w_arr: continue

        if i < adv_num - 1:
            ctrq = advlist[i][4]
            if ctrq <= 0: continue

            gsp_score = advlist[i + 1][0]
            price = gsp_score
            if price > minbid:
                advlist[i][6] = price

        prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
        value_list = [1, 0]
        conv_num = np.random.choice(value_list, p = prob_list)
        #conv_num = advlist[i][4] * advlist[i][5]
        advlist[i][7] = conv_num
        
        # * 10
        advlist[i][0] = advlist[i][0] * 10
        advlist[i][6] = advlist[i][6] * 10
        for index in range(0, 9):
            conv_num_tmp = np.random.choice(value_list, p = prob_list)
            advlist[i][7] += conv_num_tmp

        keep_list.append(advlist[i])
        #if conv_num == 1:
        #    print "index"
        #    print conv_num
        #    print keep_list

    #print "keep_list"
    #print advlist
    #print keep_list
    return keep_list

def gsp_for_test(advstr, w_arr, gap_arr):
    """ gsp auction """
    minbid = 5.0 * 0.01  # reserve price
    win_num = 1   # asn
    items = advstr.strip().split("#")
    advlist = []
    for one in items:
        userid, unitid, bid, ctrq, roiq = one.split(",")

        # mutliply bid with the corresponding w
        if unitid in w_arr:
            bid = float(bid) * float(w_arr[unitid]) * float(gap_arr[unitid])

        # cpm, userid, unitid, bid, ctrq, roiq, price, conv
        adv = [float(bid) * float(ctrq)/1000000,
                userid,
                unitid,
                float(bid),
                float(ctrq)/1000000,
                float(roiq)/1000000,
                minbid,
                0]
        advlist.append(adv)


    # sort by cpm
    advlist.sort(key = lambda x: x[0], reverse = True)

    # get gsp price
    adv_num = len(advlist)
    keep_list = []
    for i in range(0, win_num):
        if i >= adv_num: continue

        unitid = advlist[i][2]
        if i < adv_num - 1:
            ctrq = advlist[i][4]
            if ctrq <= 0: continue

            gsp_score = advlist[i + 1][0]
            price = gsp_score
            if price > minbid:
                advlist[i][6] = price

        prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
        value_list = [1, 0]
        conv_num = np.random.choice(value_list, p = prob_list)
        #conv_num = advlist[i][4] * advlist[i][5]
        advlist[i][7] = conv_num
        
        keep_list.append(advlist[i])
    
    return keep_list

def gsp_auction(advstr, w_arr, gap_arr, obid_arr):
    """ gsp auction """
    minbid = 5.0 * 0.01  # reserve price
    win_num = 1   # asn
    hit_num = 0   # the num of ads that is in w_arr
    items = advstr.strip().split("#")
    advlist = []
    for one in items:
        if one == "" or one == "NULL": continue
        userid, unitid, bid, ctrq, roiq = one.split(",")
        
        if unitid not in obid_arr: continue
        
        gap_value = 1.3
        if unitid in gap_arr:
            gap_value = float(gap_arr[unitid])

        obid = float(obid_arr[unitid])
        
        # mutliply bid with the corresponding w
        bid = obid * float(roiq)/1000000 * gap_value
        
        if unitid in w_arr:
            bid = bid * float(w_arr[unitid])
            hit_num += 1

        # cpm, userid, unitid, bid, ctrq, roiq, price, conv
        adv = [float(bid) * float(ctrq)/1000000,
                userid,
                unitid,
                float(bid),
                float(ctrq)/1000000,
                float(roiq)/1000000,
                minbid,
                0]
        advlist.append(adv)

    if hit_num <= 0: return [] # no ad in w_arr 

    # sort by cpm
    advlist.sort(key = lambda x: x[0], reverse = True)

    #print "advlist"
    #print advlist

    # get gsp price
    # only keep the unit that is in w_arr
    adv_num = len(advlist)
    keep_list = []
    for i in range(0, win_num):
        if i >= adv_num: continue

        unitid = advlist[i][2]
        if unitid not in w_arr: continue

        if i < adv_num - 1:
            #ctrq = advlist[i][4]
            #if ctrq <= 0: continue

            gsp_score = advlist[i + 1][0]
            price = gsp_score
            if price > minbid:
                advlist[i][6] = price

        prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
        value_list = [1, 0]
        conv_num = np.random.choice(value_list, p = prob_list)
        #conv_num = advlist[i][4] * advlist[i][5]
        advlist[i][7] = conv_num
        
        # * 10
        advlist[i][0] = advlist[i][0] * 10
        advlist[i][6] = advlist[i][6] * 10
        for index in range(0, 9):
            conv_num_tmp = np.random.choice(value_list, p = prob_list)
            advlist[i][7] += conv_num_tmp

        keep_list.append(advlist[i])

    return keep_list

def calc_gap_arr(unit_list, eshow_sum_arr_cp, bid_sum_arr_cp, price_sum_arr_cp):
    """ calc gap arr """
    gap_arr = {}
    for unitid in unit_list:
        gap_arr[unitid] = 1.3
        if (unitid in eshow_sum_arr_cp) and eshow_sum_arr_cp[unitid] > 200:
            tmp_ratio = bid_sum_arr_cp[unitid] / price_sum_arr_cp[unitid]
            tmp_ratio = max(tmp_ratio, 1.0)
            tmp_ratio = min(tmp_ratio, 3.0)
            gap_arr[unitid] = tmp_ratio
        print ("gap_ratio unit:%s bid_sum:%.2f price_sum:%.2f ratio:%.2f"\
                % (unitid, bid_sum_arr_cp[unitid], price_sum_arr_cp[unitid], gap_arr[unitid]))
    return gap_arr

def load_unit(file):
    """ load_unit """
    unit_rec = {}
    for line in open(file):
        if len(line.strip().split("\t")) < 3: continue
        unit, obid, charge = line.split("\t")

        if obid == "": continue
        unit_rec[unit] = obid

    return unit_rec

def load_unit_with_prob(file, file2):
    """ load_unit_with_prob """

    unit_abandon = {}
    for line in open(file2):
        unitid, trans_type, is_ocpc_deep, deep_trans_type = line.strip().split("\t")
        if trans_type in ['26', '49', '42'] or deep_trans_type in ['26', '49', '42', '28']:
            unit_abandon[unitid] = trans_type + "\t" + deep_trans_type

    unit_rec = {}
    prob_total = 0.0
    for line in open(file):
        if len(line.strip().split("\t")) < 3: continue
        unitid, obid, charge, ratio = line.strip().split("\t")

        if obid == "": continue
        if unitid in unit_abandon: continue

        unit_rec[unitid] = float(ratio)
        prob_total += float(ratio)
    
    unit_rec[unitid] += (1 - prob_total)

    return unit_rec

def load_gap(file):
    """ load gap """
    gap_arr = {}
    for line in open(file):
        unitid, cmatch, ratio = line.strip().split("\t")
        ratio = float(ratio)
        ratio = round(ratio, 2)
        ratio = max(ratio, 1.0)
        ratio = min(ratio, 3.0)

        gap_arr[unitid] = ratio

    return gap_arr

def load_big_table(file):
    """ load_big_table """
    big_table = {}
    for line in open(file):
        try:
            unitid, hour, ratio, price, conv, bid_sum = line.strip().split("\t")
        except:
            continue

        key = '\t'.join(map(str, [unitid, hour, ratio]))
        if key not in big_table:
            big_table[key] = [0.0, 0.0, 0.0]
        
        big_table[key][0] = float(price)
        big_table[key][1] = float(conv)
        big_table[key][2] = float(bid_sum)

    return big_table

def get_unit_for_train(unit_rec, num):
    """ get_unit_for_train """
    unit_list = random.sample(unit_rec.keys(), num)
    return unit_list

def get_unit_for_train_with_prob(unit_rec, num):
    """ get_unit_for_train_with_prob """
    if num > len(unit_rec.keys()):
        num = len(unit_rec.keys())

    unit_list = np.random.choice(unit_rec.keys(), num, replace=False, p=unit_rec.values())

    return unit_list

def load_pv_sample(file):
    """ load_pv_sample """
    pv_rec = {}
    for line in open(file):
        items = line.strip().split("\x01")
        hour = int(items[2])
        searchid = items[3]
        ad_num = items[4]
        ad_str = items[5]

        if hour not in pv_rec:
            pv_rec[hour] = {}
        #pv_rec[hour][searchid] = ad_num + "\t" + ad_str
        pv_rec[hour][searchid] = ad_str

    return pv_rec


def load_state_file(file):
    """ load_state_file """
    result = {}
    for line in open(file):
        try:
            conv, excess_ratio, left_ratio, num = line.strip().split('\t')
            key = '\t'.join(map(str, [conv, excess_ratio, left_ratio]))
            result[key] = int(num)
        except:
            continue

    return result

def load_action_file_reverse(file):
    """ load_action_file_reverse """
    result = {}
    for line in open(file):
        try:
            ratio, num = line.strip().split('\t')
            result[int(num)] = float(ratio)
        except:
            continue

    return result

def load_state_file_reverse(file):
    """ load_state_file_reverse """
    state_map_reverse = {}
    state_num_list = []
    for line in open(file):
        if len(line.strip().split('\t')) != 4: continue
        conv, ratio, left_ratio, num = line.strip().split('\t')
        key = '\t'.join(map(str, [conv, ratio, left_ratio]))
        state_map_reverse[int(num)] = key
        state_num_list.append(int(num))

    return state_map_reverse, state_num_list

def get_feedback_ratio(conv, charge, obid):
    """ get_feedback_ratio """
    ratio = 1.0
    charge = float(charge)
    conv = float(conv)
    obid = float(obid)
    tcharge = obid * conv
    if tcharge <= 0:
        if charge > obid:
            ratio = round(obid / charge, 1)
    else:
        ratio = round(tcharge / charge, 1)

    ratio = max(ratio, 0.7)
    ratio = min(ratio, 1.3)
    
    return ratio

def calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action, gap_arr):
    """ calc_w_att """
    
    print "w_att"
    w_att = {}
    for index in range(len(unit_list)):
        unitid = unit_list[index]
        fb_r = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
        ac_r = action[index]

        w_att[unitid] = round(fb_r * ac_r - ac_r + 1, 2)
        w_att[unitid] = max(w_att[unitid], 0.5)
        w_att[unitid] = min(w_att[unitid], 1.9)
        
        w_att[unitid] = round(w_att[unitid] * gap_arr[unitid], 1)
        w_att[unitid] = max(w_att[unitid], 0.1)
        w_att[unitid] = min(w_att[unitid], 5.0)

        #w_att[unitid] = ac_r
        #print ("unit:%s conv:%d obid:%d charge:%.2f fb_r:%.2f ac_r:%.2f w:%f"\
        #        % (unitid, int(conv_arr[unitid]), int(obid_arr[unitid]),
        #            float(charge_arr[unitid]), fb_r, ac_r, w_att[unitid]))
        

    return w_att

def calc_w_att_for_test(unit_list, conv_arr, charge_arr, obid_arr, action_arr, gap_arr):
    """ calc_w_att """
    
    print "w_att"
    w_att = {}
    for index in range(len(unit_list)):
        unitid = unit_list[index]
        fb_r = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
        ac_r = action_arr[unitid]

        #ac_r = 1.9

        w_att[unitid] = round(fb_r * ac_r - ac_r + 1, 1)
        w_att[unitid] = max(w_att[unitid], 0.5)
        w_att[unitid] = min(w_att[unitid], 1.9)

        if w_att[unitid] <= 1.1 and w_att[unitid] >= 0.9:
            w_att[unitid] = 1.0

        w_att[unitid] = round(w_att[unitid] * gap_arr[unitid], 1)
        w_att[unitid] = max(w_att[unitid], 0.1)
        w_att[unitid] = min(w_att[unitid], 5.0)

        #w_att[unitid] = ac_r
        print ("unit:%s conv:%d obid:%d charge:%.2f fb_r:%.2f ac_r:%.2f w:%f"\
                % (unitid, int(conv_arr[unitid]), int(obid_arr[unitid]),
                    float(charge_arr[unitid]), fb_r, ac_r, w_att[unitid]))
        

    return w_att

def load_cyc(file):
    """ load_cyc """
    result = {}
    for line in open(file):
        try:
            plan_id, cyc_res = line.strip().split("\t")
            cyc_item = cyc_res.split("#")
            
            cyc_list = map(float, cyc_item)
            result[plan_id] = cyc_list
        except:
            continue

    return result

def get_state_num(conv, charge, obid, state_map, left_ratio):
    """ get_state_num """
    excess_ratio = 1.0
    charge = float(charge)
    obid = float(obid)
    conv = int(conv)

    tcharge = obid * conv
    if tcharge <= 0:
        #if charge >= (float(obid) * 1.5):
        #    excess_ratio = 2.0
        
        if charge > obid:
            excess_ratio = round(charge / obid, 1)

    else:
        excess_ratio = round(charge / tcharge, 1)

    excess_ratio = max(excess_ratio, 0.5)
    excess_ratio = min(excess_ratio, 2.0)
    
    conv = max(conv, 0)
    conv = min(conv, 20)
    conv_status = int(conv / 5) * 5

    key = '\t'.join(map(str, [conv_status, excess_ratio, left_ratio]))
    #print ("state_value conv:%d excess_ratio:%.2f" % (conv_status, excess_ratio))

    if key not in state_map:
        key = '\t'.join(map(str, [0, 1.0, 1.0]))

    num = state_map[key]
    return num

def get_state_value(conv, charge, obid, left_ratio):
    """ get_state_value """
    excess_ratio = 1.0
    tcharge = float(obid) * float(conv)
    if tcharge <= 0:
        if charge >= (float(obid) * 1.5):
            excess_ratio = 2.0
    else:
        excess_ratio = round(float(charge) / float(tcharge), 1)

    excess_ratio = max(excess_ratio, 0.5)
    excess_ratio = min(excess_ratio, 2.0)
    
    conv = int(conv)
    conv = max(conv, 0)
    conv = min(conv, 20)
    conv_status = int(conv / 5) * 5

    val = '\t'.join(map(str, [conv_status, excess_ratio, left_ratio]))

    return val

def get_ori_state(unit_size, state_size):
    """ get_ori_state """
    num_list = [65 for x in range(unit_size)]
    state = np.eye(state_size)[num_list]

    return state.astype('float32')

def get_curr_state(unit_list, state_size, conv_arr, charge_arr, obid_arr, state_map, cyc_rec, T):
    """ get_curr_state """
    num_list = []
    for unitid in unit_list:
        num = get_state_num(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid], state_map, cyc_rec[unitid][T])
        num_list.append(int(num))
    #print "state list"
    #print conv_arr
    #print charge_arr
    #print obid_arr
    #print num_list
    state = (np.eye(state_size)[num_list])

    return state.astype('float32'), num_list

def calc_rewards(unit_list, conv_arr, charge_arr, obid_arr):
    """ calc_rewards """
    total = len(unit_list)
    cnt = 0
    for unitid in unit_list:
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])
        if tcharge <= 0:
            if charge < obid:
                cnt += 1
        else:
            if charge > (0.8 * tcharge) and charge < (1.2 * tcharge):
                cnt += 1

    ratio = cnt / total

    return ratio

def calc_rewards_list(unit_list, conv_arr, charge_arr, obid_arr):
    """ calc_rewards_list """
    total = 0
    cnt = 0
    rewards = []
    for unitid in unit_list:
        total += 1
        val = 0
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])
        #if tcharge <= 0:
        #    if charge <  obid:
        #        val = 1
        #        cnt += 1
        #else:
        #    if charge > (0.8 * tcharge) and charge < (1.2 * tcharge):
        #        val = 1
        #        cnt += 1
        if tcharge > 0 and (charge > (0.8 * tcharge) and charge < (1.2 * tcharge)):
            val = 1
            cnt += 1

        rewards.append(val)

    print ("rewards total %d cnt %d  ratio %.2f" % (total, cnt, float(cnt) / float(total)))

    rewards = np.array(rewards).reshape(len(unit_list), 1).astype('float32')
    return rewards

def calc_rewards_list_with_tcharge(unit_list, conv_arr, charge_arr, obid_arr, base_tcharge):
    """ calc_rewards_list """
    total_tcharge = 0.0
    for unitid in unit_list:
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        total_tcharge = total_tcharge + tcharge

    tcharge_ratio = round(total_tcharge / base_tcharge - 1, 4)
    super_a = 0.1
    ratio = tcharge_ratio * super_a
    ratio = max(ratio, -0.02)
    ratio = min(ratio, 0.02)

    total = 0
    cnt = 0
    rewards = []
    for unitid in unit_list:
        total += 1
        val = 0
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])
        #if tcharge <= 0:
        #    if charge <  obid:
        #        val = 1
        #        cnt += 1
        #else:
        #    if charge > (0.8 * tcharge) and charge < (1.2 * tcharge):
        #        val = 1
        #        cnt += 1
        if tcharge > 0 and (charge > (0.8 * tcharge) and charge < (1.2 * tcharge)):
            val = 1
            cnt += 1
        
        unit_reward = val + ratio
        print "tcharge_reward: %s %.4f %.4f %.4f %.4f %.4f" % \
                (unitid, val, ratio, unit_reward, base_tcharge, total_tcharge)
        
        rewards.append(unit_reward)

    print ("rewards total %d cnt %d  ratio %.2f" % (total, cnt, float(cnt) / float(total)))

    rewards = np.array(rewards).reshape(len(unit_list), 1).astype('float32')
    return rewards

def calc_rewards_list2(unit_list, conv_arr, charge_arr, obid_arr):
    """ calc_rewards_list """
    total = 0
    cnt = 0
    rewards = []
    for unitid in unit_list:
        total += 1
        val = 0
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])
        if tcharge <= 0:
            if charge < obid:
                cnt += 1
            if charge > obid:
                val = charge / obid - 1
        else:
            val = abs(charge / tcharge - 1)
            if charge > (0.8 * tcharge) and charge < (1.2 * tcharge):
                cnt += 1

        rewards.append(val)

    print ("rewards total %d cnt %d  ratio %.2f" % (total, cnt, float(cnt) / float(total)))

    rewards = np.array(rewards).reshape(len(unit_list), 1).astype('float32')
    print (rewards)
    return rewards

def calc_base_tcharge(unit_list, w_arr, obid_arr, gap_arr, big_table):
    """ calc_base_tcharge """
    base_w_arr = w_arr.copy()
    base_gap_arr = gap_arr.copy()
    conv_arr = {}
    charge_arr = {}
    action_value = []
    for unitid in unit_list:
        conv_arr[unitid] = 0.0
        charge_arr[unitid] = 0.0
        action_value.append(1.0)

    f = open("base_tcharge.txt", "w")
    for T in range(0, 24):
        hour = ("%02d" % T)
        for unitid in unit_list:
            unit_w = base_w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))
            if key in big_table:
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]
        
                conv = float(fetch_list[1])
                obid = float(obid_arr[unitid])
                tcharge = conv * obid
                linestr = "one\t%s\t%d\t%.2f\t%.2f\t%.2f" % (unitid, T, conv, obid, tcharge)
                f.write(linestr + "\n")

        base_w_arr = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value, base_gap_arr)

    tcharge_total = 0.0
    for unitid in unit_list:
        conv = float(conv_arr[unitid])
        obid = float(obid_arr[unitid])
        tcharge = conv * obid
        tcharge_total = tcharge_total + tcharge
    
        linestr = "%s\t%.2f\t%.2f\t%.2f" % (unitid, conv, obid, tcharge)
        f.write(linestr + "\n")

    f.close()

    tcharge_total = round(tcharge_total, 2)
    
    return tcharge_total

if __name__ == "__main__":
    #advstr = "s1,u1,10,100000,100000#s2,u2,20,100000,100000"
    #res = gsp(advstr)
    #print res

    unit_size = 3
    state_size = 10
    state = get_ori_state(unit_size, state_size)
    print state
