""" fast_get_unit_gap """

#!/usr/bin/env python
# coding=utf-8
import datetime
import random
from func import *

import numpy as np
import sys

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)

USE_PREDICT = 1

if len(sys.argv) >= 2:
    USE_PREDICT = int(sys.argv[1])


# load obid arr all
obid_arr_all = load_unit("unit_obid_charge")

# big_table
big_table = load_big_table("big_talbe_nogap.txt_10000")

#load unit
unit_rec = load_unit_with_prob("unit_obid_charge_prob_10000")

# initialization
w_arr = {}
price_arr = {}
bid_arr = {}

for unitid in unit_rec:
    w_arr[unitid] = 1.0
    price_arr[unitid] = 1.0
    bid_arr[unitid] = 1.0

for num in range(0, 10):
    print "num:%d" % num 
    for unitid in unit_rec:
        price_arr[unitid] = 1.0
        bid_arr[unitid] = 1.0

    for T in range(0, 24):
        hour = ("%02d" % T)
        for unitid in unit_rec:
            unit_w = w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))
            #print "key:%s" % key
            if key in big_table:
                #print "hit"
                fetch_list = big_table[key]
                price_arr[unitid] += fetch_list[0]
                bid_arr[unitid] += fetch_list[2]
            else:
                #print "not hit"
                pass

    for unitid in unit_rec:
        if bid_arr[unitid] < 100 or price_arr[unitid] < 100: continue
        w_arr[unitid] = round(bid_arr[unitid] / price_arr[unitid], 1)
        w_arr[unitid] = min(w_arr[unitid], 3.0)
        print "check unit:%s bid:%.2f price:%.2f w:%.2f" % (unitid, bid_arr[unitid], price_arr[unitid], w_arr[unitid])

    wfile = "./wfile/wfile_%d" % num
    f_wfile = open(wfile, "w")
    for unitid in unit_rec:
        line_str = "%s\t%.1f\n" % (unitid, w_arr[unitid])
        f_wfile.write(line_str)
    f_wfile.close()
