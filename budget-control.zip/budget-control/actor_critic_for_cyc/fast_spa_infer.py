""" fast_spa_infer.py """

#!/usr/bin/env python
# coding=utf-8
import datetime
import random
from cyc_func import *

import numpy as np
import sys

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)

USE_PREDICT = 1

if len(sys.argv) >= 2:
    USE_PREDICT = int(sys.argv[1])


# load obid arr all
obid_arr_all = load_unit("unit_obid_charge")

# load gap arr
gap_arr = load_gap("unit_gap")

# big_table
big_table = load_big_table("big_talbe_nogap.txt_10000_pcoc")

#
unit_rec = load_unit_with_prob("unit_obid_charge_prob_10000", "unit_trans_type")

cyc_rec = load_cyc("unit_cyc")

# load infer
action_map = {}
#dict_infer infer_for_estimate
for line in open("dict_infer"):
    conv, excess, left_ratio, value = line.strip().split("\t")
    key = '\t'.join([conv, excess, left_ratio])
    action_map[key] = float(value)

# initialization
w_arr = {}
conv_arr = {}
charge_arr = {}
obid_arr = {}
action_arr = {}

for unitid in unit_rec:
    if unitid not in gap_arr:
        gap_arr[unitid] = 1.3
    w_arr[unitid] = gap_arr[unitid]

    obid_arr[unitid] = obid_arr_all[unitid]
    
    conv_arr[unitid] = 0.0
    charge_arr[unitid] = 0.0
    action_arr[unitid] = 1.0

for T in range(0, 24):
    hour = ("%02d" % T)
    for unitid in unit_rec:
        unit_w = w_arr[unitid]
        key = '\t'.join(map(str, [unitid, hour, unit_w]))
        if key in big_table:
            fetch_list = big_table[key]
            charge_arr[unitid] += fetch_list[0]
            conv_arr[unitid] += fetch_list[1]

    # update w_arr
    for unitid in w_arr:
        action_arr[unitid] = 1.0
        if USE_PREDICT == 0:
            continue
        
        state_value = get_state_value(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid], cyc_rec[unitid][T])
        if state_value in action_map:
            action = action_map[state_value]
            action_arr[unitid] = action
        #action_arr[unitid] = 3.0

    unit_list  = w_arr.keys()
    w_arr = calc_w_att_for_test(unit_list, conv_arr, charge_arr, obid_arr, action_arr, gap_arr)

# check results
total_cnt = 0
valid_cnt = 0
single_hit_cnt = 0
double_hit_cnt = 0
total_charge = 0.0
total_tcharge = 0.0

check_charge = {}
check_tcharge = {}

for unitid in unit_rec:
    conv = float(conv_arr[unitid])
    charge = float(charge_arr[unitid])
    obid = float(obid_arr[unitid])
    tcharge = obid * conv

    total_charge += charge
    total_tcharge += tcharge

    check_charge[unitid] = check_charge.get(unitid, 0.0) + charge
    check_tcharge[unitid] = check_tcharge.get(unitid, 0.0) + tcharge

    total_cnt += 1;
    if conv >= 5:
        valid_cnt += 1

        if charge <= 1.2 * tcharge:
            single_hit_cnt += 1
            
            if charge >= 0.8 * tcharge:
                double_hit_cnt += 1

excess_ratio = total_charge / total_tcharge - 1

if valid_cnt == 0: valid_cnt = 1.0
single_ratio = single_hit_cnt * 1.0 / valid_cnt
double_ratio = double_hit_cnt * 1.0 / valid_cnt

f_file = "check_results.txt_%d" % USE_PREDICT
f = open(f_file, 'w')
res_str = "res charge:%.2f tcharge:%.2f total_cnt:%d valid_cnt:%d single_hit:%d double_hit:%d \
        excess_ratio:%.2f single_ratio:%.2f double_rratio:%.2f" \
        % (total_charge, total_tcharge, total_cnt, valid_cnt, \
        single_hit_cnt, double_hit_cnt, excess_ratio, single_ratio, double_ratio)
f.write(res_str + "\n")
f.close()

t_file = "check_excess.txt_%d" % USE_PREDICT
t_f = open(t_file, "w")
for unitid in check_charge:
    line_str = '\t'.join(map(str, [unitid, check_charge[unitid], check_tcharge[unitid], conv_arr[unitid]]))
    t_f.write(line_str + "\n")
t_f.close()
