""" map_red file """
import sys
import random
#import numpy as np

def random_choice_one(seq, prob):
    """ random_choice_one """
    res = seq[0]
    p = random.random()
    for i in range(len(seq)):
        if sum(prob[:i]) < p <= sum(prob[:i + 1]):
            res = seq[i]
    return res

def takeSecond(elem):
    """ takeSecond """
    return elem[0]


def mapper():
    """ mapper """
    big_table = {}

    unit_rec = {}
    for line in open("unit_obid_charge_prob"):
        try:
            unitid, obid, charge, ratio = line.strip().split("\t")
        except:
            continue

        if obid == "": continue

        unit_rec[unitid] = 1

    obid_arr = {}
    for line in open("unit_obid_charge"):
        try:
            unitid, obid, charge = line.strip().split("\t")
        except:
            continue

        if obid == "": continue

        obid_arr[unitid] = obid

    gap_arr = {}
    for line in open("unit_gap"):
        try:
            unitid, cmatch, ratio = line.strip().split("\t")
        except:
            continue

        gap_arr[unitid] = ratio
    

    for line in sys.stdin:
        try:
            cmatch, day, hour, search_id, ad_num, ad_str = line.strip().split("\x01")
        except:
            continue

        advlist = []
        items = ad_str.strip().split("#") 

        for one in items:
            try:
                userid, unitid, bid, ctrq, roiq = one.split(",")
            except:
                continue
        
            if unitid not in obid_arr: continue

            obid = float(obid_arr[unitid])
            bid = obid * float(roiq)/1000000
            #gap_value = 1.3
            #if unitid in gap_arr:
            #    gap_value = float(gap_arr[unitid])
            #bid = obid * float(roiq)/1000000 * gap_value

            # cpm, userid, unitid, bid, ctrq, roiq, price, conv
            minbid = 5.0 * 0.01  # reserve price
            adv = [bid * float(ctrq)/1000000,
                    userid,
                    unitid,
                    bid,
                    float(ctrq)/1000000,
                    float(roiq)/1000000,
                    minbid,
                    0]

            if adv[0] <= 0: continue
            advlist.append(adv)

        #advlist.sort(key = lambda x: x[0], reverse = True)
        advlist = sorted(advlist, key = takeSecond, reverse = True)

        if len(advlist) < 2: continue

        # computing bid_charge
        for i in range(len(advlist)):
            # only keep the top units
            unitid = advlist[i][2]
            if unitid not in unit_rec:
                continue

            if i == 0:
                # charge
                price = advlist[i + 1][0]
                if price < minbid:
                    price = minbid

                # conv
                prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
                value_list = [1, 0]
                #conv_num = np.random.choice(value_list, p = prob_list)
                conv_num = random_choice_one(value_list, prob_list)

                ratio = round(advlist[i + 1][0] / advlist[i][0], 1)
                if ratio < 0.1: ratio = 0.1
                
                while ratio <= 5.0:
                    key = '\t'.join(map(str, [unitid, hour, ratio]))
                    if key not in big_table:
                        big_table[key] = [0.0, 0.0, 0.0]

                    big_table[key][0] += price
                    big_table[key][1] += conv_num
                    big_table[key][2] += (advlist[i][0] * ratio)
                
                    ratio += 0.1
            else:
                ratio = round(advlist[0][0] / advlist[i][0], 1)
                if ratio > 5.0: continue
                
                # charge
                price = advlist[0][0]
                if price < minbid:
                    price = minbid

                # conv
                prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
                value_list = [1, 0]
                #conv_num = np.random.choice(value_list, p = prob_list)
                conv_num = random_choice_one(value_list, prob_list)

                while ratio <= 5.0:
                    key = '\t'.join(map(str, [unitid, hour, ratio]))
                    if key not in big_table:
                        big_table[key] = [0.0, 0.0, 0.0]

                    big_table[key][0] += price
                    big_table[key][1] += conv_num
                    big_table[key][2] += (advlist[i][0] * ratio)

                    ratio += 0.1
                
    for key in big_table:
        var = '\t'.join(map(str, [key, big_table[key][0], big_table[key][1], big_table[key][2]]))
        print var

def reducer():
    """ reducer """
    reduce_table = {}
    for line in sys.stdin:
        try:
            unitid, hour, ratio, price, conv_num, bid_sum = line.strip().split("\t")
        except:
            continue

        key = '\t'.join(map(str, [unitid, hour, ratio]))
        if key not in reduce_table:
            reduce_table[key] = [0.0, 0.0, 0.0]

        reduce_table[key][0] += round(float(price), 1)
        reduce_table[key][1] += float(conv_num)
        reduce_table[key][2] += float(bid_sum)

    for key in reduce_table:
        var = '\t'.join(map(str, [key, reduce_table[key][0], reduce_table[key][1], reduce_table[key][2]]))
        print var

if __name__ == '__main__':
    exec sys.argv[1] + '()'
