#!/usr/bin/env bash
set -x
#source run.conf

HADOOP_YQUAN='/home/users/yangye03/tools/hadoop_client/cornac-client/hadoop/bin/cornac'
HDFS_YQUAN='afs://tianqi.afs.baidu.com:9902'
HDFS_BAIHUA='afs://baihua.afs.baidu.com:9902'
#PYTHON_BIN='/root/.jumbo/bin/python2.7'
PYTHON_TAR=/app/ecom/native-ad-price/yangye03/tools/python2.7.tar.gz

DATE=$1
DAYS=1
DATELIST=$DATE
i=1
while [[ $i -ne $DAYS ]];do
    DATE_TMP=`date -d "-$i day $DATE" +%Y%m%d`
    DATELIST=${DATELIST},$DATE_TMP
    ((i++));
done;
echo ${DATELIST}
#yquan token -gen -job-type static
#YQ01-TIANQI_ecom-buffer
#YQ01-XINGTIAN_native-ad

in_put=${HDFS_YQUAN}/app/ecom/native-ad-price/yangye03/programming/test_input/
in_put=afs://wudang.afs.baidu.com:9902/user/turing/export_data/22652871/result/
#out_path=${HDFS_YQUAN}/app/ecom/native-ad-price/yangye03/programming/545_output/
out_path=${HDFS_YQUAN}/app/ecom/native-ad-price/yangye03/programming/545_output_nogap/
${HADOOP_YQUAN} fs -rmr ${out_path}
${HADOOP_YQUAN} streaming  \
    -Dcornac.job.queue='YQ01-XINGTIAN_native-ad' \
    -D mapred.job.name="fz_native_research_yangye03_jifei_${DATE}" \
    -D mapred.job.priority='VERY_HIGH' \
    -D mapred.job.map.capacity=300 \
    -D mapred.job.reduce.capacity=100 \
    -D mapred.map.tasks=300 \
    -D mapred.reduce.tasks=100 \
    -D stream.memory.limit=16000 \
    -D mapred.reduce.slowstart.completed.maps=0.99 \
    -D mapred.hce.replace.streaming=false \
    -Dcornac.job.token=f6f550aca8935cf127f941dbbe54761f \
    -input ${in_put} \
    -output ${out_path} \
    -mapper "python/bin/python2.7 -v map_red.py mapper" \
    -reducer "python/bin/python2.7 -v map_red.py reducer" \
    -file "map_red.py" \
    -file "unit_obid_charge" \
    -file "unit_obid_charge_prob" \
    -file "unit_gap" \
    -cacheArchive ${PYTHON_TAR}'#python'

#${HADOOP_YQUAN} fs -cat ${out_path}/part-* > tmp2_${DATE}_${DAYS}
#cat tmp2_${DATE}_${DAYS} | grep -v dlopen > stat2_${DATE}_${DAYS}
#sed -i 's/;/\t/g' stat_${DATE}_${DAYS}
#rm tmp2_${DATE}_${DAYS}
