""" process cyc """

ratio_dict = {}
for line in open("consume_hour_ratio_dict.txt"):
    try:
        hour, ratio = line.strip().split("\t")
        ratio_dict[int(hour)] = float(ratio)
    except:
        continue

#for key in ratio_dict:
#    print key, ratio_dict[key]

result = {}
for line in open("plan_ori"):
    try:
        items = line.strip().split("\x01\x01")
    
        plan_id = items[0]
        cyc_ori = items[5]

        week5 = int(cyc_ori.split("\x01")[4])
    except:
        continue

    ratio_left_list = []    
    ratio_sum = 0.0
    for hour in range(0, 24):
        ratio_left = round(1 - ratio_sum, 1)
        ratio_left_list.append(ratio_left)
        #print "ratiosum:%.2f left:%.2f" % (ratio_sum, ratio_left)

        flag = 1 if week5 & (1 << (23 - hour)) > 0 else 0
        if flag == 1:
            ratio_sum += ratio_dict[hour] 
    
    result[plan_id] = ratio_left_list

for key in result:
    line_str = key + "\t" + '#'.join(map(str, result[key]))
    print line_str
