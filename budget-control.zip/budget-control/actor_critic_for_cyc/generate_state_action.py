""" generate_state_action """
#!/usr/bin/env python
# coding=utf-8

# conv num
conv_num = [x * 5 for x in range(0, 5)]

# charge / tcharge
excess_ratio = [ x / 10.0 for x in range(5, 21)]

# left ratio
left_ratio = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

# generate state file
f_state = open('state_file.txt', 'w')
index = 0
for key1 in conv_num:
    for key2 in excess_ratio:
        for key3 in left_ratio: 
            linestr = '\t'.join(map(str, [key1, key2, key3, index]))
            if index > 0:
                linestr = "\n" + linestr

            f_state.write(linestr)
            index += 1
f_state.close()

# generate action file

action_list = [ x / 10.0 for x in range(5, 31)]
f_action = open('action_file.txt', 'w')
index = 0
for key in action_list:
    linestr = '\t'.join(map(str, [key, index]))
    if index > 0:
        linestr = "\n" + linestr

    f_action.write(linestr)
    index += 1
f_action.close()


