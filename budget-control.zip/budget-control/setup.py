#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Setup script.

Authors: yangye03(yangye03@baidu.com)
Date:    2020/03/19 11:29:52
"""

from setuptools import setup, find_packages

setup(
    name = "budget-control",
    version = "1.0",
    packages = find_packages(),
    description = "This is budget-control code record model",
    author = "yangye03",
    author_email = "None",
    url = "None",
)

