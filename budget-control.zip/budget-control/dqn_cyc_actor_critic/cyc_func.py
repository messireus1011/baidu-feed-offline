""" author yangye03 """

#!/usr/bin/env python
# coding=utf-8

import random
import numpy as np
import sys

def get_conv_norm(conv, size):
    """ get_conv_norm """
    conv_norm = round(float(conv) / float(size), 1)
    conv_norm = max(conv_norm, 0.0)
    conv_norm = min(conv_norm, 1.0)

    return conv_norm

def switch_action_num_to_value(num):
    """ switch_action_num_to_value """
    value = (num + 5) * 1.0 / 10

    return value

def get_feedback_ratio(conv, charge, obid):
    """ get_feedback_ratio """
    ratio = 1.0
    charge = float(charge)
    conv = float(conv)
    obid = float(obid)
    tcharge = obid * conv

    if charge >= (5 * obid):
        if tcharge <= 0:
            ratio = round(obid / charge, 1)
        else:
            ratio = round(tcharge / charge, 1)

    ratio = round(ratio, 2)
    ratio = max(ratio, 0.5)
    ratio = min(ratio, 3.0)

def get_fb_ratio(unit_list, conv_arr, charge_arr, obid_arr):
    """ get_fb_ratio """
    fb_ratio_list = []
    for unitid in unit_list:
        fb_ratio = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
        fb_ratio_list.append(fb_ratio)

    return fb_ratio_list

def get_left_flow_ratio(cyc_rec, unitid, T):
    """ get left flow ratio """
    left_ratio = round(cyc_rec[unitid][T], 2)

    return left_ratio

def get_curr_hour(T):
    """ get_curr_hour """
    ratio = round(float(T) / 23, 2)

    return ratio

def get_consume_fea(unitid, charge_T_arr, T, unit_obid, size):
    """ get_consume_fea """
    unit_obid = float(unit_obid)

    result = 0.0
    if T < 1:
        result = round(float(charge_T_arr[T][unitid]) / unit_obid / size, 1)
    else:
        charge_curr_hour = float(charge_T_arr[T][unitid]) - float(charge_T_arr[T - 1][unitid])
        result = round(charge_curr_hour * 1.0 / unit_obid / size, 1)

    return result


def get_curr_state_x(unit_list, state_size, conv_arr, charge_arr, obid_arr, cyc_rec, \
        T, charge_T_arr, conv_T_arr, action_T_arr):
    """ get curr state """

    ## state_size: 100+201+11+24+21*24+31*24+10*24
    #state_size_real = 1824
    state_size_real = 22
    if state_size != state_size_real:
        sys.exit("get_curr_state: state size is not right")

    state = np.empty(shape=(0, state_size_real))
    for unitid in unit_list:
        unit_conv = int(conv_arr[unitid])
        unit_obid = int(obid_arr[unitid])
        unit_charge = int(charge_arr[unitid])    

        # fea1: current cv
        fea1_cv = get_conv_norm(unit_conv, 20)

        # fea2: fb_ratio
        fea2_fb = get_feedback_ratio(unit_conv, unit_charge, unit_obid)

        # fea3: left flow ratio
        fea3_left_flow = get_left_flow_ratio(cyc_rec, unitid, T)

        # fea4: curr_hour
        fea4_curr_hour = get_curr_hour(T)
        
        # fea5: action_list
        fea5_action_1 = 1.0 if T - 1 < 0 else action_T_arr[T - 1][unitid]
        fea5_action_2 = 1.0 if T - 2 < 0 else action_T_arr[T - 2][unitid]
        fea5_action_3 = 1.0 if T - 3 < 0 else action_T_arr[T - 3][unitid]
        fea5_action_4 = 1.0 if T - 4 < 0 else action_T_arr[T - 4][unitid]
        fea5_action_5 = 1.0 if T - 5 < 0 else action_T_arr[T - 5][unitid]
        fea5_action_6 = 1.0 if T - 6 < 0 else action_T_arr[T - 6][unitid]

        # fea6: fb_list
        fea6_fb_1 = 1.0 if  T - 1 < 0 else get_feedback_ratio(conv_T_arr[T - 1][unitid], \
                charge_T_arr[T - 1][unitid], unit_obid)
        fea6_fb_2 = 1.0 if  T - 2 < 0 else get_feedback_ratio(conv_T_arr[T - 2][unitid], \
                charge_T_arr[T - 2][unitid], unit_obid)
        fea6_fb_3 = 1.0 if  T - 3 < 0 else get_feedback_ratio(conv_T_arr[T - 3][unitid], \
                charge_T_arr[T - 3][unitid], unit_obid)
        fea6_fb_4 = 1.0 if  T - 4 < 0 else get_feedback_ratio(conv_T_arr[T - 4][unitid], \
                charge_T_arr[T - 4][unitid], unit_obid)
        fea6_fb_5 = 1.0 if  T - 5 < 0 else get_feedback_ratio(conv_T_arr[T - 5][unitid], \
                charge_T_arr[T - 5][unitid], unit_obid)
        fea6_fb_6 = 1.0 if  T - 6 < 0 else get_feedback_ratio(conv_T_arr[T - 6][unitid], \
                charge_T_arr[T - 6][unitid], unit_obid)

        # fea7: consume_list get_consume_fea(charge_T_arr, T, unit_obid, size):
        fea7_consume_1 = 0.0 if T - 1 < 0 else get_consume_fea(unitid, charge_T_arr, T - 1, unit_obid, 5)
        fea7_consume_2 = 0.0 if T - 2 < 0 else get_consume_fea(unitid, charge_T_arr, T - 2, unit_obid, 5)
        fea7_consume_3 = 0.0 if T - 3 < 0 else get_consume_fea(unitid, charge_T_arr, T - 3, unit_obid, 5)
        fea7_consume_4 = 0.0 if T - 4 < 0 else get_consume_fea(unitid, charge_T_arr, T - 4, unit_obid, 5)
        fea7_consume_5 = 0.0 if T - 5 < 0 else get_consume_fea(unitid, charge_T_arr, T - 5, unit_obid, 5)
        fea7_consume_6 = 0.0 if T - 6 < 0 else get_consume_fea(unitid, charge_T_arr, T - 6, unit_obid, 5)


        state = np.append(state, [[fea1_cv, fea2_fb, fea3_left_flow, fea4_curr_hour, \
            fea5_action_1, fea5_action_2, fea5_action_3, fea5_action_4, fea5_action_5, fea5_action_6, \
            fea6_fb_1, fea6_fb_2, fea6_fb_3, fea6_fb_4, fea6_fb_5, fea6_fb_6, \
            fea7_consume_1, fea7_consume_2, fea7_consume_3, fea7_consume_4, fea7_consume_5, fea7_consume_6]], axis=0)
    
    state = state.astype('float32')
    
    print ("state value")
    print state
    return state

def calc_rewards_list_x_baging(unit_list, unit_cred_list, conv_arr, charge_arr, obid_arr, base_tcharge, \
    action_predict_list, pid_ratio_list, state_unit_cred, action_num_unit_cred, action_size, train_num, pid_train_num):
    """ calc_rewards_list """

    action_predict_list = np.array(action_predict_list)
    rewards = action_predict_list.copy()
    for index in range(len(action_predict_list)):
        # excess reward
        unitid = unit_cred_list[index]
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        charge = float(charge_arr[unitid])
        excess = get_curr_excess_ratio(conv, obid, charge, 100, 200);
        excess_reward = round(abs(excess * 1.0 / 100 - 1), 2)

        # pid reward
        action_num = action_num_unit_cred[index]
        
        action_num_real = np.argmin(action_predict_list[index])
        acton_value_real = switch_action_num_to_value(action_num_real)
        pid_reward = abs(acton_value_real * 1.0 - pid_ratio_list[index] * 1.0)

        # reward bagging
        bagging_reward = 0.4 * pid_reward + 0.6 * excess_reward

        ## train pid first 
        if train_num < pid_train_num:
            bagging_reward = pid_reward

        rewards[index][action_num] = bagging_reward
        

        # scale
        if action_num - 1 >= 0:
            rewards[index][action_num - 1] = 0.2 * bagging_reward + 0.8 * action_predict_list[index][action_num - 1]
        if action_num + 1 < action_size:
            rewards[index][action_num + 1] = 0.2 * bagging_reward + 0.8 * action_predict_list[index][action_num + 1]

        # ins detail
        ins_state = '\t'.join(map(str, state_unit_cred[index]))
        print "ins> state:%s action:%s action_real:%s action_real_value:%s pid:%s pid_diff:%.2f \
                pid_r:%.4f excess_r:%.4f bagging_r:%.4f train_num:%d" % \
            (ins_state, str(action_num), str(action_num_real), str(acton_value_real), \
            str(pid_ratio_list[index]), pid_reward, \
                pid_reward, excess_reward, bagging_reward, train_num)


    rewards = np.array(rewards).astype('float32')

    print "rewards"
    #print action_predict_list
    #print pid_ratio_list
    #print rewards

    return rewards

'''
   for unitid in unit_cred_list:
        total += 1
        
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])

        excess = get_curr_excess_ratio(conv, obid, charge, 100, 200);
        val = round(abs(excess * 1.0 / 100 - 1), 2)

        if tcharge > 0 and (charge > (0.8 * tcharge) and charge < (1.2 * tcharge)):
            cnt += 1
        
        unit_reward = val - ratio
        unit_reward = max(unit_reward, 0)

        print "tcharge_reward: %s %.4f %.4f %.4f %.4f %.4f %.4f" % (unitid, excess, \
                val, ratio, unit_reward, base_tcharge, total_tcharge)
        rewards.append(unit_reward)

    print ("rewards total %d cnt %d  ratio %.2f" % (total, cnt, float(cnt) / float(total)))

    rewards = np.array(rewards).reshape(len(unit_cred_list), 1).astype('float32')
    return rewards
    '''

def calc_rewards_list_x(unit_list, unit_cred_list, conv_arr, \
        charge_arr, obid_arr, base_tcharge, action_predict_list, pid_ratio_list, state_unit_cred):
    """ calc_rewards_list """

    action_predict_list = np.array(action_predict_list)
    rewards = action_predict_list.copy()
    for index in range(len(action_predict_list)):
        action_num = np.argmin(action_predict_list[index])
        pid_reward = abs(action_num - pid_ratio_list[index]) * 1.0 / 10
        rewards[index][action_num] = pid_reward

        #print action_num
        #print pid_reward

        # scale
        if action_num - 1 >= 0:
            rewards[index][action_num - 1] = 0.4 * pid_reward + 0.6 * action_predict_list[index][action_num - 1]
        if action_num + 1 <= 30:
            rewards[index][action_num + 1] = 0.4 * pid_reward + 0.6 * action_predict_list[index][action_num + 1]

        # ins detail
        ins_state = '\t'.join(map(str, state_unit_cred[index]))
        ins_action = action_num
        ins_pid = pid_ratio_list[index]
        ins_pid_diff = pid_reward
        print "ins> state:%s action:%s pid:%s pid_diff:%s" % (ins_state, \
                str(ins_action), str(ins_pid), str(ins_pid_diff))

    rewards = np.array(rewards).astype('float32')

    print "rewards"
    print action_predict_list
    print pid_ratio_list
    print rewards

    return rewards

def get_one_hot(fea_name, num, len):
    """ generate one hot for fea """
    if num > len - 1:
        print(fea_name + "'s num is too large: " + str(num))
        num = len - 1

    fea_one_hot = (np.eye(len)[num]).astype('float32')
    return fea_one_hot

def get_curr_excess_ratio(unit_conv, unit_obid, unit_charge, scale, max_num):
    """ get current excess ratio """
    unit_obid = float(unit_obid)
    unit_conv = float(unit_conv)
    unit_charge = float(unit_charge)
    tcharge = unit_conv * unit_obid

    excess_ratio = 1.0 * scale
    if unit_charge >= (5 * unit_obid):
        if tcharge <= 0:
            excess_ratio = int(unit_charge * 1.0 / unit_obid * scale)
        else:
            excess_ratio = int(unit_charge * 1.0 / tcharge * scale)

    excess_ratio = max(excess_ratio, 0)
    excess_ratio = min(excess_ratio, max_num)

    #print ("calc excess scale:%f conv:%f obid:%f charge:%f excess:%f" % (float(scale), float(unit_conv), float(unit_obid), float(unit_charge), excess_ratio))
    return excess_ratio



def get_curr_state(unit_list, state_size, conv_arr, charge_arr, obid_arr, cyc_rec, \
        T, charge_T_arr, conv_T_arr, action_T_arr):
    """ get curr state """

    # state_size: 100+201+11+24+21*24+31*24+10*24
    state_size_real = 1824
    if state_size != state_size_real:
        sys.exit("get_curr_state: state size is not right")

    state = np.empty(shape=(0, state_size_real))
    for unitid in unit_list:
        unit_conv = int(conv_arr[unitid])
        unit_obid = int(obid_arr[unitid])
        unit_charge = int(charge_arr[unitid])    

        # fea1: current cv
        fea1_len = 100
        fea1_one_hot = get_one_hot("fea1", unit_conv, fea1_len)

        # fea2: excess_ratio
        fea2_len = 201
        curr_excess_ratio = get_curr_excess_ratio(unit_conv, unit_obid, unit_charge, 100, 200)
        fea2_one_hot = get_one_hot("fea2", curr_excess_ratio, fea2_len)

        # fea3: left flow ratio
        fea3_len = 11
        left_flow_ratio = get_left_flow_ratio(cyc_rec, unitid, T)
        fea3_one_hot = get_one_hot("fea3", left_flow_ratio, fea3_len)

        # fea4: curr_hour
        fea4_len = 24
        fea4_one_hot = get_one_hot("fea4", int(T), fea4_len)

        # fea5: list excess
        fea5_len = 21 * 24
        fea5_item_len = 21
        fea5_one_hot = []
        for hour in range (24):
            unit_conv_hour = int(conv_T_arr[hour][unitid])
            unit_charge_hour = int(charge_T_arr[hour][unitid])
            excess_ratio_hour = get_curr_excess_ratio(unit_conv_hour, unit_obid, unit_charge_hour, 10, 20)
            one_hot_tmp = get_one_hot("fea5", excess_ratio_hour, fea5_item_len)
            fea5_one_hot = np.concatenate((fea5_one_hot, one_hot_tmp))

        # fea6: list action
        fea6_len = 31 * 24
        fea6_item_len = 31
        fea6_one_hot = []
        for hour in range(24):
            action_tmp = int(action_T_arr[hour][unitid] * 10)
            one_hot_tmp = get_one_hot("fea6", action_tmp, fea6_item_len)
            fea6_one_hot = np.concatenate((fea6_one_hot, one_hot_tmp))

        # fea7: consume action
        fea7_len = 10 * 24
        fea7_item_len = 10
        fea7_one_hot = []
        for hour in range(24):
            consume_tmp = int(charge_T_arr[hour][unitid] * 1.0 / unit_obid + 0.5)
            one_hot_tmp = get_one_hot("fea7", consume_tmp, fea7_item_len)
            fea7_one_hot = np.concatenate((fea7_one_hot, one_hot_tmp))
        
        state_one = np.concatenate((fea1_one_hot, fea2_one_hot, fea3_one_hot, \
                fea4_one_hot, fea5_one_hot, fea6_one_hot, fea7_one_hot))
        state = np.append(state, [state_one], axis=0)
    
    state = state.astype('float32')

    return state


def calc_base_tcharge(unit_list, w_arr, obid_arr, gap_arr, big_table):
    """ calc base tcharge """
    base_w_arr = w_arr.copy()
    base_gap_arr = gap_arr.copy()
    conv_arr = {}
    charge_arr = {}
    action_value = []
    for unitid in unit_list:
        conv_arr[unitid] = 0.0
        charge_arr[unitid] = 0.0
        action_value.append(1.0)

    f = open("base_tcharge.txt", "w")
    for T in range(0, 24):
        hour = ("%02d" % T)
        for unitid in unit_list:
            unit_w = base_w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))
            if key in big_table:
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]
        
                conv = float(fetch_list[1])
                obid = float(obid_arr[unitid])
                tcharge = conv * obid
                linestr = "one\t%s\t%d\t%.2f\t%.2f\t%.2f" % (unitid, T, conv, obid, tcharge)
                f.write(linestr + "\n")

    tcharge_total = 0.0
    for unitid in unit_list:
        conv = float(conv_arr[unitid])
        obid = float(obid_arr[unitid])
        tcharge = conv * obid
        tcharge_total = tcharge_total + tcharge
    
        linestr = "%s\t%.2f\t%.2f\t%.2f" % (unitid, conv, obid, tcharge)
        f.write(linestr + "\n")
    f.close()

    tcharge_total = round(tcharge_total, 2)
    
    return tcharge_total

def calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value, gap_arr):
    """ calc_w_att """
    
    w_att = {}
    for index in range(len(unit_list)):
        unitid = unit_list[index]
        ac_r = action_value[index]

        w_att[unitid] = round(ac_r * gap_arr[unitid], 1)

        # the search-table of bid -> <conv, charge> is only in range [0.1, 5.0]
        w_att[unitid] = max(w_att[unitid], 0.1)
        w_att[unitid] = min(w_att[unitid], 5.0)

    return w_att



def calc_rewards_list(unit_list, unit_cred_list, conv_arr, \
        charge_arr, obid_arr, base_tcharge):
    """ calc_rewards_list """
    total_tcharge = 0.0
    for unitid in unit_list:
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        total_tcharge = total_tcharge + tcharge

    tcharge_ratio = round(total_tcharge / base_tcharge - 1, 4)
    super_a = 0.1
    ratio = tcharge_ratio * super_a
    ratio = max(ratio, -0.02)
    ratio = min(ratio, 0.02)

    total = 0
    cnt = 0
    rewards = []
    for unitid in unit_cred_list:
        total += 1
        
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])

        excess = get_curr_excess_ratio(conv, obid, charge, 100, 200);
        val = round(abs(excess * 1.0 / 100 - 1), 2)

        if tcharge > 0 and (charge > (0.8 * tcharge) and charge < (1.2 * tcharge)):
            cnt += 1
        
        unit_reward = val - ratio
        unit_reward = max(unit_reward, 0)

        print "tcharge_reward: %s %.4f %.4f %.4f %.4f %.4f %.4f" % (unitid, excess, \
                val, ratio, unit_reward, base_tcharge, total_tcharge)
        rewards.append(unit_reward)

    print ("rewards total %d cnt %d  ratio %.2f" % (total, cnt, float(cnt) / float(total)))

    rewards = np.array(rewards).reshape(len(unit_cred_list), 1).astype('float32')
    return rewards

def calc_rewards_list_with_tcharge(unit_list, unit_cred_list, conv_arr, charge_arr, obid_arr, base_tcharge):
    """ calc_rewards_list """
    total_tcharge = 0.0
    for unitid in unit_list:
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        total_tcharge = total_tcharge + tcharge

    tcharge_ratio = round(total_tcharge / base_tcharge - 1, 4)
    super_a = 0.1
    ratio = tcharge_ratio * super_a
    ratio = max(ratio, -0.02)
    ratio = min(ratio, 0.02)

    total = 0
    cnt = 0
    rewards = []
    for unitid in unit_cred_list:
        total += 1
        val = 0
        obid = float(obid_arr[unitid])
        conv = float(conv_arr[unitid])
        tcharge = obid * conv
        charge = float(charge_arr[unitid])
        #if tcharge <= 0:
        #    if charge <  obid:
        #        val = 1
        #        cnt += 1
        #else:
        #    if charge > (0.8 * tcharge) and charge < (1.2 * tcharge):
        #        val = 1
        #        cnt += 1
        if tcharge > 0 and (charge > (0.8 * tcharge) and charge < (1.2 * tcharge)):
            val = 1
            cnt += 1
        
        unit_reward = val + ratio
        print "tcharge_reward: %s %.4f %.4f %.4f %.4f %.4f" % (unitid, val, ratio, \
                unit_reward, base_tcharge, total_tcharge)
        
        rewards.append(unit_reward)

    print ("rewards total %d cnt %d  ratio %.2f" % (total, cnt, float(cnt) / float(total)))

    rewards = np.array(rewards).reshape(len(unit_cred_list), 1).astype('float32')
    return rewards

def get_feedback_ratio(conv, charge, obid):
    """ get_feedback_ratio """
    ratio = 1.0
    charge = float(charge)
    conv = float(conv)
    obid = float(obid)
    tcharge = obid * conv

    if charge >= 5 * obid:
        if tcharge <= 0:
            ratio = round(obid / charge, 1)
        else:
            ratio = round(tcharge / charge, 1)

    ratio = round(ratio, 1)
    ratio = max(ratio, 0.5)
    ratio = min(ratio, 3.0)
    
    return ratio




def gsp(advstr, w_arr, gap_arr):
    """ gsp auction """
    minbid = 5.0 * 0.01  # reserve price
    win_num = 1   # asn
    hit_num = 0   # the num of ads that is in w_arr
    items = advstr.strip().split("#")
    advlist = []
    for one in items:
        userid, unitid, bid, ctrq, roiq = one.split(",")

        # mutliply bid with the corresponding w
        if unitid in w_arr:
            #bid = float(bid) * float(w_arr[unitid]) * float(gap_arr[unitid])
            bid = float(bid) * float(w_arr[unitid])
            hit_num += 1

        # cpm, userid, unitid, bid, ctrq, roiq, price, conv
        adv = [float(bid) * float(ctrq)/1000000,
                userid,
                unitid,
                float(bid),
                float(ctrq)/1000000,
                float(roiq)/1000000,
                minbid,
                0]
        advlist.append(adv)

    if hit_num <= 0: return [] # no ad in w_arr 

    # sort by cpm
    advlist.sort(key = lambda x: x[0], reverse = True)

    #print "advlist"
    #print advlist

    # get gsp price
    # only keep the unit that is in w_arr
    adv_num = len(advlist)
    keep_list = []
    for i in range(0, win_num):
        if i >= adv_num: continue

        unitid = advlist[i][2]
        if unitid not in w_arr: continue

        if i < adv_num - 1:
            ctrq = advlist[i][4]
            if ctrq <= 0: continue

            gsp_score = advlist[i + 1][0]
            price = gsp_score
            if price > minbid:
                advlist[i][6] = price

        prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
        value_list = [1, 0]
        conv_num = np.random.choice(value_list, p = prob_list)
        #conv_num = advlist[i][4] * advlist[i][5]
        advlist[i][7] = conv_num
        
        # * 10
        advlist[i][0] = advlist[i][0] * 10
        advlist[i][6] = advlist[i][6] * 10
        for index in range(0, 9):
            conv_num_tmp = np.random.choice(value_list, p = prob_list)
            advlist[i][7] += conv_num_tmp

        keep_list.append(advlist[i])
        #if conv_num == 1:
        #    print "index"
        #    print conv_num
        #    print keep_list

    #print "keep_list"
    #print advlist
    #print keep_list
    return keep_list

def gsp_for_test(advstr, w_arr, gap_arr):
    """ gsp auction """
    minbid = 5.0 * 0.01  # reserve price
    win_num = 1   # asn
    items = advstr.strip().split("#")
    advlist = []
    for one in items:
        userid, unitid, bid, ctrq, roiq = one.split(",")

        # mutliply bid with the corresponding w
        if unitid in w_arr:
            bid = float(bid) * float(w_arr[unitid]) * float(gap_arr[unitid])

        # cpm, userid, unitid, bid, ctrq, roiq, price, conv
        adv = [float(bid) * float(ctrq)/1000000,
                userid,
                unitid,
                float(bid),
                float(ctrq)/1000000,
                float(roiq)/1000000,
                minbid,
                0]
        advlist.append(adv)


    # sort by cpm
    advlist.sort(key = lambda x: x[0], reverse = True)

    # get gsp price
    adv_num = len(advlist)
    keep_list = []
    for i in range(0, win_num):
        if i >= adv_num: continue

        unitid = advlist[i][2]
        if i < adv_num - 1:
            ctrq = advlist[i][4]
            if ctrq <= 0: continue

            gsp_score = advlist[i + 1][0]
            price = gsp_score
            if price > minbid:
                advlist[i][6] = price

        prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
        value_list = [1, 0]
        conv_num = np.random.choice(value_list, p = prob_list)
        #conv_num = advlist[i][4] * advlist[i][5]
        advlist[i][7] = conv_num
        
        keep_list.append(advlist[i])
    
    return keep_list

def gsp_auction(advstr, w_arr, gap_arr, obid_arr):
    """ gsp auction """
    minbid = 5.0 * 0.01  # reserve price
    win_num = 1   # asn
    hit_num = 0   # the num of ads that is in w_arr
    items = advstr.strip().split("#")
    advlist = []
    for one in items:
        if one == "" or one == "NULL": continue
        userid, unitid, bid, ctrq, roiq = one.split(",")
        
        if unitid not in obid_arr: continue
        
        gap_value = 1.3
        if unitid in gap_arr:
            gap_value = float(gap_arr[unitid])

        obid = float(obid_arr[unitid])
        
        # mutliply bid with the corresponding w
        bid = obid * float(roiq)/1000000 * gap_value
        
        if unitid in w_arr:
            bid = bid * float(w_arr[unitid])
            hit_num += 1

        # cpm, userid, unitid, bid, ctrq, roiq, price, conv
        adv = [float(bid) * float(ctrq)/1000000,
                userid,
                unitid,
                float(bid),
                float(ctrq)/1000000,
                float(roiq)/1000000,
                minbid,
                0]
        advlist.append(adv)

    if hit_num <= 0: return [] # no ad in w_arr 

    # sort by cpm
    advlist.sort(key = lambda x: x[0], reverse = True)

    #print "advlist"
    #print advlist

    # get gsp price
    # only keep the unit that is in w_arr
    adv_num = len(advlist)
    keep_list = []
    for i in range(0, win_num):
        if i >= adv_num: continue

        unitid = advlist[i][2]
        if unitid not in w_arr: continue

        if i < adv_num - 1:
            #ctrq = advlist[i][4]
            #if ctrq <= 0: continue

            gsp_score = advlist[i + 1][0]
            price = gsp_score
            if price > minbid:
                advlist[i][6] = price

        prob_list = [advlist[i][4] * advlist[i][5], 1 - (advlist[i][4] * advlist[i][5])]
        value_list = [1, 0]
        conv_num = np.random.choice(value_list, p = prob_list)
        #conv_num = advlist[i][4] * advlist[i][5]
        advlist[i][7] = conv_num
        
        # * 10
        advlist[i][0] = advlist[i][0] * 10
        advlist[i][6] = advlist[i][6] * 10
        for index in range(0, 9):
            conv_num_tmp = np.random.choice(value_list, p = prob_list)
            advlist[i][7] += conv_num_tmp

        keep_list.append(advlist[i])

    return keep_list


def load_unit(file):
    """ load_unit """
    unit_rec = {}
    for line in open(file):
        if len(line.strip().split("\t")) < 3: continue
        unit, obid, charge = line.split("\t")

        if obid == "": continue
        unit_rec[unit] = obid

    return unit_rec

def load_unit_with_prob(file, file2):
    """ load_unit_with_prob """

    unit_abandon = {}
    for line in open(file2):
        unitid, trans_type, is_ocpc_deep, deep_trans_type = line.strip().split("\t")
        if trans_type in ['26', '49', '42'] or deep_trans_type in ['26', '49', '42', '28']:
            unit_abandon[unitid] = trans_type + "\t" + deep_trans_type

    unit_rec = {}
    prob_total = 0.0
    for line in open(file):
        if len(line.strip().split("\t")) < 3: continue
        unitid, obid, charge, ratio = line.strip().split("\t")

        if obid == "": continue
        if unitid in unit_abandon: continue

        unit_rec[unitid] = float(ratio)
        prob_total += float(ratio)
    
    unit_rec[unitid] += (1 - prob_total)

    return unit_rec

def load_gap(file):
    """ load gap """
    gap_arr = {}
    for line in open(file):
        unitid, cmatch, ratio = line.strip().split("\t")
        ratio = float(ratio)
        ratio = round(ratio, 2)
        ratio = max(ratio, 1.0)
        ratio = min(ratio, 3.0)

        gap_arr[unitid] = ratio

    return gap_arr

def load_big_table(file):
    """ load big table """
    big_table = {}
    for line in open(file):
        try:
            unitid, hour, ratio, price, conv, bid_sum = line.strip().split("\t")
        except:
            continue

        key = '\t'.join(map(str, [unitid, hour, ratio]))
        if key not in big_table:
            big_table[key] = [0.0, 0.0, 0.0]
        
        big_table[key][0] = float(price)
        big_table[key][1] = float(conv)
        big_table[key][2] = float(bid_sum)

    return big_table

def get_unit_for_train(unit_rec, num):
    """ get_unit_for_train """
    if num > len(unit_rec.keys()):
        num = len(unit_rec.keys())

    unit_list = np.random.choice(unit_rec.keys(), num, replace=False, p=None)

    return unit_list

def get_unit_for_train_with_prob(unit_rec, num):
    """ get_unit_for_train_with_prob """
    if num > len(unit_rec.keys()):
        num = len(unit_rec.keys())

    unit_list = np.random.choice(unit_rec.keys(), num, replace=False, p=unit_rec.values())

    return unit_list

def load_pv_sample(file):
    """ load_pv_sample """
    pv_rec = {}
    for line in open(file):
        items = line.strip().split("\x01")
        hour = int(items[2])
        searchid = items[3]
        ad_num = items[4]
        ad_str = items[5]

        if hour not in pv_rec:
            pv_rec[hour] = {}
        #pv_rec[hour][searchid] = ad_num + "\t" + ad_str
        pv_rec[hour][searchid] = ad_str

    return pv_rec



def calc_w_att_old(unit_list, conv_arr, charge_arr, obid_arr, action, gap_arr):
    """ calc_w_att """
    
    print "w_att"
    w_att = {}
    for index in range(len(unit_list)):
        unitid = unit_list[index]
        #fb_r = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
        ac_r = action[index]

        #w_att[unitid] = round(fb_r * ac_r - ac_r + 1, 2)
        #w_att[unitid] = max(w_att[unitid], 0.5)
        #w_att[unitid] = min(w_att[unitid], 1.9)

        w_att[unitid] = round(ac_r * gap_arr[unitid], 1)
        w_att[unitid] = max(w_att[unitid], 0.1)
        w_att[unitid] = min(w_att[unitid], 5.0)

        #w_att[unitid] = ac_r
        #print ("unit:%s conv:%d obid:%d charge:%.2f fb_r:%.2f ac_r:%.2f w:%f"\
        #        % (unitid, int(conv_arr[unitid]), int(obid_arr[unitid]),
        #            float(charge_arr[unitid]), fb_r, ac_r, w_att[unitid]))
        

    return w_att

def load_cyc(file):
    """ load cyc """
    result = {}
    for line in open(file):
        try:
            plan_id, cyc_res = line.strip().split("\t")
            cyc_item = cyc_res.split("#")
            
            cyc_list = map(float, cyc_item)
            result[plan_id] = cyc_list
        except:
            continue

    return result

if __name__ == "__main__":
    #advstr = "s1,u1,10,100000,100000#s2,u2,20,100000,100000"
    #res = gsp(advstr)
    #print res

    #unit_size = 3
    #state_size = 10
    #state = get_ori_state(unit_size, state_size)
    #print state

    print "cyc_fun"
