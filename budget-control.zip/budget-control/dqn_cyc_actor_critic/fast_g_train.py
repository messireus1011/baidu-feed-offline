""" author: yangye03 """

import datetime
time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)

import sys
import argparse

import math
import numpy as np

import six

import paddle
import paddle.fluid as fluid

import random
from cyc_func import *

#
# first step: prepare the data
#


######################## global parameters ######################
EPISODE = 11 # Episode limitation
UNIT_SIZE = 10 # step limitation in one episode
TEST = 10 # the number of experiment test every 100 episode
STATE_SIZE = 22 # the dimension of state
ACTION_SIZE = 26 # the dimension of action
PID_TRAIN_NUM = 20000
LEARNING_RATE = 0.001
##################################################################


def get_rand_state(s_dim):
    """ generate random state """
    state = np.zeros(s_dim, dtype=float).astype('float32')
    rand_val = np.random.randint(s_dim)
    rand_val = 1
    state[rand_val] = 1.0

    state = state.reshape(1, s_dim).astype('float32')
    return state

def get_rand_action(a_dim):
    """ generate random state """
    action = np.zeros(a_dim, dtype=float).astype('float32')
    rand_val = np.random.randint(a_dim)
    rand_val = 1
    action[rand_val] = 1.0

    action = action.reshape(1, a_dim).astype('float32')
    return action

def simulate(state, action, s_dim):
    """ generate random simulate result """
    state = get_rand_state(s_dim)
    reward = np.array([np.random.normal(0, 1)]).reshape(1, 1).astype('float32')

    return state, reward


###############################  Q network #################################################
actor_program = fluid.Program()
with fluid.program_guard(actor_program):
    a_state = fluid.layers.data(name='a_state', shape=[STATE_SIZE], dtype='float32')
    a_action = fluid.layers.data(name='a_action', shape=[ACTION_SIZE], dtype='float32')
    a_q_value = fluid.layers.data(name='a_q_value', shape=[ACTION_SIZE], dtype='float32')

    a_hidden1 = fluid.layers.fc(input=a_state, size=64, act='relu', \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))
    a_hidden2 = fluid.layers.fc(input=a_hidden1, size=64, act='softmax', \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))

    actor_all_act_value = fluid.layers.fc(input=a_hidden1, size=ACTION_SIZE, act=None, \
            param_attr=fluid.initializer.Normal(loc=0.0, scale=0.1))
    
    # program for test
    actor_program_test = actor_program.clone(for_test=True)

    actor_all_act_value_reduce = actor_all_act_value
    #actor_all_act_value_reduce = fluid.layers.elementwise_add(actor_all_act_value, a_q_value)
    cost = fluid.layers.square_error_cost(input=actor_all_act_value, label=a_q_value)
    actor_loss_value = fluid.layers.mean(cost)
    
    actor_opt = fluid.optimizer.Adam(learning_rate=LEARNING_RATE)
    actor_opt.minimize(loss=actor_loss_value)

    #actor_all_act_value_reduce = fluid.layers.reduce_sum(actor_all_act_value * a_action, dim=1, keep_dim=True)
    #actor_all_act_value_reduce = fluid.layers.elementwise_mul(a_action, a_q_value)
    #actor_all_act_value_reduce = fluid.layers.sum(a_q_value * a_action)
    #cost = fluid.layers.square_error_cost(input=actor_all_act_value_reduce, label=a_q_value)
    #actor_loss_value = fluid.layers.mean(cost)

    #action_model = fluid.layers.argmin(x=actor_all_act_value, axis=-1).astype('float32')
    #action_model = fluid.layers.reshape(x=action_model, shape=[-1,1], inplace=True).astype('float32')
    #action_model = fluid.layers.reshape(x=action_model, shape=[-1,1])
    #a_pid_ratio = fluid.layers.flatten(a_pid_ratio, axis=0)[0]
    #actor_all_act_value_reduce = fluid.layers.flatten(actor_all_act_value_reduce, axis=0)[0]
    #action_model = fluid.layers.flatten(action_model, axis=0)[0]
    #cost = fluid.layers.square_error_cost(input=actor_all_act_value_reduce, label=a_pid_ratio)
    #cost = fluid.layers.square_error_cost(input=actor_all_act_value, label=actor_all_act_value_reduce)
    #actor_loss_value = fluid.layers.mean(cost)

    #actor_loss_value = fluid.layers.mean(a_pid_ratio)

    #output = fluid.layers.shape(actor_all_act_value_reduce)
    #output2 = fluid.layers.shape(action_model)


def actor_learn(exe, program, state, action, q_value):
    """ actor train """
    [value, value_reduce, ct, loss, a_c, a_q] \
            = exe.run(program, feed={'a_state':state,
            'a_action':action, 'a_q_value':q_value},
            fetch_list=[actor_all_act_value, actor_all_act_value_reduce, cost, actor_loss_value, a_action, a_q_value])

    print ("actor_learn2")
    print value
    print value_reduce
    print ct
    print loss
    print a_c
    print a_q

    return loss

def actor_choose_action(exe, program, state, ACTION_SIZE, train_num, PID_TRAIN_NUM):
    """ actor choose action """

    action_num_list = []
    action_value_list = []
    [act_value] = exe.run(program, feed={'a_state':state}, fetch_list=[actor_all_act_value])
    for index in range(act_value.shape[0]):
        num = np.argmin(act_value[index])

        # random disturb
        # num = np.random.choice(range(ACTION_SIZE))
        if train_num > PID_TRAIN_NUM:
            disturb_list = [-3, -2, -1, 0, 1, 2, 3]
            disturb_prob = [0.1, 0.1, 0.1, 0.4, 0.1, 0.1, 0.1]
            disturb_num = np.random.choice(disturb_list, p=disturb_prob)
            num = num + disturb_num
            num = min(num, ACTION_SIZE - 1)
            num = max(num, 0)

        action_num_list.append(num)
        #value = num * 1.0 / 10
        value = switch_action_num_to_value(num)
        action_value_list.append(value)
    
    action = (np.eye(ACTION_SIZE)[action_num_list]).astype('float32')
    action_predict = act_value

    return action, action_value_list, action_num_list, action_predict

###############################################################################################

    
use_cuda = False
place = fluid.CUDAPlace(0) if use_cuda else fluid.CPUPlace()
exe = fluid.Executor(place)
startup_program = fluid.default_startup_program()
exe.run(startup_program)


time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print("start load pv %s" % (time))

# load train unit
unit_rec = load_unit_with_prob("unit_obid_charge_prob_9000", "unit_trans_type")
# load cyc
cyc_rec = load_cyc("unit_cyc")
# load obid arr all
obid_arr_all = load_unit("unit_obid_charge")
# load gap arr
gap_arr = load_gap("unit_gap")
# load big_table
big_table = load_big_table("big_talbe_nogap.txt_10000_pcoc")

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print("load big table finished %s" % (time))

train_num = 0
EPISODE = 10000000 # Episode limitation
UNIT_SIZE = 1000 # step limitation in one episode
for ep in range(EPISODE):
    time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print ("epstart %d start %s" % (ep, time))

    # get unit for current batch
    unit_list = get_unit_for_train(unit_rec, UNIT_SIZE)

    # initialization
    w_arr = {}         # bid ratio 
    conv_arr = {}      # unit's total conv
    charge_arr = {}    # unit's total charge
    obid_arr = {}      # unit's obid
    
    charge_T_arr = {}
    conv_T_arr = {}
    action_T_arr = {}

    for hour in range(0, 24):
        charge_T_arr[hour] = {}
        conv_T_arr[hour] = {}
        action_T_arr[hour] = {}
    
    for unitid in unit_list:
        if unitid not in gap_arr:
            gap_arr[unitid] = 1.3
        w_arr[unitid] = gap_arr[unitid]

        obid_arr[unitid] = obid_arr_all[unitid]
        conv_arr[unitid] = 0.0
        charge_arr[unitid] = 0.0

        for hour in range(0, 24):
            charge_T_arr[hour][unitid] = 0.0
            conv_T_arr[hour][unitid] = 0.0
            action_T_arr[hour][unitid] = 1.0

    # base tcharge with only gap_param
    base_tcharge = calc_base_tcharge(unit_list, w_arr, obid_arr, gap_arr, big_table)

    # step 0
    T=0
    for T in range(0, 1):
        hour = ("%02d" % T)
        for unitid in unit_list:
            unit_w = w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))
            if key in big_table:
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]

                charge_T_arr[T][unitid] += fetch_list[0]
                conv_T_arr[T][unitid] += fetch_list[1]
            #if T > 0:
            #    charge_T_arr[T][unitid] += charge_T_arr[T - 1][unitid]
            #    conv_T_arr[T][unitid] += conv_T_arr[T - 1][unitid]



    for T in range(1, 24):
        time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print("start_T samples ep %d %d %s" % (ep, T, time))
        
        # update the state
        cnt = 0
        for i in conv_arr:
            cnt += conv_arr[i]
        print "cnt: " + str(cnt)

        # get curr state
        state = get_curr_state_x(unit_list, STATE_SIZE, conv_arr, charge_arr, obid_arr, \
                cyc_rec, T, charge_T_arr, conv_T_arr, action_T_arr)

        # get curr action
        action, action_value, action_num_list, action_predict = actor_choose_action(exe, \
                actor_program_test, state, ACTION_SIZE, train_num, PID_TRAIN_NUM)


        print "batch unit"
        print unit_list
        print state
        print action
        print action_value

        # fetch conversion-credible unit (conv >= 5)
        unit_cred_list = []
        state_unit_cred = np.empty(shape=(0, STATE_SIZE))
        action_unit_cred = np.empty(shape=(0, ACTION_SIZE))
        action_num_unit_cred = []
        action_unit_cred_predict = []
        
        for index in range(len(unit_list)):
            unitid = unit_list[index]

            #print ("test1 unit:%s charge:%f conv:%d obid:%d" % \
            #        (unitid, float(charge_arr[unitid]), int(conv_arr[unitid]), int(obid_arr[unitid])))
            if int(obid_arr[unitid]) > 0 and float(charge_arr[unitid]) >= (5 * int(obid_arr[unitid])):
                unit_cred_list.append(unitid)
                state_unit_cred = np.append(state_unit_cred, [state[index]], axis=0)
                action_unit_cred = np.append(action_unit_cred, [action[index]], axis=0)
                action_num_unit_cred.append(action_num_list[index])
                action_unit_cred_predict.append(action_predict[index])
            else:
                # if the conv is not credible, set the action = 1.0
                action_value[index] = 1.0
            

        state_unit_cred = state_unit_cred.astype('float32')
        action_unit_cred = action_unit_cred.astype('float32')
        
        # fb ratio list 
        pid_ratio_list = get_fb_ratio(unit_cred_list, conv_arr, charge_arr, obid_arr)

        print "credible unit"
        print unit_cred_list
        print state_unit_cred
        print len(state_unit_cred)
        print action_unit_cred
        print len(action_unit_cred)

        # update w_arr
        w_arr = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value, gap_arr)

        # execute T step
        hour = ("%02d" % T)
        
        check_num = 0
        total_num = 0
        for index in range(len(unit_list)):
            total_num += 1

            unitid = unit_list[index]
            unit_w = w_arr[unitid]
            key = '\t'.join(map(str, [unitid, hour, unit_w]))

            action_T_arr[T][unitid] = action_value[index]
            if key in big_table:
                check_num += 1
                fetch_list = big_table[key]
                charge_arr[unitid] += fetch_list[0]
                conv_arr[unitid] += fetch_list[1]
                    
                charge_T_arr[T][unitid] += fetch_list[0]
                conv_T_arr[T][unitid] += fetch_list[1]

            if T > 0:
                charge_T_arr[T][unitid] += charge_T_arr[T - 1][unitid]
                conv_T_arr[T][unitid] += conv_T_arr[T - 1][unitid]
        
        print ("total_num:%d check_num:%d" % (total_num, check_num))


        # the last hour does not need the second loop
        if T > 23: continue

        # if there is no credible unit, continue
        if len(unit_cred_list) <= 0: continue

        # storage for the second loop
        charge_arr_cp = charge_arr.copy()
        conv_arr_cp = conv_arr.copy()
       
        for t in range(T + 1, 24):
            hour = ("%02d" % t)
        
            for unitid in unit_cred_list:
                unit_w = w_arr[unitid]
                key = '\t'.join(map(str, [unitid, hour, unit_w]))
                if key in big_table:
                    fetch_list = big_table[key]
                    charge_arr_cp[unitid] += fetch_list[0]
                    conv_arr_cp[unitid] += fetch_list[1]

            time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print("finished samples ep %d %d %d %s" % (ep, T, t, time))

        # calc rewards
        #rewards = calc_rewards_list(unit_list, unit_cred_list, conv_arr_cp, charge_arr_cp, obid_arr, base_tcharge)
        rewards = calc_rewards_list_x_baging(unit_list, unit_cred_list, conv_arr_cp, charge_arr_cp, obid_arr, \
            base_tcharge, action_unit_cred_predict, pid_ratio_list, state_unit_cred, action_num_unit_cred, \
            ACTION_SIZE, train_num, PID_TRAIN_NUM)
        #print "rewards"
        #print rewards

        # train the Q network
        loss = actor_learn(exe, actor_program, state_unit_cred, action_unit_cred, rewards)
        print ("actor loss %.5f  num %d ep:%d T:%d train_num:%d" % (loss[0], len(unit_cred_list), ep, T, train_num))

        # record the train_num
        train_num += 1
        #sys.exit()
    time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print ("ep %d end %s" % (ep, time))


    # save actor predict model
    if ep % 100 == 0:
        actor_params_dirname = "actor_model/actor.model.%s" % (ep)
        fluid.io.save_inference_model(dirname = actor_params_dirname,
            feeded_var_names = ['a_state'],
            target_vars = [actor_all_act_value],
            executor = exe,
            main_program = actor_program_test)

#state = (np.eye(10)[[1,2]]).astype('float32')
#action = (np.eye(10)[[3,4]]).astype('float32')
#q_value = np.array([23, 25]).reshape(2,1).astype('float32')

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)
