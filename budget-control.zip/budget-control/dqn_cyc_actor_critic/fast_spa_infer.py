""" author: yangye03 """
#!/usr/bin/env python
# coding=utf-8
import datetime
import random
from cyc_func import *

import paddle
import paddle.fluid as fluid

import numpy as np
import sys

from scipy.signal import find_peaks
from scipy.misc import electrocardiogram

time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(time)

######################## global parameters ######################
STATE_SIZE = 22 # the dimension of state
ACTION_SIZE = 31 # the dimension of action
LEARNING_RATE = 0.001
##################################################################


use_cuda = False
place = fluid.CUDAPlace(0) if use_cuda else fluid.CPUPlace()
infer_exe = fluid.Executor(place)
startup_program = fluid.default_startup_program()
infer_exe.run(startup_program)

params_dirname = "actor_model/actor.model.25000"
[inference_program, feed_target_names, fetch_targets] = fluid.io.load_inference_model(params_dirname, infer_exe)

print "param"
print feed_target_names
print fetch_targets

print ("hello")


USE_PREDICT = 1

if len(sys.argv) >= 2:
    USE_PREDICT = int(sys.argv[1])

print "USE"
print USE_PREDICT


# load obid arr all
obid_arr_all = load_unit("unit_obid_charge")

# load gap arr
gap_arr = load_gap("unit_gap")

# big_table
big_table = load_big_table("big_talbe_nogap.txt_10000_pcoc")

# load cyc
cyc_rec = load_cyc("unit_cyc")

# load test unit
#unit_rec = load_unit_with_prob("unit_obid_charge_prob_10000", "unit_trans_type")
unit_rec = load_unit_with_prob("unit_obid_charge_prob_test_1000", "unit_trans_type")
#unit_rec = load_unit_with_prob("unit_obid_charge_prob_9000", "unit_trans_type")

# select unit for test
unit_list = unit_rec.keys()

# initialization
w_arr = {}         # bid ratio 
conv_arr = {}      # unit's total conv
charge_arr = {}    # unit's total charge
obid_arr = {}      # unit's obid
    
charge_T_arr = {}
conv_T_arr = {}
action_T_arr = {}

for hour in range(0, 24):
    charge_T_arr[hour] = {}
    conv_T_arr[hour] = {}
    action_T_arr[hour] = {}
    
for unitid in unit_list:
    if unitid not in gap_arr:
        gap_arr[unitid] = 1.3
    w_arr[unitid] = gap_arr[unitid]

    obid_arr[unitid] = obid_arr_all[unitid]
    conv_arr[unitid] = 0.0
    charge_arr[unitid] = 0.0

    for hour in range(0, 24):
        charge_T_arr[hour][unitid] = 0.0
        conv_T_arr[hour][unitid] = 0.0
        action_T_arr[hour][unitid] = 1.0

# base tcharge with only gap_param
#base_tcharge = calc_base_tcharge(unit_list, w_arr, obid_arr, gap_arr, big_table)
check_file = "./check_detail/pid_check.txt"
check_f = open(check_file, "w")

for T in range(0, 24):
    time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print("start_T samples ep %d %d %s" % (0, T, time))
        
    # get curr state
    state = get_curr_state_x(unit_list, STATE_SIZE, conv_arr, charge_arr, obid_arr, \
            cyc_rec, T, charge_T_arr, conv_T_arr, action_T_arr)

    results = infer_exe.run(
        inference_program,
        feed={'a_state':state,},
        fetch_list=fetch_targets)
    
    print "size"
    print len(results[0])
    print len(unit_list)
    
    action_value = []
    for index in range(len(unit_list)):
        unitid = unit_list[index]
        num = np.argmin(results[0][index])
        value = switch_action_num_to_value(num)
        action_value.append(value)

    print "results"
    print results

    #sys.exit()
    print "batch unit"
    print action_value

    # fetch conversion-credible unit (conv >= 5)
    check_unit_list = []
    check_aciont_list = []
    check_pid_list = []

    for index in range(len(unit_list)):
        unitid = unit_list[index]

        if USE_PREDICT == 1:
            #print ("test1 unit:%s charge:%f conv:%d obid:%d" % (unitid, float(charge_arr[unitid]), int(conv_arr[unitid]), int(obid_arr[unitid])))
            if int(obid_arr[unitid]) > 0 and float(charge_arr[unitid]) >= (5 * int(obid_arr[unitid])):
                check_unit_list.append(unitid)
                check_aciont_list.append(action_value[index])
                pid_tmp = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
                check_pid_list.append(pid_tmp)

                # check peaks
                np_max = np.max(results[0][index])
                np_change = np.array([np_max - x for x in results[0][index]])
                np_max_change = np.max(np_change)
                height_val = np_max_change * 0.98
                peaks, _ = find_peaks(np_change, height=height_val, distance=3)
                peak_num = len(peaks)

                print ("peak_check")
                print results[0][index]
                print np_max
                print np_change
                print np_max_change
                print height_val
                print peaks
                print "peak_num: %d" % (peak_num)

                pass
            else:
                # if the conv is not credible, set the action = 1.0
                action_value[index] = 1.0

        if USE_PREDICT == 2:
            print "check:use 2"
            if int(obid_arr[unitid]) > 0 and float(charge_arr[unitid]) >= (5 * int(obid_arr[unitid])):
                action_value[index] = get_feedback_ratio(conv_arr[unitid], charge_arr[unitid], obid_arr[unitid])
            else:
                action_value[index] = 1.0
        
        if USE_PREDICT == 3:
            print "check:use 3"
            action_value[index] = 1.0
    
    print action_value

    check_unit_str = '\t'.join(map(str, check_unit_list))
    check_aciont_str = '\t'.join(map(str, check_aciont_list))
    check_pid_str = '\t'.join(map(str, check_pid_list))
    check_f.write(str(T) + "\n")
    check_f.write(check_unit_str + "\n")
    check_f.write(check_aciont_str + "\n")
    check_f.write(check_pid_str + "\n")

    # update w_arr
    w_arr = calc_w_att(unit_list, conv_arr, charge_arr, obid_arr, action_value, gap_arr)

    # execute T step
    hour = ("%02d" % T)
        
    check_num = 0
    total_num = 0
    for index in range(len(unit_list)):
        total_num += 1

        unitid = unit_list[index]
        unit_w = w_arr[unitid]
        key = '\t'.join(map(str, [unitid, hour, unit_w]))

        action_T_arr[T][unitid] = action_value[index]
        if key in big_table:
            check_num += 1
            fetch_list = big_table[key]
            charge_arr[unitid] += fetch_list[0]
            conv_arr[unitid] += fetch_list[1]
                    
            charge_T_arr[T][unitid] += fetch_list[0]
            conv_T_arr[T][unitid] += fetch_list[1]
        else:
            print ("key:%s not in big_table" % (key))
        if T > 0:
            charge_T_arr[T][unitid] += charge_T_arr[T - 1][unitid]
            conv_T_arr[T][unitid] += conv_T_arr[T - 1][unitid]
        
    print ("total_num:%d check_num:%d" % (total_num, check_num))


check_f.close()

# check results
total_cnt = 0
valid_cnt = 0
single_hit_cnt = 0
double_hit_cnt = 0
total_charge = 0.0
total_tcharge = 0.0

check_charge = {}
check_tcharge = {}

for unitid in unit_list:
    conv = float(conv_arr[unitid])
    charge = float(charge_arr[unitid])
    obid = float(obid_arr[unitid])
    tcharge = obid * conv

    total_charge += charge
    total_tcharge += tcharge

    check_charge[unitid] = check_charge.get(unitid, 0.0) + charge
    check_tcharge[unitid] = check_tcharge.get(unitid, 0.0) + tcharge

    total_cnt += 1;
    if conv >= 5:
        valid_cnt += 1

        if charge <= 1.2 * tcharge:
            single_hit_cnt += 1
            
            if charge >= 0.8 * tcharge:
                double_hit_cnt += 1

excess_ratio = total_charge / total_tcharge - 1

if valid_cnt == 0: valid_cnt = 1.0
single_ratio = single_hit_cnt * 1.0 / valid_cnt
double_ratio = double_hit_cnt * 1.0 / valid_cnt

f_file = "./check_detail/check_results.txt_%d" % USE_PREDICT
f = open(f_file, 'w')
res_str = "res charge:%.2f tcharge:%.2f total_cnt:%d valid_cnt:%d single_hit:%d \
        double_hit:%d excess_ratio:%.2f single_ratio:%.2f double_rratio:%.2f" % \
        (total_charge, total_tcharge, total_cnt, valid_cnt, single_hit_cnt, \
        double_hit_cnt, excess_ratio, single_ratio, double_ratio)
f.write(res_str + "\n")
f.close()

t_file = "./check_detail/check_excess.txt_%d" % USE_PREDICT
t_f = open(t_file, "w")
for unitid in check_charge:
    line_str = '\t'.join(map(str, [unitid, check_charge[unitid], check_tcharge[unitid], conv_arr[unitid]]))
    t_f.write(line_str + "\n")
t_f.close()
